/*
* @(#)BaseActivity.java
*
* Copyright (c) 2013, Liberty Tax Service.
* All rights reserved.
*
* Use is subject to license terms. This software is protected by
* copyright law and international treaties. Unauthorized reproduction or
* distribution of this program, or any portion of it, may result in severe
* civil and criminal penalties, and will be prosecuted to the maximum extent.
*/
package net.libertytax.b2b.activities;

import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.Misc;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.Error;
import net.libertytax.b2b.base.ErrorCode;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.base.WebServiceTask;
import net.libertytax.b2b.util.B2BContext;
import net.libertytax.b2b.util.MessageUtil;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;

public class BaseActivity extends Activity {

	protected Object data;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		B2BContext.getInstance().setActiveContext(this);
		setData();
		prepareControls();
		subscribeEvents();
		applyDefaults();
	}

	private void setData() {

		Bundle bundle = getIntent().getBundleExtra("info");

		if (bundle == null) return;

		data = Content.resolve(bundle.getString(Keys.BUNDLE_CONTENT_KEY));
	}

	public Object getData() { return data; }

	public void openActivity(Context ctx, Class<?> cls, Bundle bundle) {

		Intent intent = new Intent(ctx, cls);
		if (bundle != null) {
			intent.putExtra(Keys.BUNDLE_KEY, bundle);
		}
		((Activity) ctx).finish();
		ctx.startActivity(intent);
	}

	public void executeService(RequestCode code, Boolean singleCall, ServiceInput input) {
		WebServiceTask serviceTask = new WebServiceTask(this, code, singleCall);
		serviceTask.execute(input);
	}

	public void executeService(RequestCode code, Boolean singleCall, Boolean canStartProgress, ServiceInput input) {
		WebServiceTask serviceTask = new WebServiceTask(this, code, singleCall, canStartProgress);
		serviceTask.execute(input);
	}

	public Bundle getBundle(String contentKey) {
		Bundle bundle = new Bundle();
		bundle.putString(Keys.BUNDLE_CONTENT_KEY, contentKey);
		return bundle;
	}

	public void convertAndThrow(Exception e, String title) {
		AppException ae;
		if (e instanceof AppException) {
			ae = (AppException)e;
		} else {
			ae = (new AppException(new Error(ErrorCode.UNKNOWN)));
		}
		handleError(ae, title);
	}

	private ProgressDialog progressBar;
	public void showProgress(Context context, String title, String messageKey) {

		progressBar = new ProgressDialog(context);
		progressBar.setCancelable(false);
		progressBar.setCustomTitle(null);
		progressBar.setMessage(Misc.KEY_LOADING);
		progressBar.show();
	}

	public void dismissProgress() {

		if (progressBar == null) return;

		progressBar.dismiss();
		progressBar = null;
	}

	public void showAlert(final Context c,
										String msg,
										String title) {

		AlertDialog.Builder builder = new AlertDialog.Builder(c);
		if (msg == null) {
			msg = ErrorCode.UNKNOWN;
		}
		builder.setTitle(title);
		builder.setMessage(msg)
			   .setCancelable(true)
			   .setNeutralButton(Labels.ALERT_BUTTON_TEXT,
					   new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int id) { }
			   		  });
		AlertDialog alert = builder.create();
		alert.show();
	}

	public void showConfirmation(Context context, String title, String msg) {

		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
 
		// set title
		alertDialogBuilder.setTitle(title);
 
		// set dialog message
		alertDialogBuilder
			.setMessage(msg)
			.setCancelable(false)
			.setPositiveButton(Misc.POSITIVE_BUTTON, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog,int id) {
					dialog.dismiss();
					BaseActivity.this.onPositiveResult();
				}
			})
			.setNegativeButton(Misc.NEGATIVE_BUTTON, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog,int id) {
					dialog.cancel();
					BaseActivity.this.onNegativeResult();
				  }
			});
 
		// create alert dialog
		AlertDialog alertDialog = alertDialogBuilder.create();

		// show it
		alertDialog.show();
	}

	public void handleError(Exception ae, String titleKey) {

		String msg;
		if (ae instanceof AppException) {
			msg = ae.getMessage();
			if (((AppException) ae).getErrCodes().get(0).equals(ErrorCode.SESSION_EXPIRED)) {
				String userName = (String) Content.resolve(Keys.LOGIN_CONTENT);
				Content.removeAll();
				Content.getInstance().addContent(Keys.LOGOUT_CONTENT, userName);
				openActivity(this, LoginActivity.class, getBundle(Keys.LOGOUT_CONTENT));
			}
		} else {
			msg = new AppException(ae).getMessage();
		}
		showAlert(this, msg, MessageUtil.getMessage(titleKey));
		dismissProgress();
	}

	protected void addFragment(int resource, Fragment fragment) {

        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();

        ft.add(resource, fragment);
        ft.commitAllowingStateLoss();
    }

	protected void replaceFragment(int resource, Fragment fragment) {

        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();

        ft.replace(resource, fragment);

        ft.commitAllowingStateLoss();
    }

	public void processOutput(ServiceResponse result, RequestCode requestCode) {	}
	protected void prepareControls() {	}
	protected void subscribeEvents() {	}
	protected void applyDefaults() { }
	protected void onPositiveResult() {	}
	protected void onNegativeResult() { }
	public void currentLocationFromUtil(Location location) { }
}

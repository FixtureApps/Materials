package net.libertytax.b2b.activities;

import java.util.List;

import net.libertytax.b2b.R;
import net.libertytax.b2b.adapters.OtherMarketerAdapter;
import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.Misc;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.base.Constants.Titles;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.Error;
import net.libertytax.b2b.base.ErrorCode;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.base.ServiceInvoker;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.fragments.B2BMapFragment;
import net.libertytax.b2b.fragments.B2BMapFragment.OnMapAttachedListener;
import net.libertytax.b2b.fragments.B2BMapFragment.OnMapViewCreatedListener;
import net.libertytax.b2b.maputils.ui.TextIconGenerator;
import net.libertytax.b2b.model.Marketer;
import net.libertytax.b2b.util.B2BLocationManager;
import net.libertytax.b2b.util.KeyboardUtil;
import net.libertytax.b2b.util.LocationValue;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.location.Location;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.SparseArray;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class OtherMarketersActivity extends BaseActivity
							implements OnClickListener,
										OnMapAttachedListener,
										OnMapViewCreatedListener,
										OnItemClickListener,
										TextWatcher {

	private RelativeLayout relOtherMarketers;
	private RelativeLayout relSearch;
	private ImageButton imgBtBack;
	private ImageButton imgBtSearch;
	private AutoCompleteTextView txtMarketerSearch;
	private TextView txtCancel;
    private GoogleMap gMap;
	private B2BMapFragment mapFragment;

	private List<Marketer> marketers;
	private SparseArray<Marker> marketerMarkersMap;
	private SparseArray<String> marketerAddressMap;
	private boolean mapLoaded;
	private String previousText;

    Location currentLocation;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.other_marketers);
		super.onCreate(savedInstanceState);
		addMapFragment(R.id.relMarketerMap, getMapFragment());
	}

	@Override
	protected void prepareControls() {

		if (!mapLoaded) return;

		relOtherMarketers = (RelativeLayout) findViewById(R.id.relOtherMarketers);
		relSearch = (RelativeLayout) findViewById(R.id.relOtherMarketersSearch);
		imgBtBack = (ImageButton) findViewById(R.id.imgMarketersBack);
		imgBtSearch = (ImageButton) findViewById(R.id.imgMarketersSearch);
		txtMarketerSearch = (AutoCompleteTextView) findViewById(R.id.txtMarketersSearchText);
		txtCancel = (TextView) findViewById(R.id.txtMarketersCancel);
		marketerMarkersMap = new SparseArray<Marker>();
		marketerAddressMap = new SparseArray<String>();
	}

	@Override
	protected void subscribeEvents() {

		if (!mapLoaded) return;

		imgBtBack.setOnClickListener(this);
		imgBtSearch.setOnClickListener(this);
		txtCancel.setOnClickListener(this);
		txtMarketerSearch.setOnItemClickListener(this);
		txtMarketerSearch.addTextChangedListener(this);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void applyDefaults() {

		if (!mapLoaded) return;

		marketers = (List<Marketer>) data;
		populateTextView();
	}

	private void populateTextView() {

		OtherMarketerAdapter adapter = new OtherMarketerAdapter(OtherMarketersActivity.this, marketers);
		txtMarketerSearch.setAdapter(adapter);
	}

	private void addMapFragment(int resource, Fragment fragment) {

        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();

        ft.add(resource, fragment);
        ft.commitAllowingStateLoss();
    }

	private B2BMapFragment getMapFragment() {

		if (mapFragment == null) {
			mapFragment = new B2BMapFragment();
			mapFragment.setListener(this);
			mapFragment.setViewListener(this);
		}
		return mapFragment;
	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.imgMarketersBack:
			goBack();
			break;
		case R.id.imgMarketersSearch:
			showSearchBar(true);
			break;
		case R.id.txtMarketersCancel:
			cancelSearch();
			break;
		default:
			break;
		}
	}

	private void showSearchBar(boolean canShow) {

		relOtherMarketers.setVisibility(canShow ? View.GONE : View.VISIBLE);
		relSearch.setVisibility(canShow ? View.VISIBLE : View.GONE);
		if (canShow) {
			txtMarketerSearch.requestFocus();
			KeyboardUtil.setImeVisibility(true, txtMarketerSearch);
			txtMarketerSearch.addTextChangedListener(null);
			txtMarketerSearch.setText(Labels.EMPTY);
			txtMarketerSearch.addTextChangedListener(this);
		} else {
			KeyboardUtil.setImeVisibility(false, txtMarketerSearch);
		}
	}

	private void cancelSearch() {
		showSearchBar(false);
	}

	@Override
	public void onBackPressed() {

		try {
			goBack();
		} catch (Exception e) {
			convertAndThrow(e, Titles.SELECT_OFFICE_TITLE);
		}
	}

	private void goBack() {

		ServiceInvoker.checkNetworkAvailability();
		showProgress(OtherMarketersActivity.this, Labels.EMPTY, Misc.KEY_LOADING);
		openActivity(OtherMarketersActivity.this, DashboardActivity.class, null);
	}

	@Override
	public void OnMapViewCreated() {

		mapLoaded = true;
		prepareControls();
		subscribeEvents();
		applyDefaults();
		setUpMapIfNeeded();
		setMapViewParams();
		showProgress(OtherMarketersActivity.this, Labels.EMPTY, Misc.KEY_LOADING);
		getCurrentLocation();
	}

	private void fetchAddresses() {

    	Marketer current = new Marketer();
    	current.setLattitude(String.valueOf(currentLocation.getLatitude()));
    	current.setLattitude(String.valueOf(currentLocation.getLongitude()));
    	Content.getInstance().addContent(Keys.GOOGLE_MAP_ADDRESS_COUNTER, -1);
    	Content.getInstance().addContent(Keys.GOOGLE_MAP_ADDRESS_TAG, current);
    	fetchLatLng(current, false, false);
	}

    private void fetchLatLng(Marketer source, boolean isLastCall, boolean startProgress) {

    	try {
    		if (isLastCall) {
    			executeService(RequestCode.GOOGLE_MAP_ADDRESS_SERVICES_LAST, isLastCall, startProgress,
    					getGoogleMapInput(source.getLattitude(), source.getLongitude()));
    		} else {
    			executeService(RequestCode.GOOGLE_MAP_ADDRESS_SERVICES, isLastCall, startProgress,
    					getGoogleMapInput(source.getLattitude(), source.getLongitude()));
    		}
    	} catch (Exception e) {
    		handleError(new AppException(new Error(ErrorCode.MAP_ROAD_FETCH_FAILED)), Titles.MY_MAP_TITLE);
    	}
    }

    private ServiceInput getGoogleMapInput(String sourceLat, String sourceLong) {

    	ServiceInput input = new ServiceInput();
    	input.setHeaderRequired(false);
    	input.setInput(Labels.EMPTY);
    	input.setRequestType(RequestType.GET);
    	input.setUrl(makeURL(sourceLat, sourceLong));

    	return input;
    }

    public String makeURL (String sourceLat, String sourceLong){

    	StringBuilder urlString = new StringBuilder();
        urlString.append("http://maps.googleapis.com/maps/api/geocode/json");
        urlString.append("?latlng=");// from
        urlString.append(sourceLat);
        urlString.append(",");
        urlString.append(sourceLong);
        urlString.append("&sensor=false");
        return urlString.toString();
    }

    @Override
    public void processOutput(ServiceResponse result, RequestCode requestCode) {

    	switch (requestCode) {
		case GOOGLE_MAP_ADDRESS_SERVICES:
			onAddressFetching(result);
			break;
		case GOOGLE_MAP_ADDRESS_SERVICES_LAST:
			onAddressFetched(result);
			break;
		default:
			break;
		}
    }

    private void onAddressFetching(ServiceResponse response) {

		try {
			
			if (marketers.size() == 0) {
				addMarkerForMarketers();
				return;
			}

			Integer counter = (Integer) Content.resolve(Keys.GOOGLE_MAP_ADDRESS_COUNTER);
			Marketer marketer = (Marketer) Content.resolve(Keys.GOOGLE_MAP_ADDRESS_TAG);
			marketerAddressMap.put(marketer.getMarketerId(), getAddress(response.getOutput()));
			counter++;

			boolean isLastCall = (counter >= (marketers.size() - 1));

			Content.getInstance().addContent(Keys.GOOGLE_MAP_ADDRESS_COUNTER, counter);
			Content.getInstance().addContent(Keys.GOOGLE_MAP_ADDRESS_TAG, marketers.get(counter));
			fetchLatLng(marketers.get(counter), isLastCall, false);
		} catch (Exception e) {
			handleError(new AppException(new Error(ErrorCode.UNKNOWN_GMAP)), Titles.MY_MAP_TITLE);
		} 
    }

    private void onAddressFetched(ServiceResponse response) {

    	Marketer marketer = (Marketer) Content.resolve(Keys.GOOGLE_MAP_ADDRESS_TAG);
		marketerAddressMap.put(marketer.getMarketerId(), getAddress(response.getOutput()));

		addMarkerForMarketers();

		dismissProgress();
    }

    private String getAddress(String json) {

    	try {

    		JSONObject jsonObj = new JSONObject(json);
			JSONArray resultArray = jsonObj.getJSONArray(Misc.RESULTS_PARAM_NAME);
			JSONObject result = resultArray.getJSONObject(0);
			return result.getString(Misc.FORMATTED_ADDRESS_PARAM_NAME);
    	} catch (JSONException je) {
    	}

    	return Labels.EMPTY;
    }

    private void getCurrentLocation() {
        B2BLocationManager.getB2BLocationManager().getCurrentLocation(OtherMarketersActivity.this, locationValue);
    }

    public LocationValue locationValue = new LocationValue() {

    	@Override
        public void getCurrentLocation(Location location) {
            // You will get location here if the GPS is enabled
            if(location != null) {

            	currentLocation = location;

            	if (currentLocation != null) {

            		gMap.clear();

            		fetchAddresses();
            	}
            }
        }
    };

    private Marker addMarker(LatLng latLng, String title, String address, BitmapDescriptor bitmap) {

    	// Uses a colored icon.
        return gMap.addMarker(new MarkerOptions()
                .position(latLng)
                .title(title)
                .snippet(address)
                .icon(bitmap));
    }

    private void addMarkerForMarketers() {
		addMarkersToMap();
    }

    private void addMarkersToMap() {

    	LatLngBounds.Builder builder = new LatLngBounds.Builder();

    	Marketer marketer = new Marketer();
    	marketer.setMarketerName(Labels.CURRENT_LOCATION);
    	marketer.setLattitude(String.valueOf(currentLocation.getLatitude()));
    	marketer.setLongitude(String.valueOf(currentLocation.getLongitude()));

    	String address = Labels.EMPTY;
    	BitmapDescriptor descriptor = BitmapDescriptorFactory.fromResource(R.drawable.map_marketer);

    	LatLng latLng = saveMarker(marketer, address, descriptor);

    	builder.include(latLng);

    	int length = marketers.size();
    	for (int i = 0; i < length; i++) {


    		try {

    			marketer = marketers.get(i);

    			TextIconGenerator iconFactory = new TextIconGenerator(OtherMarketersActivity.this);
				iconFactory.setStyle(TextIconGenerator.STYLE_GREEN);
				descriptor = BitmapDescriptorFactory.fromBitmap(iconFactory.makeIcon(String.valueOf(i + 1)));

				address = marketerAddressMap.get(marketer.getMarketerId());

				latLng = saveMarker(marketer, address, descriptor);

				builder.include(latLng);
    		} catch (Exception e) {
    			convertAndThrow(e, Titles.OTHER_MARKETERS_TITLE);
    		}
    	}

    	CameraUpdate cu = null;

    	cu = CameraUpdateFactory.newLatLngBounds(builder.build(), 1);

    	gMap.moveCamera(cu);

    	gMap.animateCamera(cu);
    }

    private LatLng saveMarker(Marketer marketer, String address, BitmapDescriptor descriptor) {

//    	if (Labels.EMPTY.trim().equals(marketer.getLattitude().trim()) || Labels.EMPTY.trim().equals(marketer.getLongitude().trim())) {
//    		throw new AppException(new Error(ErrorCode.UNABLE_TO_LOCATE_MARKETER, marketer.getMarketerName()));
//    	}

		Double lat = 0.0;
		Double lng = 0.0;
		if (!Labels.EMPTY.equals(marketer.getLattitude().trim())) {
			lat = Double.parseDouble(marketer.getLattitude());
		}
		if (!Labels.EMPTY.equals(marketer.getLattitude().trim())) {
			lng = Double.parseDouble(marketer.getLongitude());
		}
		LatLng latLng = new LatLng(lat, lng);
		Marker marker = addMarker(latLng,
		    			marketer.getMarketerName(),
		    			address,
		    			descriptor);
		marketerMarkersMap.put(marketer.getMarketerId(), marker);
		return latLng;
    }
    @Override
	public void OnMapAttached(Activity activity) {
	}

    private void setUpMapIfNeeded() {

    	// Do a null check to confirm that we have not already instantiated the map.
        if (gMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            gMap = mapFragment.getMap();
        }
    }

	private void setMapViewParams() {
		mapFragment.getView().getLayoutParams().width = LayoutParams.MATCH_PARENT;
		mapFragment.getView().getLayoutParams().height = LayoutParams.MATCH_PARENT;
	}

	@Override
	public void onItemClick(AdapterView<?> adapterView, View view, int position, long layout) {

		String marketerName = (((TextView) view).getText()).toString();

		if (Labels.NO_MARKETERS.equals(marketerName)) return;

		Marketer marketer = getMarketerFromName(marketerName);

		if (marketer == null) return;

		if (Labels.EMPTY.equals(marketer.getLattitude().trim()) || Labels.EMPTY.equals(marketer.getLongitude().trim())) {
			return;
		}

		LatLng latLng = new LatLng(Double.parseDouble(marketer.getLattitude()), Double.parseDouble(marketer.getLongitude()));
    	CameraUpdate cu = CameraUpdateFactory.newLatLngZoom(latLng, 14);
    	gMap.moveCamera(cu);
    	gMap.animateCamera(cu);
		marketerMarkersMap.get(marketer.getMarketerId()).showInfoWindow();

		KeyboardUtil.setImeVisibility(false, txtMarketerSearch);
	}

	private Marketer getMarketerFromName(String mName) {

		for (Marketer marketer : marketers) {
			if (marketer.getMarketerName().equals(mName)) {
				return marketer;
			}
		}

		return null;
	}

	@Override
	public void afterTextChanged(Editable s) {

		String str = s.toString();
		if (Labels.NO_MARKETERS.equals(str)) {
			txtMarketerSearch.removeTextChangedListener(this);
			txtMarketerSearch.setText(previousText);
			txtMarketerSearch.setSelection(txtMarketerSearch.getText().length());
			txtMarketerSearch.addTextChangedListener(this);
		} else {
			previousText = str;
			((OtherMarketerAdapter)txtMarketerSearch.getAdapter()).getFilter().filter(str);
		}
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
	}
}

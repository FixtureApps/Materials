/*
* @(#)LoginActivity.java
*
* Copyright (c) 2013, Liberty Tax Service.
* All rights reserved.
*
* Use is subject to license terms. This software is protected by
* copyright law and international treaties. Unauthorized reproduction or
* distribution of this program, or any portion of it, may result in severe
* civil and criminal penalties, and will be prosecuted to the maximum extent.
*/
package net.libertytax.b2b.activities;

import java.io.InputStream;
import java.util.Properties;

import net.libertytax.b2b.R;
import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.base.Constants.Titles;
import net.libertytax.b2b.base.Constants.URL;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.base.ServiceInvoker;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.model.LoginResult;
import net.libertytax.b2b.model.PayloadData;
import net.libertytax.b2b.util.B2BContext;
import net.libertytax.b2b.util.MessageUtil;
import net.libertytax.b2b.util.ModelUtil;
import net.libertytax.b2b.validator.LoginValidator;

import org.json.JSONException;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends BaseActivity
 implements OnClickListener {

	private EditText usernameText;
	private EditText passwordText;
	private Button loginButton;

	@Override
    protected void onCreate(Bundle savedInstanceState) {
		try {
			init();
			setContentView(R.layout.activity_login);
			super.onCreate(savedInstanceState);
		} catch (Exception e) {
			handleError(e, Titles.LOGIN_TITLE);
		}
    }

	@Override
	public void prepareControls() {

		usernameText = (EditText)findViewById(R.id.txtUsername);
		passwordText = (EditText)findViewById(R.id.txtPassword);
		loginButton  = (Button)findViewById(R.id.btLogin);
	}

	@Override
	public void subscribeEvents() {
		loginButton.setOnClickListener(this);
	}

	@Override
	protected void applyDefaults() {

		if (data != null) {
			usernameText.setText(data.toString());
		}
	}

	private void init() throws Exception {

		ServiceInvoker.httpContext = null;
		initializeMessageUtil(this);
	}

	private void initializeMessageUtil(Context context) throws Exception {

		if (MessageUtil.messageProperties != null) {
			return;
		}

		MessageUtil.messageProperties = new Properties();
		InputStream is = context.getAssets().open("config/Messages.properties");
		MessageUtil.messageProperties.load(is);
		is.close();
	}

	@Override
	public void onClick(View v) {

		try {

			B2BContext.getInstance().setShowProgress(true);

			initServices();
		} catch (Exception e) {
			handleError(e, Titles.LOGIN_TITLE);
		}
	}

	private ServiceInput getLoginInput(String credentials) {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setUrl(String.format(URL.LOGIN, credentials));
		input.setRequestType(RequestType.GET);
		return input;
	}

	private ServiceInput getConfigInput() {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setUrl(URL.GET_CONFIG);
		input.setRequestType(RequestType.GET);
		return input;
	}

	private ServiceInput getApproveClientInput(String content) throws JSONException {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getApproveClientInputString(content));
		input.setUrl(URL.APPROVE_CLIENT);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getApproveClientInputString(String content) throws JSONException {

		PayloadData payload = new PayloadData();
		payload.setContent(content);
		return ModelUtil.serialize(payload);
	}

	private void initServices() {

		try {

			new LoginValidator().validateLogin(usernameText.getText().toString(), passwordText.getText().toString());

			executeService(RequestCode.GET_CONFIG, false, getConfigInput());
		} catch (Exception e) {
			convertAndThrow(e, Titles.LOGIN_TITLE);
			passwordText.setText(Labels.EMPTY);
		}
	}

	@Override
	public void processOutput(ServiceResponse result, RequestCode requestCode) {

		try {
			if (RequestCode.GET_CONFIG == requestCode) {
				processGetConfigOutput(result);
			} else if (RequestCode.APPROVE_CLIENT == requestCode) {
				processApproveClientOutput(result);
			} else if (RequestCode.LOGIN == requestCode) {
				processLoginOutput(result);
			}
		} catch (Exception e) {
			convertAndThrow(e, Titles.LOGIN_TITLE);
		}
	}

	private void processGetConfigOutput(ServiceResponse result) throws Exception {

		if (result.isStatus()) {

			String configData = (String) ModelUtil.deserialize(result.getOutput(), String.class);
			InputStream is = getResources().openRawResource(R.raw.payload);
			String payLoadData = new String(ServiceInvoker.getPayloadData(is));
			String encryptedContent = ServiceInvoker.encryptData(payLoadData, configData);
			B2BContext.getInstance().setShowProgress(false);
			executeService(RequestCode.APPROVE_CLIENT, false, getApproveClientInput(encryptedContent));
		} else {
			handleError(new AppException(result.getErrors()), Titles.LOGIN_TITLE);
		}
	}

	private void processApproveClientOutput(ServiceResponse result) {

		if (result.isStatus()) {

			String credentials = "?loginId="
										+ usernameText.getText().toString()
										+ "&password="
										+ passwordText.getText().toString();
			executeService(RequestCode.LOGIN, true, getLoginInput(credentials));
		} else {
			handleError(new AppException(result.getErrors()), Titles.LOGIN_TITLE);
			passwordText.setText(Labels.EMPTY);
		}
	}

	private void processLoginOutput(ServiceResponse result) {

		if (result.isStatus()) {
			LoginResult loginResult = (LoginResult) ModelUtil.deserialize(result.getOutput(), LoginResult.class);
			B2BContext.getInstance().setLoginResult(loginResult);
			Content.getInstance().addContent(Keys.LOGIN_CONTENT, usernameText.getText().toString());
			openActivity(this, DashboardActivity.class, getBundle(Keys.LOGIN_CONTENT));
		} else {
			handleError(new AppException(result.getErrors()), Titles.LOGIN_TITLE);
			passwordText.setText(Labels.EMPTY);
		}
	}
}

package net.libertytax.b2b.activities;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.libertytax.b2b.R;
import net.libertytax.b2b.adapters.RearrangeAdapter;
import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.base.Constants.Titles;
import net.libertytax.b2b.base.Constants.URL;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.base.ServiceInvoker;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.customviews.DragSortListView;
import net.libertytax.b2b.customviews.DragSortListView.DropListener;
import net.libertytax.b2b.model.Business;
import net.libertytax.b2b.model.BusinessDetailsInput;
import net.libertytax.b2b.model.RearrangeInput;
import net.libertytax.b2b.model.RearrangeInput.RearrangeSequence;
import net.libertytax.b2b.util.B2BContext;
import net.libertytax.b2b.util.ModelUtil;
import net.libertytax.b2b.util.RearrangeController;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageButton;

import com.google.gson.reflect.TypeToken;

public class RearrangeActivity extends BaseActivity
 implements OnClickListener,
 			OnItemClickListener,
 			DropListener {

	private ImageButton imgBack;
	private ImageButton imgDone;
	private DragSortListView lstRearrange;

	private RearrangeAdapter rearrangeAdapter;
	private RearrangeController rearrangeController;
	private List<Business> businesses;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.rearrange);
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void prepareControls() {

		imgBack = (ImageButton) findViewById(R.id.imgRearrangeBack);
		imgDone = (ImageButton) findViewById(R.id.imgRearrangeDone);
		lstRearrange = (DragSortListView) findViewById(R.id.lstRearrange);
	}

	@Override
	protected void subscribeEvents() {
		imgBack.setOnClickListener(this);
		imgDone.setOnClickListener(this);
		lstRearrange.setDropListener(this);
//		lstRearrange.setDragListener(this);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void applyDefaults() {

		businesses = (List<Business>) data;
		populateList();
	}

    private RearrangeController buildController() {
    	RearrangeController controller = new RearrangeController(lstRearrange, rearrangeAdapter);
        return controller;
    }

	@Override
	public void onBackPressed() {

		try {
			goBack();
		} catch (Exception e) {
			convertAndThrow(e, Titles.REARRANGE_TITLE);
		}
	}

	private void goBack() {

		ServiceInvoker.checkNetworkAvailability();

		B2BContext.getInstance().setShowProgress(true);
		executeService(RequestCode.BUSINESS_TODAY, true, getRouteInput());
	}

	@Override
	public void processOutput(ServiceResponse result, RequestCode requestCode) {

		try {
			switch(requestCode) {
				case BUSINESS_TODAY:
					processRoutesOutput(result);
					break;
				case REARRANGE_BUSINESS:
					processRearrangeOutput(result);
					break;
			}
		} catch (Exception e) {
			convertAndThrow(e, Titles.REARRANGE_TITLE);
		}
	}

	private void processRoutesOutput(ServiceResponse result) {
		if (result.isStatus()) {
			List<Business> businesses = ModelUtil.deserializeArray(
					result.getOutput(),
					new TypeToken<List<Business>>(){}.getType());
			Content.getInstance().addContent(Keys.MY_ROUTE_CONTENT, businesses);
			Content.getInstance().addContent(Keys.FROM_REARRANGE, "dummy");
			openActivity(this, RouteActivity.class, getBundle(Keys.MY_ROUTE_CONTENT));
		} else {
			handleError(new AppException(result.getErrors()), Titles.MY_ROUTE_TITLE);
		}
	}

	private void processRearrangeOutput(ServiceResponse result) {

		if (result.isStatus()) {
			goBack();
		}
	}

	private ServiceInput getRouteInput() {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getRouteJSON());
		input.setUrl(URL.BUSINESS_DETAILS);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private ServiceInput getRearrangeInput() {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getRearrangeJSON());
		input.setUrl(URL.REARRANGE_BUSINESS);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getRouteJSON() {

		BusinessDetailsInput bdInput = new BusinessDetailsInput();
		bdInput.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());
		bdInput.setStartDate(new Date());
		bdInput.setEndDate(new Date());
		return ModelUtil.serialize(bdInput);
	}

	private String getRearrangeJSON() {

		RearrangeInput rearrangeInput = new RearrangeInput();
		rearrangeInput.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());
		rearrangeInput.setAssignmentDate(new Date());
		rearrangeInput.setAssignmentSequence(new ArrayList<RearrangeInput.RearrangeSequence>());
		RearrangeSequence rearrange = null;
		for (int i = 0; i < rearrangeAdapter.getCount(); i++) {
			rearrange = new RearrangeSequence();
			rearrange.setAssignmentId(rearrangeAdapter.getItem(i).getAssignmentId());
			rearrange.setSequenceNumber(i + 1);
			rearrangeInput.getAssignmentSequence().add(rearrange);
		}
		return ModelUtil.serialize(rearrangeInput);
	}

	private void populateList() {

		rearrangeAdapter = new RearrangeAdapter(RearrangeActivity.this, businesses);
		lstRearrange.setAdapter(rearrangeAdapter);

		rearrangeController = buildController();
        lstRearrange.setFloatViewManager(rearrangeController);
        lstRearrange.setOnTouchListener(rearrangeController);
	}

	@Override
	public void onItemClick(AdapterView<?> adapterView, View view, int arg2, long arg3) {

		switch (view.getId()) {
		case R.id.lstRearrange:
			break;
		default:
			break;
		}
	}

	@Override
	public void onClick(View v) {

		try {
			switch (v.getId()) {
			case R.id.imgRearrangeBack:
				goBack();
				break;
			case R.id.imgRearrangeDone:
				B2BContext.getInstance().setShowProgress(true);
				executeService(RequestCode.REARRANGE_BUSINESS, true, getRearrangeInput());
				break;
			default:
				break;
			}
		} catch (Exception e) {
			convertAndThrow(e, Titles.REARRANGE_TITLE);
		}
	}

	@Override
	public void drop(int from, int to) {

		if (from != to) {
            Business item = rearrangeAdapter.getItem(from);
            rearrangeAdapter.remove(item);
            rearrangeAdapter.insert(item, to);
        }
	}
}

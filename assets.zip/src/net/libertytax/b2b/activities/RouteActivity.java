package net.libertytax.b2b.activities;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import net.libertytax.b2b.R;
import net.libertytax.b2b.adapters.FilterAdapter;
import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.Misc;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.base.Constants.Titles;
import net.libertytax.b2b.base.Constants.URL;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.Error;
import net.libertytax.b2b.base.ErrorCode;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.base.ServiceInvoker;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.fragments.EmptyFragmentWithCallbackOnResume.OnFragmentAttachedListener;
import net.libertytax.b2b.fragments.HostFragment;
import net.libertytax.b2b.fragments.HostFragment.OnViewChangeListener;
import net.libertytax.b2b.fragments.TimeLineFragment;
import net.libertytax.b2b.model.Business;
import net.libertytax.b2b.model.Filter;
import net.libertytax.b2b.model.RetrieveBusinessInput;
import net.libertytax.b2b.model.TimeLine;
import net.libertytax.b2b.util.B2BContext;
import net.libertytax.b2b.util.MapUtil;
import net.libertytax.b2b.util.ModelUtil;
import net.libertytax.b2b.util.RouteUtil;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ImageButton;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.model.Marker;
import com.google.gson.reflect.TypeToken;

public class RouteActivity extends BaseActivity
	implements OnClickListener,
				OnViewChangeListener,
				OnFragmentAttachedListener,
				OnItemClickListener,
				OnInfoWindowClickListener {

	private Button btToday;
	private Button btWeek;
	private Button btMonth;
	private Button btTaxSeason;
	private Button currentSelection;
	private ImageButton imgBtRearrange;
	private ImageButton imgBtFilter;
	private ImageButton btBack;
	private TextView txtTitle;

	private HostFragment hostFragment;
	private TimeLineFragment timeLineFragment;
	private TimeLineFragment currentTimeLineFragment;

	private List<String> filters;
	private boolean isManualDismiss;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		setContentView(R.layout.route);
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void applyDefaults() {

		if (!Content.containsKey(Keys.SELECTED_TIMELINE)) {
			selectToday();
		} else {
			selectTimeline((TimeLine) Content.resolve(Keys.SELECTED_TIMELINE));
		}

		if (Content.containsKey(Keys.FROM_REARRANGE)  ||
			Content.containsKey(Keys.FROM_SHOW_ROUTE) ||
			Content.containsKey(Keys.FROM_BUSINESS_DETAIL)) {

			Content.remove(Keys.FROM_REARRANGE);
			Content.remove(Keys.FROM_SHOW_ROUTE);
			Content.remove(Keys.FROM_BUSINESS_DETAIL);
		} else {
			resetKeys();
		}
	}

	private void selectToday() {

		setSelected(btToday);
		hostFragment = getHostFragment();
		timeLineFragment = null;
		replaceFragment(R.id.linearBusiness, hostFragment);
	}
	
	private void selectWeek() {

		setSelected(btWeek);
		timeLineFragment = getTimeLineFragment(TimeLine.WEEK);
		hostFragment = null;
		replaceFragment(R.id.linearBusiness, timeLineFragment);
	}
	
	private void selectMonth() {

		setSelected(btMonth);
		timeLineFragment = getTimeLineFragment(TimeLine.MONTH);
		hostFragment = null;
		replaceFragment(R.id.linearBusiness, timeLineFragment);
	}
	
	@SuppressWarnings("unchecked")
	private void selectTaxseason(RequestCode requestCode) {

		setSelected(btTaxSeason);
		hostFragment = null;
		if (RequestCode.BUSINESS_SEASON_FROM_TAX_SEASON != requestCode) {
			currentTimeLineFragment = getTimeLineFragment(TimeLine.TAX_SEASON);
			timeLineFragment = currentTimeLineFragment;
			replaceFragment(R.id.linearBusiness, currentTimeLineFragment);
		} else {
			currentTimeLineFragment.updateList((List<Business>) data);
		}
	}

	private void selectTimeline(TimeLine timeline) {

		switch (timeline) {
		case TODAY:
			selectToday();
			break;
		case WEEK:
			selectWeek();
			break;
		case MONTH:
			selectMonth();
			break;
		case TAX_SEASON:
			selectTaxseason(RequestCode.BUSINESS_SEASON);
			break;
		default:
			break;
		}
	}

	private void resetKeys() {

		Content.getInstance().addContent(Keys.SELECTED_FILTER_TODAY, Filter.ALL);
		Content.getInstance().addContent(Keys.SELECTED_FILTER_MONTH, Filter.ALL);
		Content.getInstance().addContent(Keys.SELECTED_FILTER_WEEK, Filter.ALL);
		Content.getInstance().addContent(Keys.SELECTED_FILTER_TAX_SEASON, Filter.ALL);

		Content.remove(Keys.SELECTED_TAB_TODAY);
		Content.remove(Keys.SELECTED_TAX_SEASON);
	}

	private void setSelected(Button selectionButton) {

		if (currentSelection != null) {
			currentSelection.setCompoundDrawablesWithIntrinsicBounds(null, getDrawable(currentSelection.getId(), false), null, null);
		}
		selectionButton.setCompoundDrawablesWithIntrinsicBounds(null, getDrawable(selectionButton.getId(), true), null, null);
		currentSelection = selectionButton;
		imgBtRearrange.setVisibility((selectionButton == btToday) ? View.VISIBLE : View.GONE );
	}

	private Drawable getDrawable(int id, boolean selected) {

		int drawableId;
		switch (id) {
		case R.id.btToday:
			drawableId = selected ? R.drawable.today_selected : R.drawable.today_normal;
			break;
		case R.id.btWeek:
			drawableId = selected ? R.drawable.week_selected : R.drawable.week_normal;
			break;
		case R.id.btMonth:
			drawableId = selected ? R.drawable.month_selected : R.drawable.month_normal;
			break;
		case R.id.btTaxSeason:
			drawableId = selected ? R.drawable.tax_selected : R.drawable.tax_normal;
			break;
		default: return null;
		}

		return getResources().getDrawable(drawableId);
	}

	@Override
	protected void prepareControls() {

		btToday = (Button) findViewById(R.id.btToday);
		btWeek = (Button) findViewById(R.id.btWeek);
		btMonth = (Button) findViewById(R.id.btMonth);
		btTaxSeason = (Button) findViewById(R.id.btTaxSeason);
		imgBtRearrange = (ImageButton) findViewById(R.id.imgRearrange);
		imgBtFilter = (ImageButton) findViewById(R.id.imgFilter);
		btBack = (ImageButton) findViewById(R.id.imgBack);
		txtTitle = (TextView) findViewById(R.id.txtHeader);
	}

	@Override
	protected void subscribeEvents() {
		btToday.setOnClickListener(this);
		btWeek.setOnClickListener(this);
		btMonth.setOnClickListener(this);
		btTaxSeason.setOnClickListener(this);
		imgBtRearrange.setOnClickListener(this);
		imgBtFilter.setOnClickListener(this);
		btBack.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {

		try {
			switch (v.getId()) {
			case R.id.btToday:
				B2BContext.getInstance().setShowProgress(true);
				executeService(RequestCode.BUSINESS_TODAY, true, RouteUtil.getRouteInput(TimeLine.TODAY, 0));
				break;
			case R.id.btWeek:
				B2BContext.getInstance().setShowProgress(true);
				executeService(RequestCode.BUSINESS_WEEK, true, RouteUtil.getRouteInput(TimeLine.WEEK, 0));
				break;
			case R.id.btMonth:
				B2BContext.getInstance().setShowProgress(true);
				executeService(RequestCode.BUSINESS_MONTH, true, RouteUtil.getRouteInput(TimeLine.MONTH, 0));
				break;
			case R.id.btTaxSeason:
				int month = 0;
				if (!Content.containsKey(Keys.SELECTED_TAX_SEASON)) {
					month = Calendar.JANUARY;
				} else {
					Button button = (Button) Content.resolve(Keys.SELECTED_TAX_SEASON);
					month = getMonth(button);
				}
				B2BContext.getInstance().setShowProgress(true);
				executeService(RequestCode.BUSINESS_SEASON, true, RouteUtil.getRouteInput(TimeLine.TAX_SEASON, month));
				break;
			case R.id.imgRearrange:
				if (Filter.ALL != ((Filter) Content.resolve(Keys.SELECTED_FILTER_TODAY))) {
					throw new AppException(new Error(ErrorCode.REARRANGE_FAILED));
				}
				Content.getInstance().addContent(Keys.REARRANGE_CONTENT, data);
				openActivity(RouteActivity.this, RearrangeActivity.class, getBundle(Keys.REARRANGE_CONTENT));
				break;
			case R.id.imgFilter:
				showFilter();
				break;
			case R.id.imgBack:
				goBack();
				break;
			}
		} catch (Exception e) {
			convertAndThrow(e, Titles.MY_ROUTE_TITLE);
		}
	}

	private ServiceInput getBusinessDetailsInput(Business business) {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getBusinessDetailsJSON(business));
		input.setUrl(URL.RETRIEVE_BUSSINESS_DETAIL);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getBusinessDetailsJSON(Business business) {

		RetrieveBusinessInput bdInput = new RetrieveBusinessInput();
		bdInput.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());
		bdInput.setAssignmentId(business.getAssignmentId());
		bdInput.setBusinessId(business.getBusinessId());
		return ModelUtil.serialize(bdInput);
	}

	private int getMonth(Button monthButton) {

		switch (monthButton.getId()) {
		case R.id.imgBtJan: return Calendar.JANUARY;
		case R.id.imgBtFeb: return Calendar.FEBRUARY;
		case R.id.imgBtMar: return Calendar.MARCH;
		case R.id.imgBtApr: return Calendar.APRIL;
		case R.id.imgBtMay: return Calendar.MAY;
		default: return Calendar.JANUARY;
		}
	}

	@Override
	public void processOutput(ServiceResponse result, RequestCode requestCode) {

		try {
			switch (requestCode) {
			case BUSINESS_TODAY:
				processTodayOutput(result);
				break;
			case BUSINESS_WEEK:
				processWeekOutput(result);
				break;
			case BUSINESS_MONTH:
				processMonthOutput(result);
				break;
			case BUSINESS_SEASON:
				processTaxSeasonOutput(result, requestCode);
				break;
			case BUSINESS_SEASON_FROM_TAX_SEASON:
				processTaxSeasonOutput(result, requestCode);
				break;
			case GOOGLE_MAP_ROAD_SERVICES:
				hostFragment.onRouteFetching(result);
				break;
			case GOOGLE_MAP_ROAD_SERVICES_LAST:
				hostFragment.onRouteFetched(result);
				break;
			case GOOGLE_SPLIT_ROAD_SERVICES:
				hostFragment.onSplitRouteFetching(result);
				break;
			case GOOGLE_SPLIT_ROAD_SERVICES_LAST:
				hostFragment.onSplitRouteFetched(result);
				break;
			case RETRIEVE_BUSINESS_DETAILS:
				processRetrieveBusinessOutput(result);
				break;
			default:
				break;
			}
		} catch (Exception e) {
			convertAndThrow(e, Titles.MY_ROUTE_TITLE);
			mapLoaded();
			if (hostFragment != null) {
				hostFragment.mapLoaded();
			}
		}
	}

	@Override
	public void onBackPressed() {
		try {
			goBack();
		} catch (Exception e) {
			convertAndThrow(e, Titles.MY_ROUTE_TITLE);
		}
	}

	private void goBack() {
		ServiceInvoker.checkNetworkAvailability();
		showProgress(RouteActivity.this, Labels.EMPTY, Misc.KEY_LOADING);
		openActivity(RouteActivity.this, DashboardActivity.class, null);
	}

	@SuppressWarnings("deprecation")
	private void showFilter() {

		View layout = LayoutInflater.from(this).inflate(R.layout.filter_list, null);

		PopupWindow popupWindow = new PopupWindow(this);
		popupWindow.setContentView(layout);
		popupWindow.setWidth(LayoutParams.WRAP_CONTENT);
		popupWindow.setHeight(LayoutParams.WRAP_CONTENT);
		popupWindow.setFocusable(true);
		popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {

			@Override
			public void onDismiss() {

				Filter filter = (Filter) Content.resolve(getFilterKey());
				if (filter == Filter.CLOSEST) {
					showProgress(RouteActivity.this, Labels.EMPTY, Misc.KEY_LOADING);
					MapUtil.getCurrentLocation(RouteActivity.this);
				} else {
					refreshFragmentsWithFilter(filter, null);
				}

				if (Filter.ALL == filter) {
					imgBtRearrange.setVisibility(View.VISIBLE);
				} else {
					imgBtRearrange.setVisibility(View.GONE);
				}
			}
		});

		if (filters == null) {
	        filters = new ArrayList<String>();
	        filters.add(Labels.ALL);
	        filters.add(Labels.COMPLETED);
	        filters.add(Labels.IN_PROGRESS);
		} else {
			filters.remove(3);
		}
		if (currentSelection == btToday) {
			filters.add(Labels.CLOSEST);
		} else {
			filters.add(Labels.IN_COMPLETE);
		}

        FilterAdapter adapter = new FilterAdapter(RouteActivity.this, filters);
    	adapter.setSelected(((Filter)Content.resolve(getFilterKey())).toString());
        ListView list = (ListView) popupWindow.getContentView().findViewById(R.id.listFilter);
        list.setOnItemClickListener(this);
        list.setAdapter(adapter);
        list.setTag(R.string.filter_dialog_key, popupWindow);

		popupWindow.showAtLocation(layout, Gravity.NO_GRAVITY,
				getWindowManager().getDefaultDisplay().getWidth() - 30, 65);
	}

	public void setTitle(Filter filter) {

		String title = Labels.EMPTY;
		switch (filter) {
		case CLOSEST:
			title = Labels.CLOSEST;
			break;
		case INCOMPLETE:
			title = Labels.IN_COMPLETE;
			break;
		case INPROGRESS:
			title = Labels.IN_PROGRESS;
			break;
		case COMPLETED:
			title = Labels.COMPLETED;
			break;
		default:
			title = Labels.MY_ROUTE;
			break;
		}
		txtTitle.setText(title);
	}

	@Override
	public void currentLocationFromUtil(Location location) {
		refreshFragmentsWithFilter(Filter.CLOSEST, location);
		dismissProgress();
	}

	private void refreshFragmentsWithFilter(Filter filter, Location currentLocation) {

		if (hostFragment == null) {
			timeLineFragment.refreshTimeLines(currentLocation);
		} else {
			hostFragment.refreshHost(currentLocation);
		}

		if (isManualDismiss) {
			Toast.makeText(RouteActivity.this,
							String.format(Labels.FILTER_TOAST, getStringFromFilter(filter)),
							Toast.LENGTH_SHORT)
							.show();
			isManualDismiss = false;
		}
	}

	private void processTodayOutput(ServiceResponse result) {

		if (result.isStatus()) {
			data = ModelUtil.deserializeArray(result.getOutput(),
					new TypeToken<List<Business>>() {}.getType());
			selectToday();
		} else {
			handleError(new AppException(result.getErrors()), Titles.MY_ROUTE_TITLE);
		}
	}

	private void processWeekOutput(ServiceResponse result) {

		if (result.isStatus()) {
			data = ModelUtil.deserializeArray(result.getOutput(),
					new TypeToken<List<Business>>() {}.getType());
			selectWeek();
		} else {
			handleError(new AppException(result.getErrors()), Titles.MY_ROUTE_TITLE);
		}
	}

	private void processMonthOutput(ServiceResponse result) {

		if (result.isStatus()) {
			data = ModelUtil.deserializeArray(result.getOutput(),
					new TypeToken<List<Business>>() {}.getType());
			selectMonth();
		} else {
			handleError(new AppException(result.getErrors()), Titles.MY_ROUTE_TITLE);
		}
	}

	private void processTaxSeasonOutput(ServiceResponse result, RequestCode requestCode) {

		if (result.isStatus()) {
			data = ModelUtil.deserializeArray(result.getOutput(),
					new TypeToken<List<Business>>() {}.getType());
			selectTaxseason(requestCode);
		} else {
			handleError(new AppException(result.getErrors()), Titles.MY_ROUTE_TITLE);
		}
	}

	private void processRetrieveBusinessOutput(ServiceResponse result) {

		if (result.isStatus()) {
			if (hostFragment != null) hostFragment.navigateToDetailActivity(result);
			if (timeLineFragment != null) timeLineFragment.navigateToDetailActivity(result);
		} else {
			handleError(new AppException(result.getErrors()), Titles.MY_ROUTE_TITLE);
		}
	}

	@Override
	public void viewChanged(boolean canShowButtons) {

		setButtonsEnabled(false);
		if (canShowButtons) {
//			imgBtRearrange.setVisibility(View.VISIBLE);
//			lnrButtons.setVisibility(View.VISIBLE);
		} else {
//			imgBtRearrange.setVisibility(View.GONE);
//			lnrButtons.setVisibility(View.GONE);
		}
	}

	private TimeLineFragment getTimeLineFragment(TimeLine timeLine) {

		TimeLineFragment timeLineFragment = new TimeLineFragment();
		timeLineFragment.setTimeLine(timeLine);
		return timeLineFragment;
	}

	private HostFragment getHostFragment() {

		HostFragment hostFragment = new HostFragment();
		hostFragment.setListener(this);
		return hostFragment;
	}

	@Override
	public void OnFragmentAttached() {
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long arg3) {

		ListView list = (ListView) parent;

		CheckedTextView txtView = null;
		for (int i = 0; i < list.getChildCount(); i++) {

			txtView = (CheckedTextView) list.getChildAt(i);
			txtView.setChecked(false);
		}

		txtView = (CheckedTextView) view;
		txtView.setChecked(true);
		Content.getInstance().addContent(getFilterKey(), getFilter(txtView.getText().toString()));

		PopupWindow popUp = (PopupWindow) list.getTag(R.string.filter_dialog_key);
		isManualDismiss = true;
		popUp.dismiss();
	}

	private String getFilterKey() {

		if (currentSelection == btToday) return Keys.SELECTED_FILTER_TODAY;
		if (currentSelection == btWeek) return Keys.SELECTED_FILTER_WEEK;
		if (currentSelection == btMonth) return Keys.SELECTED_FILTER_MONTH;
		if (currentSelection == btTaxSeason) return Keys.SELECTED_FILTER_TAX_SEASON;

		return null;
	}

	private Filter getFilter(String filter) {

		if (Labels.COMPLETED.equals(filter)) return Filter.COMPLETED;
		if (Labels.IN_PROGRESS.equals(filter)) return Filter.INPROGRESS;
		if (Labels.IN_COMPLETE.equals(filter)) return Filter.INCOMPLETE;
		if (Labels.CLOSEST.equals(filter)) return Filter.CLOSEST;
		return Filter.ALL;
	}

	private String getStringFromFilter(Filter filter) {

		switch (filter) {
		case COMPLETED: return Labels.COMPLETED;
		case INPROGRESS: return Labels.IN_PROGRESS;
		case INCOMPLETE: return Labels.IN_COMPLETE;
		case CLOSEST: return Labels.CLOSEST;
		default: return Labels.ALL;
		}
	}

	private void setButtonsEnabled(boolean enabled) {
		btToday.setEnabled(enabled);
		btWeek.setEnabled(enabled);
		btMonth.setEnabled(enabled);
		btTaxSeason.setEnabled(enabled);
	}

	public void mapLoaded() {
		setButtonsEnabled(true);
	}

	@Override
	public void onInfoWindowClick(Marker marker) {

		Business selectedBusiness = (Business) ModelUtil.deserialize(marker.getSnippet(), Business.class);
		executeService(RequestCode.RETRIEVE_BUSINESS_DETAILS_FROM_MAP, true, getBusinessDetailsInput(selectedBusiness));
	}
}

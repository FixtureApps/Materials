
package net.libertytax.b2b.activities;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import net.libertytax.b2b.R;
import net.libertytax.b2b.adapters.BusinessDetailsAdapter;
import net.libertytax.b2b.adapters.FeedbackAdapter;
import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.Misc;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.base.Constants.Titles;
import net.libertytax.b2b.base.Constants.URL;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.ErrorCode;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.base.ServiceInvoker;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.model.Business;
import net.libertytax.b2b.model.BusinessDetail;
import net.libertytax.b2b.model.BusinessDetailViewModel;
import net.libertytax.b2b.model.CompleteAssignment;
import net.libertytax.b2b.model.ContactDetail;
import net.libertytax.b2b.model.Coupon;
import net.libertytax.b2b.model.DetailDisplay;
import net.libertytax.b2b.model.DetailDisplay.DetailConst;
import net.libertytax.b2b.model.DetailDisplay.ViewType;
import net.libertytax.b2b.model.Feedback;
import net.libertytax.b2b.model.Item;
import net.libertytax.b2b.model.Note;
import net.libertytax.b2b.model.RetrieveBusinessInput;
import net.libertytax.b2b.model.TimeLine;
import net.libertytax.b2b.util.B2BContext;
import net.libertytax.b2b.util.ModelUtil;
import net.libertytax.b2b.util.RouteUtil;
import net.libertytax.b2b.validator.BusinessDetailValidator;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;

public class BusinessDetailActivity extends BaseActivity
				implements OnClickListener,
						   OnItemClickListener {

	private ImageButton btBack;
	private TextView txtHeader;
	private ImageButton btPrevious;
	private ImageButton btNext;
	private ListView lstBusinessDetails;
	private RatingBar ratingBar;
	private TextView txtStatus;
	private RelativeLayout relStatus;

	private BusinessDetailViewModel bDetailViewModel;
	private int ctSelectedIndex;
	private List<String> feedbacks;
	private boolean feedbackDone;
	private List<DetailDisplay> detailDisplayModels;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.business_detail);
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void prepareControls() {
		btBack = (ImageButton) findViewById(R.id.imgDetailsBack);
		txtHeader = (TextView) findViewById(R.id.txtDetailsHeader);
		btPrevious = (ImageButton) findViewById(R.id.imgDetailsPrevious);
		btNext = (ImageButton) findViewById(R.id.imgDetailsNext);
		lstBusinessDetails = (ListView) findViewById(R.id.lstBusinessDetails);
		ratingBar = (RatingBar) findViewById(R.id.ratingBusiness);
		txtStatus = (TextView) findViewById(R.id.txtViewPending);
		relStatus = (RelativeLayout) findViewById(R.id.relStatus);
	}

	@Override
	protected void subscribeEvents() {
		btBack.setOnClickListener(this);
		btPrevious.setOnClickListener(this);
		btNext.setOnClickListener(this);
		lstBusinessDetails.setOnItemClickListener(this);
	}

	@Override
	protected void applyDefaults() {

		if (Content.containsKey(Keys.FROM_CONTACT_DETAILS_KEY)) {
			Content.remove(Keys.FROM_CONTACT_DETAILS_KEY);
		} else {
			clearCache();
		}
		showPreviousNext();

		bDetailViewModel = (BusinessDetailViewModel) data;
		setBusinessDetails();
	}

	private void setBusinessDetails() {

		manageHeaderLayout();
		populateHeaderDetails();
		populateDetails();
		populateFooterDetails();
		scrollToPosition();
	}

	private void manageHeaderLayout() {

		btPrevious.setEnabled(true);
		btNext.setEnabled(true);
		if (bDetailViewModel.getSelectedIndex() == 0) {
			btPrevious.setEnabled(false);
		}
		if (bDetailViewModel.getSelectedIndex() == (getTotalBusiness() - 1)) {
			btNext.setEnabled(false);
		}
	}

	private void populateHeaderDetails() {

		NumberFormat format = NumberFormat.getInstance();
		format.setMinimumIntegerDigits(2);

		txtHeader.setText(
				format.format(bDetailViewModel.getSelectedIndex() + 1) +
				" of " +
				format.format(getTotalBusiness()));
	}

	private void populateFooterDetails() {

		ratingBar.setRating(bDetailViewModel.getSelectedBusiness().getRatings());

		String status = bDetailViewModel.getSelectedBusiness().getStatus();
		txtStatus.setText(status);
		if (Labels.COMPLETED.equals(status)) {
			relStatus.setBackgroundColor(getResources().getColor(R.color.details_completed_BG));
		} else {
			relStatus.setBackgroundColor(getResources().getColor(R.color.details_pending_BG));
		}
	}

	private void scrollToPosition() {

		if (!Content.containsKey(Keys.FROM_ADD_NOTE)) return;

		Content.remove(Keys.FROM_ADD_NOTE);
		int noteIndex = -1;
		for (int i = 0; i < detailDisplayModels.size(); i++) {
			if (detailDisplayModels.get(i).getViewType() == ViewType.NOTE) {
				noteIndex = i;
				break;
			}
		}

		lstBusinessDetails.setSelectionFromTop(noteIndex, 0);
	}

	private void populateDetails() {

		detailDisplayModels = prepareDisplayModels();

		BusinessDetailsAdapter adapter = new BusinessDetailsAdapter(BusinessDetailActivity.this, detailDisplayModels);
		lstBusinessDetails.setAdapter(adapter);
	}

	private List<DetailDisplay> prepareDisplayModels() {

		List<DetailDisplay> models = new ArrayList<DetailDisplay>();

		boolean completed = Labels.COMPLETED.equals(bDetailViewModel.getSelectedBusiness().getStatus());

		addHeader(models, ViewType.HEADER, DetailConst.DETAIL_HEADER_VALUE);
		addBusinessDetails(models, ViewType.BUSINESS_DETAIL);
		addEmptyView(models, ViewType.EMPTY);
		addHeader(models, ViewType.HEADER, Labels.BUSINESS_DETAIL_ADD_CONTACT, DetailConst.CONTACT_HEADER_VALUE, completed);
		addContactDetails(models, ViewType.CONTACT_DETAIL);
		addEmptyView(models, ViewType.EMPTY);
		addHeader(models, ViewType.HEADER, DetailConst.ITEM_HEADER_VALUE);
		addItemDetails(models, ViewType.ITEM);
		addEmptyView(models, ViewType.EMPTY);
		addHeader(models, ViewType.HEADER, DetailConst.COUPON_HEADER_VALUE);
		addCouponDetails(models, ViewType.COUPON);
		addEmptyView(models, ViewType.EMPTY);
		addHeader(models, ViewType.HEADER, DetailConst.FEEDBACK_HEADER_VALUE);
		addFeedbackDetails(models, ViewType.FEEDBACK);
		addEmptyView(models, ViewType.EMPTY);
		addHeader(models, ViewType.HEADER, Labels.BUSINESS_DETAIL_ADD_NOTE, DetailConst.NOTES_HEADER_VALUE, false);
		addNoteDetails(models, ViewType.NOTE);
		addEmptyView(models, ViewType.EMPTY);

		if (!completed) {
			addHeader(models, ViewType.HEADER, DetailConst.EMPTY_HEADER_VALUE);
			addDelivered(models, ViewType.DELIVERED);
			addEmptyView(models, ViewType.EMPTY);
//			addHeader(models, ViewType.HEADER, DetailConst.EMPTY_HEADER_VALUE);
//			addRating(models, ViewType.RATING);
		}

		return models;
	}

	private void addEmptyView(List<DetailDisplay> dd, ViewType type) {

		DetailDisplay detailDisplay = new DetailDisplay();
		detailDisplay.setLayoutId(getLayoutId(type));
		detailDisplay.setViewType(type);
		dd.add(detailDisplay);
	}

	private DetailDisplay addHeader(ViewType type, String headerValue) {

		DetailDisplay detailDisplay = new DetailDisplay();
		detailDisplay.setLayoutId(getLayoutId(type));
		detailDisplay.setViewType(type);
		detailDisplay.getValuesMap().put(DetailConst.HEADER_KEY, headerValue);
		return detailDisplay;
	}

	private void addHeader(List<DetailDisplay> models, ViewType type, String headerValue) {

		DetailDisplay detailDisplay = addHeader(type, headerValue);
		models.add(detailDisplay);
	}

	private void addHeader(List<DetailDisplay> models, ViewType type, String add, String headerValue, boolean completed) {

		DetailDisplay detailDisplay = addHeader(type, headerValue);
		if (add != null && !completed) {
			detailDisplay.getValuesMap().put(DetailConst.HEADER_ADD_KEY, add);
		}
		models.add(detailDisplay);
	}

	private void addBusinessDetails(List<DetailDisplay> models, ViewType type) {

		DetailDisplay detailDisplay = new DetailDisplay();
		detailDisplay.setLayoutId(getLayoutId(type));
		detailDisplay.setViewType(type);
		detailDisplay.getValuesMap().put(DetailConst.BUSINESS_DETAIL_KEY, DetailConst.BUSINESS_NAME);
		detailDisplay.getValuesMap().put(DetailConst.BUSINESS_DETAIL_VALUE, bDetailViewModel.getSelectedBusiness().getBusinessName());
		models.add(detailDisplay);

		detailDisplay = new DetailDisplay();
		detailDisplay.setLayoutId(getLayoutId(type));
		detailDisplay.setViewType(type);
		detailDisplay.getValuesMap().put(DetailConst.BUSINESS_DETAIL_KEY, DetailConst.BUSINESS_ADDRESS);
		detailDisplay.getValuesMap().put(DetailConst.BUSINESS_DETAIL_VALUE, bDetailViewModel.getSelectedBusiness().getAddress());
		detailDisplay.getValuesMap().put(DetailConst.BUSINESS_DETAIL_ADDRESS, "dummy");
		detailDisplay.getValuesMap().put(DetailConst.SHOW_DIVIDER, false);
		detailDisplay.setViewId(Misc.ADDRESS_VIEW_ID);
		models.add(detailDisplay);
	}

	private void addContactDetails(List<DetailDisplay> models, ViewType type) {

		List<ContactDetail> cDetails = bDetailViewModel.getSelectedBusiness().getBusinessContactDetails();
		for (int i = 0; i < cDetails.size(); i++) {
			DetailDisplay detailDisplay = new DetailDisplay();
			detailDisplay.setLayoutId(getLayoutId(type));
			detailDisplay.setViewType(type);
			detailDisplay.getValuesMap().put(DetailConst.CONTACT_DETAIL_TEXT1, cDetails.get(i).getDesignation());
			detailDisplay.getValuesMap().put(DetailConst.CONTACT_DETAIL_TEXT2, cDetails.get(i).getContactPerson());
			detailDisplay.getValuesMap().put(DetailConst.CONTACT_DETAIL_TAG, cDetails.get(i));
			detailDisplay.setViewId(Misc.CONTACT_VIEW_ID);
			if (i == cDetails.size() - 1) {
				detailDisplay.getValuesMap().put(DetailConst.SHOW_DIVIDER, false);
			}
			models.add(detailDisplay);
		}
	}

	private void addItemDetails(List<DetailDisplay> models, ViewType type) {

		boolean completed = Labels.COMPLETED.equals(bDetailViewModel.getSelectedBusiness().getStatus());

		List<Item> items = bDetailViewModel.getSelectedBusiness().getItems();
		for (int i = 0; i < items.size(); i++) {

			Item item = getItemFromCache(items.get(i));
			DetailDisplay detailDisplay = new DetailDisplay();
			detailDisplay.setLayoutId(getLayoutId(type));
			detailDisplay.setViewType(type);
			detailDisplay.getValuesMap().put(DetailConst.ITEM_NAME, item.getItemName());
			detailDisplay.getValuesMap().put(DetailConst.ITEM_COUNT, item.getItemCount());
			detailDisplay.getValuesMap().put(DetailConst.ITEM_KEY, item);
			detailDisplay.getValuesMap().put(DetailConst.ITEM_STATUS, completed);
			if (i == items.size() - 1) {
				detailDisplay.getValuesMap().put(DetailConst.SHOW_DIVIDER, false);
			}
			models.add(detailDisplay);
		}
	}

	private void addCouponDetails(List<DetailDisplay> models, ViewType type) {

		boolean completed = Labels.COMPLETED.equals(bDetailViewModel.getSelectedBusiness().getStatus());

		List<Coupon> coupons = bDetailViewModel.getSelectedBusiness().getCoupons();
		for (int i = 0; i < coupons.size(); i++) {

			Coupon coupon = getCouponFromCache(coupons.get(i));
			DetailDisplay detailDisplay = new DetailDisplay();
			detailDisplay.setLayoutId(getLayoutId(type));
			detailDisplay.setViewType(type);
			detailDisplay.getValuesMap().put(DetailConst.COUPON_NAME, coupon.getCouponName());
			detailDisplay.getValuesMap().put(DetailConst.COUPON_COUNT, coupon.getCouponCount());
			detailDisplay.getValuesMap().put(DetailConst.COUPON_KEY, coupon);
			detailDisplay.getValuesMap().put(DetailConst.COUPON_STATUS, completed);
			if (i == coupons.size() - 1) {
				detailDisplay.getValuesMap().put(DetailConst.SHOW_DIVIDER, false);
			}
			models.add(detailDisplay);
		}
	}

	private void addFeedbackDetails(List<DetailDisplay> models, ViewType type) {

		boolean completed = Labels.COMPLETED.equals(bDetailViewModel.getSelectedBusiness().getStatus());

		DetailDisplay detailDisplay = new DetailDisplay();
		detailDisplay.setLayoutId(getLayoutId(type));
		detailDisplay.setViewType(type);
		String feedback = getFeedbackFromCache(bDetailViewModel.getSelectedBusiness().getFeedback());
		feedback = (feedback == null || Labels.EMPTY.equals(feedback.toString()))
				? Labels.SELECT_FEEDBACK : feedback;
		detailDisplay.getValuesMap().put(DetailConst.FEEDBACK_VALUE, feedback);
		detailDisplay.getValuesMap().put(DetailConst.FEEDBACK_STATUS, completed);
		detailDisplay.getValuesMap().put(DetailConst.SHOW_DIVIDER, false);
		models.add(detailDisplay);
	}

	private void addNoteDetails(List<DetailDisplay> models, ViewType type) {

		List<Note> notes = bDetailViewModel.getSelectedBusiness().getNotes();
		for (int i = 0; i < notes.size(); i++) {
			DetailDisplay detailDisplay = new DetailDisplay();
			detailDisplay.setLayoutId(getLayoutId(type));
			detailDisplay.setViewType(type);
			detailDisplay.getValuesMap().put(DetailConst.NOTE_VALUE, notes.get(i));
			if (i == notes.size() - 1) {
				detailDisplay.getValuesMap().put(DetailConst.SHOW_DIVIDER, false);
			}
			models.add(detailDisplay);
		}
		if (notes.size() == 0) {
			DetailDisplay detailDisplay = new DetailDisplay();
			detailDisplay.setLayoutId(getLayoutId(type));
			detailDisplay.setViewType(type);
			Note note = new Note();
			note.setDescription(DetailConst.NO_NOTES_VALUE);
			detailDisplay.getValuesMap().put(DetailConst.NOTE_VALUE, note);
			detailDisplay.getValuesMap().put(DetailConst.SHOW_DIVIDER, false);
			models.add(detailDisplay);
		}
	}

	private void addDelivered(List<DetailDisplay> models, ViewType type) {

		DetailDisplay detailDisplay = new DetailDisplay();
		detailDisplay.setViewType(type);
		detailDisplay.setLayoutId(getLayoutId(type));
		detailDisplay.getValuesMap().put(DetailConst.SHOW_DIVIDER, false);
		models.add(detailDisplay);
	}
//
//	private void addRating(List<DetailDisplay> models, ViewType type) {
//
//		DetailDisplay detailDisplay = new DetailDisplay();
//		detailDisplay.setLayoutId(getLayoutId(type));
//		detailDisplay.setViewType(type);
//		int ratings = bDetailViewModel.getSelectedBusiness().getRatings();
//		String status = bDetailViewModel.getSelectedBusiness().getStatus();
//		detailDisplay.getValuesMap().put(DetailConst.RATING_VALUE, ratings);
//		detailDisplay.getValuesMap().put(DetailConst.STATUS_VALUE, status);
//		models.add(detailDisplay);
//	}

	private int getLayoutId(ViewType type) {

		switch (type) {
		case HEADER: return R.layout.business_detail_header;
		case BUSINESS_DETAIL: return R.layout.business_detail_business_detail;
		case CONTACT_DETAIL: return R.layout.business_detail_contact_detail;
		case ITEM: return R.layout.business_detail_item;
		case COUPON: return R.layout.business_detail_item;
		case FEEDBACK: return R.layout.business_detail_feedback;
		case NOTE: return R.layout.business_detail_note;
		case DELIVERED: return R.layout.business_detail_delivered;
		case RATING: return R.layout.business_detail_rating;
		case EMPTY: return R.layout.empty_view;
		default: return 0;
		}
	}

	@Override
	public void onBackPressed() {

		try {
			goBack();
		} catch (Exception e) {
			convertAndThrow(e, Titles.BUSINESS_DETAILS_TITLE);
		}
	}

	@Override
	public void onClick(View v) {

		try {
			switch (v.getId()) {
			case R.id.imgDetailsBack:
				goBack();
				break;
			case R.id.imgDetailsPrevious:
				goToPreviousBusiness();
				break;
			case R.id.imgDetailsNext:
				goToNextBusiness();
				break;
			case R.id.txtSectionAdd:
				addDetails((String) v.getTag());
				break;
			case R.id.imgContactSectionPhone:
				invokePhone((ContactDetail) v.getTag());
				break;
			case R.id.imgItemSectionPositive:
				addCount(v.getTag());
				break;
			case R.id.imgItemSectionNegative:
				removeCount(v.getTag());
				break;
			case R.id.btDelivered:
				completeAssignment();
				break;
			case R.id.relFeedback:
				openFeedbackPopup();
				break;
			case R.id.btFeedbackDone:
				closeFeedback(v, true);
				break;
			case R.id.btFeedbackCancel:
				closeFeedback(v, false);
				break;
			default:
				break;
			}
		} catch (Exception e) {
			ctSelectedIndex = bDetailViewModel.getSelectedIndex();
			convertAndThrow(e, Titles.BUSINESS_DETAILS_TITLE);
		}
	}

	private void completeAssignment() {

		CompleteAssignment cAssignment = collectDatas();
		new BusinessDetailValidator().validateCompleteAssignment(cAssignment);
		saveAssignment(cAssignment);
	}

	private void openFeedbackPopup() {

		View layout = LayoutInflater.from(this).inflate(R.layout.feedback_list, null);

		PopupWindow popupWindow = new PopupWindow(this);
		popupWindow.setContentView(layout);
		popupWindow.setWidth(LayoutParams.WRAP_CONTENT);
		popupWindow.setHeight(LayoutParams.WRAP_CONTENT);
		popupWindow.setFocusable(true);
		popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {

			@Override
			public void onDismiss() {

				if (!feedbackDone) {
					removeFeedbackKeys();
					return;
				}

				if (!Content.containsKey(Keys.SELECTED_FEEDBACK)) return;

				Feedback feedback = (Feedback) Content.resolve(Keys.SELECTED_FEEDBACK);
				bDetailViewModel.getSelectedBusiness().setFeedback(getFeedbackString(feedback));
				BusinessDetailsAdapter adapter = (BusinessDetailsAdapter) lstBusinessDetails.getAdapter();
				adapter.updateFeedback(getFeedbackString(feedback));
				maintainFeedbackCache(feedback);
				removeFeedbackKeys();
			}
		});

		if (feedbacks == null) {
			feedbacks = new ArrayList<String>();
			feedbacks.add(Labels.GOOD);
			feedbacks.add(Labels.FAIR);
			feedbacks.add(Labels.BAD);
		}

		FeedbackAdapter adapter = new FeedbackAdapter(BusinessDetailActivity.this, feedbacks);
		adapter.setSelected(bDetailViewModel.getSelectedBusiness().getFeedback());

		ListView list = (ListView) popupWindow.getContentView().findViewById(R.id.listFeedback);
	    list.setOnItemClickListener(this);
	    list.setAdapter(adapter);
	    list.setTag(R.string.feedback_dialog_key, popupWindow);

	    Button btDone = (Button) popupWindow.getContentView().findViewById(R.id.btFeedbackDone);
	    Button btCancel = (Button) popupWindow.getContentView().findViewById(R.id.btFeedbackCancel);

	    btDone.setTag(R.string.feedback_dialog_key, popupWindow);
	    btCancel.setTag(R.string.feedback_dialog_key, popupWindow);

	    btDone.setOnClickListener(this);
	    btCancel.setOnClickListener(this);

	    popupWindow.showAtLocation(layout, Gravity.CENTER, 0, 0);
	}

	private void removeFeedbackKeys() {
		if (Content.containsKey(Keys.SELECTED_FEEDBACK)) Content.remove(Keys.SELECTED_FEEDBACK);
		if (Content.containsKey(Keys.TEMP_SELECTED_FEEDBACK)) Content.remove(Keys.TEMP_SELECTED_FEEDBACK);
	}

	private void closeFeedback(View view, boolean fromDone) {

		feedbackDone = fromDone;
		if (fromDone) {
			if (!Content.containsKey(Keys.TEMP_SELECTED_FEEDBACK)) {
				throw new AppException(new net.libertytax.b2b.base.Error(ErrorCode.NO_FEEDBACK_SELECTED));
			}
			Feedback feedback = (Feedback) Content.resolve(Keys.TEMP_SELECTED_FEEDBACK);
			Content.getInstance().addContent(Keys.SELECTED_FEEDBACK, feedback);
		}
		PopupWindow popup = (PopupWindow) (((Button) view).getTag(R.string.feedback_dialog_key));
		popup.dismiss();
	}

	private void addCount(Object item) {

		BusinessDetailsAdapter adapter = (BusinessDetailsAdapter) lstBusinessDetails.getAdapter();
		int count = 0;
		if (item instanceof Item) {
			Item i = (Item) item;
			count = i.getItemCount();
			i.setItemCount(++count);
			maintainItemCache(i);
			adapter.updateItem(i);
		} else if (item instanceof Coupon) {
			Coupon c = (Coupon) item;
			count = c.getCouponCount();
			c.setCouponCount(++count);
			maintainCouponCache(c);
			adapter.updateCoupon(c);
		}
	}

	private void removeCount(Object item) {

		BusinessDetailsAdapter adapter = (BusinessDetailsAdapter) lstBusinessDetails.getAdapter();
		int count = 0;
		if (item instanceof Item) {
			Item i = (Item) item;
			count = i.getItemCount();
			if (count == 0) return;
			i.setItemCount(--count);
			maintainItemCache(i);
			adapter.updateItem(i);
		} else if (item instanceof Coupon) {
			Coupon c = (Coupon) item;
			count = c.getCouponCount();
			if (count == 0) return;
			c.setCouponCount(--count);
			maintainCouponCache(c);
			adapter.updateCoupon(c);
		}
	}

	private void clearCache() {

		Content.remove(Keys.ITEM_CACHE);
		Content.remove(Keys.COUPON_CACHE);
		Content.remove(Keys.FEEDBACK_CACHE);
	}

	private void showPreviousNext() {

		TimeLine timeLine = (TimeLine) Content.resolve(Keys.SELECTED_TIMELINE);
		boolean canShow = (TimeLine.TODAY == timeLine);

		btPrevious.setVisibility(canShow ? View.VISIBLE : View.GONE);
		btNext.setVisibility(canShow ? View.VISIBLE : View.GONE);
	}

	@SuppressWarnings("unchecked")
	private void maintainFeedbackCache(Feedback feedback) {

		Map<String, Feedback> feedbackCache = null;
		if (!Content.containsKey(Keys.FEEDBACK_CACHE)) {
			feedbackCache = new HashMap<String, Feedback>();
		} else {
			feedbackCache = (Map<String, Feedback>) Content.resolve(Keys.FEEDBACK_CACHE);
		}
		feedbackCache.put(bDetailViewModel.getSelectedBusiness().getBusinessId(), feedback);
		Content.getInstance().addContent(Keys.FEEDBACK_CACHE, feedbackCache);
	}

	@SuppressWarnings("unchecked")
	private void maintainItemCache(Item item) {

		Map<String, List<Item>> itemCache = null;
		List<Item> items = null;
		if (!Content.containsKey(Keys.ITEM_CACHE)) {

			itemCache = new HashMap<String, List<Item>>();
			items = new ArrayList<Item>();
			items.add(item);
		} else {

			itemCache = (Map<String, List<Item>>) Content.resolve(Keys.ITEM_CACHE);
			items = itemCache.get(bDetailViewModel.getSelectedBusiness().getBusinessId());
			int updatedIndex = -1;
			for (int i = 0; i < items.size(); i++) {
				if (item.getItemId() == items.get(i).getItemId()) {
					updatedIndex = i;
					break;
				}
			}
			if (updatedIndex == -1) {
				items.set(updatedIndex, item);
			} else {
				items.add(item);
			}
		}
		itemCache.put(bDetailViewModel.getSelectedBusiness().getBusinessId(), items);
		Content.getInstance().addContent(Keys.ITEM_CACHE, itemCache);
	}

	@SuppressWarnings("unchecked")
	private void maintainCouponCache(Coupon coupon) {

		Map<String, List<Coupon>> couponCache = null;
		List<Coupon> coupons = null;
		if (!Content.containsKey(Keys.COUPON_CACHE)) {

			couponCache = new HashMap<String, List<Coupon>>();
			coupons = new ArrayList<Coupon>();
			coupons.add(coupon);
		} else {

			couponCache = (Map<String, List<Coupon>>) Content.resolve(Keys.COUPON_CACHE);
			coupons = couponCache.get(bDetailViewModel.getSelectedBusiness().getBusinessId());
			int updatedIndex = -1;
			for (int i = 0; i < coupons.size(); i++) {
				if (coupon.getCouponId() == coupons.get(i).getCouponId()) {
					updatedIndex = i;
					break;
				}
			}
			if (updatedIndex == -1) {
				coupons.set(updatedIndex, coupon);
			} else {
				coupons.add(coupon);
			}
		}
		couponCache.put(bDetailViewModel.getSelectedBusiness().getBusinessId(), coupons);
		Content.getInstance().addContent(Keys.COUPON_CACHE, couponCache);
	}

	@SuppressWarnings("unchecked")
	private Item getItemFromCache(Item defaultItem) {

		if (!Content.containsKey(Keys.ITEM_CACHE)) {
			return defaultItem;
		} else {
			Map<String, List<Item>> itemsCache = (Map<String, List<Item>>) Content.resolve(Keys.ITEM_CACHE);
			if (itemsCache.containsKey(bDetailViewModel.getSelectedBusiness().getBusinessId())) {
				List<Item> items = itemsCache.get(bDetailViewModel.getSelectedBusiness().getBusinessId());
				for (int i = 0; i < items.size(); i++) {
					if (defaultItem.getItemId() == items.get(i).getItemId()) {
						return items.get(i);
					}
				}
			} else {
				return defaultItem;
			}
		}
		return defaultItem;
	}

	@SuppressWarnings("unchecked")
	private Coupon getCouponFromCache(Coupon defaultCoupon) {

		if (!Content.containsKey(Keys.COUPON_CACHE)) {
			return defaultCoupon;
		} else {
			Map<String, List<Coupon>> couponCache = (Map<String, List<Coupon>>) Content.resolve(Keys.COUPON_CACHE);
			if (couponCache.containsKey(bDetailViewModel.getSelectedBusiness().getBusinessId())) {
				List<Coupon> coupons = couponCache.get(bDetailViewModel.getSelectedBusiness().getBusinessId());
				for (int i = 0; i < coupons.size(); i++) {
					if (defaultCoupon.getCouponId() == coupons.get(i).getCouponId()) {
						return coupons.get(i);
					}
				}
			} else {
				return defaultCoupon;
			}
		}
		return defaultCoupon;
	}

	@SuppressWarnings("unchecked")
	private String getFeedbackFromCache(String defaultFeedback) {

		if (!Content.containsKey(Keys.FEEDBACK_CACHE)) {
			return defaultFeedback;
		} else {
			Map<String, Feedback> feedbackCache = (Map<String, Feedback>) Content.resolve(Keys.FEEDBACK_CACHE);
			if (feedbackCache.containsKey(bDetailViewModel.getSelectedBusiness().getBusinessId())) {
				return feedbackCache.get(bDetailViewModel.getSelectedBusiness().getBusinessId()).toString();
			} else {
				return defaultFeedback;
			}
		}
	}

	private CompleteAssignment collectDatas() {

		BusinessDetailsAdapter adapter = (BusinessDetailsAdapter) lstBusinessDetails.getAdapter();

		CompleteAssignment cAssignment = new CompleteAssignment();
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
		cAssignment.setCompletedDate(df.format(new Date()));
		cAssignment.setAssignmentId(bDetailViewModel.getSelectedBusiness().getAssignmentId());
		cAssignment.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());
		cAssignment.setStatus(Labels.COMPLETED);
		cAssignment.setFeedback(adapter.getFeedback());
		cAssignment.setRatings(getRating());
		cAssignment.setItems(adapter.getItems());
		cAssignment.setCoupons(adapter.getCoupons());

		return cAssignment;
	}

	public int getRating() {
		return ratingBar.getProgress();
	}

	private void saveAssignment(CompleteAssignment cAssignment) {
		executeService(RequestCode.COMPLETE_MARKETER_ASSIGNMENTS, true, getCompleteMarketerAssignmentInput(cAssignment));
	}

	private ServiceInput getCompleteMarketerAssignmentInput(CompleteAssignment cAssignment) {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getCompleteMarketerJSON(cAssignment));
		input.setUrl(URL.COMPLETE_MARKETER_ASSIGNMENT);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getCompleteMarketerJSON(CompleteAssignment cAssignment) {
		return ModelUtil.serialize(cAssignment);
	}

	private void addDetails(String tag) {

		if (Labels.BUSINESS_DETAIL_ADD_CONTACT.equals(tag)) {
			navigateToAddContact();
		} else if (Labels.BUSINESS_DETAIL_ADD_NOTE.equals(tag)){
			navigateToAddNotes();
		}
	}

	private void navigateToAddContact() {

		Content.getInstance().addContent(Keys.SHOW_BUSINESS_CONTACT_DETAIL_KEY, bDetailViewModel);
		Content.getInstance().addContent(Keys.CONTACT_BUSINESS_MODE, true);
		Content.getInstance().addContent(Keys.CONTACT_DETAIL_KEY, new ContactDetail());
		Content.getInstance().addContent(Keys.CONTACT_BUSINESS_STATUS, false);
		openActivity(BusinessDetailActivity.this, ShowContactDetailActivity.class, getBundle(Keys.SHOW_BUSINESS_CONTACT_DETAIL_KEY));
	}

	private void navigateToAddNotes() {

		Content.getInstance().addContent(Keys.ADD_NOTE_KEY, bDetailViewModel);
		Content.getInstance().addContent(Keys.ADD_NOTE_ASSIGNMENT_KEY, bDetailViewModel.getSelectedBusiness().getAssignmentId());
		Content.getInstance().addContent(Keys.ADD_NOTE_BUSINESS_KEY, bDetailViewModel.getSelectedBusiness().getBusinessId());
		openActivity(BusinessDetailActivity.this, AddNoteActivity.class, getBundle(Keys.ADD_NOTE_KEY));
	}

	private void invokePhone(ContactDetail cDetail) {

		Intent intent = new Intent(Intent.ACTION_CALL);
	    intent.setData(Uri.parse("tel:" + cDetail.getPhoneNumber()));
	    startActivity(intent);
	}

	private void showContactDetails(ContactDetail cDetail) {

		Content.getInstance().addContent(Keys.SHOW_BUSINESS_CONTACT_DETAIL_KEY, bDetailViewModel);
		Content.getInstance().addContent(Keys.CONTACT_BUSINESS_MODE, false);
		Content.getInstance().addContent(Keys.CONTACT_DETAIL_KEY, cDetail);
		boolean completed = Labels.COMPLETED.equals(bDetailViewModel.getSelectedBusiness().getStatus());
		Content.getInstance().addContent(Keys.CONTACT_BUSINESS_STATUS, completed);
		openActivity(BusinessDetailActivity.this, ShowContactDetailActivity.class, getBundle(Keys.SHOW_BUSINESS_CONTACT_DETAIL_KEY));
	}

	private void goBack() {

		ServiceInvoker.checkNetworkAvailability();
		callTimelineService();
	}

	public void callTimelineService() {

		TimeLine timeLine = (TimeLine) Content.resolve(Keys.SELECTED_TIMELINE);
		try {
			switch (timeLine) {
			case TODAY:
				B2BContext.getInstance().setShowProgress(true);
				executeService(RequestCode.BUSINESS_TODAY, true, RouteUtil.getRouteInput(TimeLine.TODAY, 0));
				break;
			case WEEK:
				B2BContext.getInstance().setShowProgress(true);
				executeService(RequestCode.BUSINESS_WEEK, true, RouteUtil.getRouteInput(TimeLine.WEEK, 0));
				break;
			case MONTH:
				B2BContext.getInstance().setShowProgress(true);
				executeService(RequestCode.BUSINESS_MONTH, true, RouteUtil.getRouteInput(TimeLine.MONTH, 0));
				break;
			case TAX_SEASON:
				int month = 0;
				if (!Content.containsKey(Keys.SELECTED_TAX_SEASON)) {
					month = Calendar.JANUARY;
				} else {
					Button button = (Button) Content.resolve(Keys.SELECTED_TAX_SEASON);
					month = RouteUtil.getMonth(button);
				}
				B2BContext.getInstance().setShowProgress(true);
				executeService(RequestCode.BUSINESS_SEASON, true, RouteUtil.getRouteInput(TimeLine.TAX_SEASON, month));
				break;
			}
		} catch (Exception e) {
			convertAndThrow(e, Titles.MY_ROUTE_TITLE);
		}
	}

	private void goToPreviousBusiness() {

		ctSelectedIndex = bDetailViewModel.getSelectedIndex();
		ctSelectedIndex--;

		if (ctSelectedIndex < getTotalBusiness()) {
			clearCache();
			Business business = findBusiness(ctSelectedIndex);
			B2BContext.getInstance().setShowProgress(true);
			executeService(RequestCode.RETRIEVE_BUSINESS_DETAILS, true, getBusinessDetailsInput(business));
		}
	}

	private void goToNextBusiness() {

		ctSelectedIndex = bDetailViewModel.getSelectedIndex();
		ctSelectedIndex++;

		if (ctSelectedIndex > 0) {
			clearCache();
			Business business = findBusiness(ctSelectedIndex);
			B2BContext.getInstance().setShowProgress(true);
			executeService(RequestCode.RETRIEVE_BUSINESS_DETAILS, true, getBusinessDetailsInput(business));
		}
	}

	private Business findBusiness(int selectedIndex) {

		if (bDetailViewModel.getTimeLine() == TimeLine.TODAY) {
			return bDetailViewModel.getBusinesses().get(selectedIndex);
		} else {

			int sectionIndex = selectedIndex;
			for (Date date : bDetailViewModel.getBusinessesMap().keySet()) {

				List<Business> businesses = bDetailViewModel.getBusinessesMap().get(date);
				if (sectionIndex >= businesses.size()) {
					sectionIndex = sectionIndex - businesses.size();
				} else {
					return businesses.get(sectionIndex);
				}
			}
		}
		return null;
	}

	private int getTotalBusiness() {

		int total = 0;
		if (TimeLine.TODAY == bDetailViewModel.getTimeLine()) {
			return bDetailViewModel.getBusinesses().size();
		} else {
			for (Date date : bDetailViewModel.getBusinessesMap().keySet()) {
	
				List<Business> businesses = bDetailViewModel.getBusinessesMap().get(date);
				total += businesses.size();
			}
		}

		return total;
	}

	private ServiceInput getBusinessDetailsInput(Business business) {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getBusinessDetailsJSON(business));
		input.setUrl(URL.RETRIEVE_BUSSINESS_DETAIL);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getBusinessDetailsJSON(Business business) {

		RetrieveBusinessInput bdInput = new RetrieveBusinessInput();
		bdInput.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());
		bdInput.setAssignmentId(business.getAssignmentId());
		bdInput.setBusinessId(business.getBusinessId());
		return ModelUtil.serialize(bdInput);
	}

	@Override
	public void processOutput(ServiceResponse result, RequestCode requestCode) {

		switch (requestCode) {
		case RETRIEVE_BUSINESS_DETAILS:
			processRetrieveBusinessDetails(result);
			break;
		case BUSINESS_TODAY:
			processTimelineOutput(result);
			break;
		case BUSINESS_WEEK:
			processTimelineOutput(result);
			break;
		case BUSINESS_MONTH:
			processTimelineOutput(result);
			break;
		case BUSINESS_SEASON:
			processTimelineOutput(result);
			break;
		case COMPLETE_MARKETER_ASSIGNMENTS:
			processCompleteMarketerAssignmentOutput(result);
			break;
		default:
			break;
		}
	}

	private void processRetrieveBusinessDetails(ServiceResponse response) {

		if (response.isStatus()) {
			BusinessDetail detail = (BusinessDetail) ModelUtil.deserialize(response.getOutput(), BusinessDetail.class);
			bDetailViewModel.setSelectedBusiness(detail);
			bDetailViewModel.setSelectedIndex(ctSelectedIndex);
			setBusinessDetails();
		} else {
			ctSelectedIndex = bDetailViewModel.getSelectedIndex();
			handleError(new AppException(response.getErrors()), Titles.BUSINESS_DETAILS_TITLE);
		}
	}

	private void processTimelineOutput(ServiceResponse result) {

		if (result.isStatus()) {
			List<Business> businesses = ModelUtil.deserializeArray(
					result.getOutput(),
					new TypeToken<List<Business>>(){}.getType());
			Content.getInstance().addContent(Keys.MY_ROUTE_CONTENT, businesses);
			Content.getInstance().addContent(Keys.FROM_BUSINESS_DETAIL, "dummy");
			openActivity(this, RouteActivity.class, getBundle(Keys.MY_ROUTE_CONTENT));
		} else {
			handleError(new AppException(result.getErrors()), Titles.MY_ROUTE_TITLE);
		}
	}

	private void processCompleteMarketerAssignmentOutput(ServiceResponse result) {

		if (result.isStatus()) {
			goBack();
		} else {
			handleError(new AppException(result.getErrors()), Titles.MY_ROUTE_TITLE);
		}
	}

	@Override
	public void onItemClick(AdapterView<?> adapterView, View view, int position, long arg3) {

		try {
			switch (adapterView.getId()) {
			case R.id.lstBusinessDetails:
				showProgress(BusinessDetailActivity.this, Labels.EMPTY, Misc.KEY_LOADING);
				OnDetailItemClick(view);
				break;
			case R.id.listFeedback:
				selectFeedback(adapterView, view);
				break;
			default:
				break;
			}
		} catch (Exception e) {
			convertAndThrow(e, Titles.BUSINESS_DETAILS_TITLE);
		} finally {
			dismissProgress();
		}
	}

	private void OnDetailItemClick(View view) {

		Object tag = view.getTag(R.string.business_detail_address_key);
		if (tag != null) {
			if (Misc.ADDRESS_VIEW_ID.equals((String)tag)) {
				showRoute(findBusiness(bDetailViewModel.getSelectedIndex()));
			} else if (Misc.CONTACT_VIEW_ID.equals((String) tag)) {
				DetailDisplay dd = (DetailDisplay) view.getTag();
				ContactDetail cDetail = (ContactDetail) dd.getValuesMap().get(DetailConst.CONTACT_DETAIL_TAG);
				showContactDetails(cDetail);
			}
		}
	}

	private void selectFeedback(AdapterView<?> parent, View view) {

		ListView list = (ListView) parent;

		CheckedTextView txtView = null;
		for (int i = 0; i < list.getChildCount(); i++) {

			txtView = (CheckedTextView) list.getChildAt(i);
			txtView.setChecked(false);
		}

		txtView = (CheckedTextView) view;
		txtView.setChecked(true);
		Content.getInstance().addContent(Keys.TEMP_SELECTED_FEEDBACK, getFeedback(txtView.getText().toString()));
	}

	private Feedback getFeedback(String feedback) {

		if (Labels.GOOD.equals(feedback)) return Feedback.GOOD;
		if (Labels.FAIR.equals(feedback)) return Feedback.FAIR;
		return Feedback.BAD;
	}

	private String getFeedbackString(Feedback feedback) {

		if (Feedback.GOOD == feedback) return Labels.GOOD;
		if (Feedback.FAIR == feedback) return Labels.FAIR;
		return Labels.BAD;
	}

	public void showRoute(Business business) {
		Content.getInstance().addContent(Keys.SHOW_ROUTE_BUSINESS, business);
		Content.getInstance().addContent(Keys.SHOW_ROUTE_BUSINESS_DETAIL, bDetailViewModel);
		Content.getInstance().addContent(Keys.SHOW_ROUTE_BUSINESS_FROM_DETAILS, true);
		Bundle  bundle = getBundle(Keys.SHOW_ROUTE_BUSINESS);
		openActivity(BusinessDetailActivity.this, ShowBusinessRouteActivity.class, bundle);
	}
}

package net.libertytax.b2b.activities;

import net.libertytax.b2b.R;
import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.base.Constants.Titles;
import net.libertytax.b2b.base.Constants.URL;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.base.ServiceInvoker;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.model.AddNoteInput;
import net.libertytax.b2b.model.BusinessDetail;
import net.libertytax.b2b.model.BusinessDetailViewModel;
import net.libertytax.b2b.model.RetrieveBusinessInput;
import net.libertytax.b2b.util.B2BContext;
import net.libertytax.b2b.util.KeyboardUtil;
import net.libertytax.b2b.util.ModelUtil;
import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnTouchListener;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

public class AddNoteActivity extends BaseActivity
				implements OnClickListener,
							TextWatcher,
							OnFocusChangeListener,
							OnGlobalLayoutListener,
							OnTouchListener {

	private ImageButton btBack;
	private EditText edTxtAddNote;
	private LinearLayout rootView;
	private Toast toast;
	private Button btDone;
	private Button btCancel;

	private BusinessDetailViewModel businessVM;
	private int assignmentId;
	private String businessId;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.add_note);
		super.onCreate(savedInstanceState);
	}

	@SuppressLint("ShowToast")
	@Override
	protected void prepareControls() {

		btBack = (ImageButton) findViewById(R.id.imgAddNoteBack);
		edTxtAddNote = (EditText) findViewById(R.id.edTxtAddNote);
		rootView = (LinearLayout) findViewById(R.id.rootAddNote);
		toast = Toast.makeText(AddNoteActivity.this, "text", Toast.LENGTH_SHORT);
		toast.setGravity(Gravity.TOP | Gravity.END, -5, 122);
		btDone = (Button) findViewById(R.id.btAddNoteSubmit);
		btCancel = (Button) findViewById(R.id.btAddNoteCancel);
	}

	@Override
	protected void subscribeEvents() {
		btBack.setOnClickListener(this);
		edTxtAddNote.addTextChangedListener(this);
		edTxtAddNote.setOnFocusChangeListener(this);
		rootView.getViewTreeObserver().addOnGlobalLayoutListener(this);
		edTxtAddNote.setOnTouchListener(this);
		btDone.setOnClickListener(this);
		btCancel.setOnClickListener(this);
	}

	@Override
	protected void applyDefaults() {

		businessVM = (BusinessDetailViewModel) data;
		assignmentId = (Integer) Content.resolve(Keys.ADD_NOTE_ASSIGNMENT_KEY);
		businessId = (String) Content.resolve(Keys.ADD_NOTE_BUSINESS_KEY);
		onFocusChange(edTxtAddNote, true);
	}

	@Override
	public void onClick(View v) {

		try {
			switch (v.getId()) {
			case R.id.imgAddNoteBack:
			case R.id.btAddNoteCancel:
				goBack();
				break;
			case R.id.btAddNoteSubmit:
				addNote();
				break;
			default:
				break;
			}
		} catch (Exception e) {
			convertAndThrow(e, Titles.ADD_NOTE_TITLE);
		}
	}

	@Override
	public void onBackPressed() {

		try {
			goBack();
		} catch (Exception e) {
			convertAndThrow(e, Titles.ADD_NOTE_TITLE);
		}
	}

	private void addNote() {

		B2BContext.getInstance().setShowProgress(true);
		executeService(RequestCode.ADD_NOTE, false, getAddNoteInput());
	}

	private void goBack() {

		ServiceInvoker.checkNetworkAvailability();

		B2BContext.getInstance().setShowProgress(true);
		executeService(RequestCode.RETRIEVE_BUSINESS_DETAILS, true, getBusinessDetailsInput());
	}

	@Override
	public void processOutput(ServiceResponse result, RequestCode requestCode) {

		switch (requestCode) {
		case RETRIEVE_BUSINESS_DETAILS:
			processRetrieveBusinessDetails(result);
			break;
		case ADD_NOTE:
			processAddNote(result);
			break;
		default:
			break;
		}
	}

	private void processAddNote(ServiceResponse response) {

		if (response.isStatus()) {
			Content.getInstance().addContent(Keys.FROM_ADD_NOTE, true);
			goBack();
		} else {
			handleError(new AppException(response.getErrors()), Titles.BUSINESS_DETAILS_TITLE);
		}
	}

	private void processRetrieveBusinessDetails(ServiceResponse response) {

		if (response.isStatus()) {
			BusinessDetail detail = (BusinessDetail) ModelUtil.deserialize(response.getOutput(), BusinessDetail.class);
			businessVM.setSelectedBusiness(detail);
			Content.getInstance().addContent(Keys.RETRIEVE_BUSINESS_DETAILS_KEY, businessVM);
			openActivity(AddNoteActivity.this, BusinessDetailActivity.class, getBundle(Keys.RETRIEVE_BUSINESS_DETAILS_KEY));
		} else {
			handleError(new AppException(response.getErrors()), Titles.BUSINESS_DETAILS_TITLE);
		}
	}

	private ServiceInput getAddNoteInput() {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getAddNoteJSON());
		input.setUrl(URL.ADD_NOTE);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private ServiceInput getBusinessDetailsInput() {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getBusinessDetailsJSON());
		input.setUrl(URL.RETRIEVE_BUSSINESS_DETAIL);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getAddNoteJSON() {

		AddNoteInput bdInput = new AddNoteInput();
		bdInput.setAssignmentId(assignmentId);
		bdInput.setDescription(edTxtAddNote.getText().toString());
		return ModelUtil.serialize(bdInput);
	}

	private String getBusinessDetailsJSON() {

		RetrieveBusinessInput bdInput = new RetrieveBusinessInput();
		bdInput.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());
		bdInput.setAssignmentId(assignmentId);
		bdInput.setBusinessId(businessId);
		return ModelUtil.serialize(bdInput);
	}

	@Override
	public void afterTextChanged(Editable s) {

		String text = s.toString();
		int length = text.length();

		if (length <= 512) {
			toast.setText((512 - length) + " Character(s) left");
			toast.show();
		} else {
			edTxtAddNote.removeTextChangedListener(this);
			edTxtAddNote.setText(text.subSequence(0, 512));
			edTxtAddNote.setSelection(edTxtAddNote.getText().length());
			edTxtAddNote.addTextChangedListener(this);
		}
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
	}

	@Override
	public void onFocusChange(View v, boolean hasFocus) {
        if (hasFocus) {
            KeyboardUtil.setImeVisibility(true, edTxtAddNote);
        } else {
            KeyboardUtil.setImeVisibility(false, edTxtAddNote);
        }
	}

	@Override
	public void onGlobalLayout() {

		int heightDiff = rootView.getRootView().getHeight() - rootView.getHeight();

        Rect rectgle= new Rect();
        Window window= getWindow();
        window.getDecorView().getWindowVisibleDisplayFrame(rectgle);
        int contentViewTop= 
            window.findViewById(Window.ID_ANDROID_CONTENT).getTop();

        if(heightDiff <= contentViewTop){
        	edTxtAddNote.setLines(10);
        } else {
        	edTxtAddNote.setLines(5);
        }
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {

		// TODO Auto-generated method stub
        if (v.getId() == R.id.edTxtAddNote) {
            v.getParent().requestDisallowInterceptTouchEvent(true);
            switch (event.getAction()&MotionEvent.ACTION_MASK){
            case MotionEvent.ACTION_UP:
                v.getParent().requestDisallowInterceptTouchEvent(false);
                break;
            }
        }
        return false;
	}
}

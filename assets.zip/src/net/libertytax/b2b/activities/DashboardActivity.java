package net.libertytax.b2b.activities;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.libertytax.b2b.R;
import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.Messages;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.base.Constants.Titles;
import net.libertytax.b2b.base.Constants.URL;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.model.Business;
import net.libertytax.b2b.model.BusinessDetailsInput;
import net.libertytax.b2b.model.Marketer;
import net.libertytax.b2b.model.Office;
import net.libertytax.b2b.model.OtherMarketersInput;
import net.libertytax.b2b.util.B2BContext;
import net.libertytax.b2b.util.ModelUtil;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.google.gson.reflect.TypeToken;

public class DashboardActivity extends BaseActivity
implements OnClickListener {

	private Button myRouteButton;
	private Button myReportButton;
	private Button marketersButton;
	private Button selectOfficeButton;
	private Button logoutButton;

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.dashboard);
        super.onCreate(savedInstanceState);
    }

	@Override
	public void prepareControls() {

		myRouteButton 	   = (Button)findViewById(R.id.btMyRoute);
		myReportButton 	   = (Button)findViewById(R.id.btMyReport);
		marketersButton    = (Button)findViewById(R.id.btMarketers);
		selectOfficeButton = (Button)findViewById(R.id.btSelectOffice);
		logoutButton 	   = (Button)findViewById(R.id.btLogout);
	}

	@Override
	public void subscribeEvents() {
		myRouteButton.setOnClickListener(this);
		myReportButton.setOnClickListener(this);
		marketersButton.setOnClickListener(this);
		selectOfficeButton.setOnClickListener(this);
		logoutButton.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btMyRoute:
			navigateToMyRoutes();
			break;
		case R.id.btMyReport:
			navigateToMyReports();
			break;
		case R.id.btMarketers:
			navigateToMarketers();
			break;
		case R.id.btSelectOffice:
			navigateToSelectOffices();
			break;
		case R.id.btLogout:
			logout();
			break;
		default:
			break;
		}
	}

	private void navigateToMyRoutes() {

		try {

			B2BContext.getInstance().setShowProgress(true);
			executeService(RequestCode.BUSINESS_TODAY, true, getRouteInput());
		} catch (Exception e) {
			handleError(e, Titles.MY_ROUTE_TITLE);
		}
	}

	private ServiceInput getRouteInput() {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getInput());
		input.setUrl(URL.BUSINESS_DETAILS);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private ServiceInput getLogoutInput() {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getLogoutJSON());
		input.setUrl(URL.LOG_OUT);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getLogoutJSON() {
		return ModelUtil.serialize(B2BContext.getInstance().getLoginResult());
	}

	private ServiceInput getSelectOfficesInput() {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getSelectOfficesJSON());
		input.setUrl(URL.SELECT_OFFICE);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private ServiceInput getOtherMarketerInput() {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getOtherMarketersJSON());
		input.setUrl(URL.OTHER_MARKETERS);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getInput() {

		BusinessDetailsInput bdInput = new BusinessDetailsInput();
		bdInput.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());
		bdInput.setStartDate(new Date());
		bdInput.setEndDate(new Date());
		return ModelUtil.serialize(bdInput);
	}

	private String getOtherMarketersJSON() {

		OtherMarketersInput omInput = new OtherMarketersInput();
		omInput.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());
		omInput.setOfficeIds(getOfficeIds());
		return ModelUtil.serialize(omInput);
	}

	@SuppressWarnings("unchecked")
	private List<String> getOfficeIds() {

		List<String> officeIds = new ArrayList<String>();
		if (!Content.containsKey(Keys.SELECTED_OFFICES)) {
			return officeIds;
		}
		List<Office> offices = (List<Office>) Content.resolve(Keys.SELECTED_OFFICES);
		for (Office office : offices) {
			officeIds.add(office.getOfficeId());
		}

		return officeIds;
	}

	private String getSelectOfficesJSON() {
		return ModelUtil.serialize(B2BContext.getInstance().getLoginResult());
	}

	@Override
	public void processOutput(ServiceResponse result, RequestCode requestCode) {

		try {
			switch(requestCode) {
				case BUSINESS_TODAY:
					processRoutesOutput(result);
					break;
				case MY_REPORT:
					processReportsOutput(result);
					break;
				case OTHER_MARKETERS:
					processMarketersOutput(result);
					break;
				case SELECT_OFFICE:
					processSelectOfficeOutput(result);
					break;
				case LOG_OUT:
					processLogoutOutput(result);
					break;
			}
		} catch (Exception e) {
			convertAndThrow(e, Titles.DASHBOARD_TITLE);
		}
	}

	private void processRoutesOutput(ServiceResponse result) {

		if (result.isStatus()) {
			List<Business> businesses = ModelUtil.deserializeArray(
					result.getOutput(),
					new TypeToken<List<Business>>(){}.getType());
			Content.getInstance().addContent(Keys.MY_ROUTE_CONTENT, businesses);
			openActivity(this, RouteActivity.class, getBundle(Keys.MY_ROUTE_CONTENT));
		} else {
			handleError(new AppException(result.getErrors()), Titles.MY_ROUTE_TITLE);
		}
	}

	private void processReportsOutput(ServiceResponse result) {
	}

	private void processMarketersOutput(ServiceResponse result) {

		if (result.isStatus()) {
			List<Marketer> offices = ModelUtil.deserializeArray(
					result.getOutput(),
					new TypeToken<List<Marketer>>(){}.getType());
			Content.getInstance().addContent(Keys.OTHER_MARKETER_CONTENT, offices);
			openActivity(DashboardActivity.this, OtherMarketersActivity.class, getBundle(Keys.OTHER_MARKETER_CONTENT));
		} else {
			handleError(new AppException(result.getErrors()), Titles.MY_ROUTE_TITLE);
		}
	}

	private void processSelectOfficeOutput(ServiceResponse result) {

		if (result.isStatus()) {
			List<Office> offices = ModelUtil.deserializeArray(
					result.getOutput(),
					new TypeToken<List<Office>>(){}.getType());
			Content.getInstance().addContent(Keys.SELECT_OFFICE_CONTENT, offices);
			openActivity(DashboardActivity.this, SelectOfficeActivity.class, getBundle(Keys.SELECT_OFFICE_CONTENT));
		} else {
			handleError(new AppException(result.getErrors()), Titles.MY_ROUTE_TITLE);
		}
	}

	private void processLogoutOutput(ServiceResponse result) {

		if (result.isStatus()) {
			String userName = (String) Content.resolve(Keys.LOGIN_CONTENT);
			Content.removeAll();
			Content.getInstance().addContent(Keys.LOGOUT_CONTENT, userName);
			openActivity(DashboardActivity.this, LoginActivity.class, getBundle(Keys.LOGOUT_CONTENT));
		} else {
			handleError(new AppException(result.getErrors()), Titles.DASHBOARD_TITLE);
		}
	}

	private void navigateToMyReports() {
	}

	private void navigateToMarketers() {

		try {

			B2BContext.getInstance().setShowProgress(true);
			executeService(RequestCode.OTHER_MARKETERS, true, getOtherMarketerInput());
		} catch (Exception e) {
			handleError(e, Titles.MY_ROUTE_TITLE);
		}
	}

	private void navigateToSelectOffices() {

		try {

			B2BContext.getInstance().setShowProgress(true);
			executeService(RequestCode.SELECT_OFFICE, true, getSelectOfficesInput());
		} catch (Exception e) {
			handleError(e, Titles.MY_ROUTE_TITLE);
		}
	}

	private void logout() {

		try {
			showConfirmation(DashboardActivity.this, Titles.LOGOUT_TITLE, Messages.LOGOUT_MSG);
		} catch (Exception e) {
			handleError(e, Titles.MY_ROUTE_TITLE);
		}
	}

	@Override
	protected void onPositiveResult() {
		B2BContext.getInstance().setShowProgress(true);
		executeService(RequestCode.LOG_OUT, true, getLogoutInput());
	}

	@Override
	protected void onNegativeResult() {
	}
}

package net.libertytax.b2b.activities;

import java.util.Date;
import java.util.List;
import java.util.Set;

import net.libertytax.b2b.R;
import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.Constants.HeaderValue;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.base.Constants.Titles;
import net.libertytax.b2b.base.Constants.URL;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.base.ServiceInvoker;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.model.Business;
import net.libertytax.b2b.model.BusinessDetail;
import net.libertytax.b2b.model.BusinessDetailViewModel;
import net.libertytax.b2b.model.ContactDetail;
import net.libertytax.b2b.model.RetrieveBusinessInput;
import net.libertytax.b2b.util.B2BContext;
import net.libertytax.b2b.util.B2BTextWatcher;
import net.libertytax.b2b.util.ModelUtil;
import net.libertytax.b2b.validator.ContactDetailValidator;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class ShowContactDetailActivity extends BaseActivity
			implements OnClickListener {

	private ImageButton imgBack;
	private TextView txtEdit;
	private TextView txtContactPerson;
	private EditText edTxtContactPerson;
	private TextView txtDesignation;
	private EditText edTxtDesignation;
	private TextView txtPhone;
	private EditText edTxtPhone;
	private ImageView imgPhone;
	private TextView txtEmail;
	private EditText edTxtEmail;
	private ImageView imgEmail;
	private TextView txtAddress;
	private EditText edTxtAddress;
	private TextView txtMobile;
	private EditText edTxtMobile;
	private ImageView imgMobile;
	private TextView txtFax;
	private EditText edTxtFax;
	private View dividerContactPerson;
	private View dividerDesignation;
	private View dividerPhone;
	private View dividerEmail;
	private View dividerAddress;
	private View dividerMobile;
	private View dividerFax;

	private BusinessDetailViewModel businessVM;
	private ContactDetail cDetail;
	private Mode mode;
	private boolean isCompleted;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.contact_detail);
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void prepareControls() {

		imgBack = (ImageButton) findViewById(R.id.imgContactBack);
		txtEdit = (TextView) findViewById(R.id.txtContactEdit);
		txtContactPerson = (TextView) findViewById(R.id.txtContactPersonName);
		edTxtContactPerson = (EditText) findViewById(R.id.edTxtContactPersonName);
		txtDesignation = (TextView) findViewById(R.id.txtContactDesignationName);
		edTxtDesignation = (EditText) findViewById(R.id.edTxtContactDesignationName);
		txtPhone = (TextView) findViewById(R.id.txtContactPhoneNumberName);
		edTxtPhone = (EditText) findViewById(R.id.edTxtContactPhoneNumberName);
		imgPhone = (ImageView) findViewById(R.id.imgContactPhone);
		txtEmail = (TextView) findViewById(R.id.txtContactEmailName);
		edTxtEmail = (EditText) findViewById(R.id.edTxtContactEmailName);
		imgEmail = (ImageView) findViewById(R.id.imgContactEmail);
		txtAddress = (TextView) findViewById(R.id.txtContactAddressName);
		edTxtAddress = (EditText) findViewById(R.id.edTxtContactAddressName);
		txtMobile = (TextView) findViewById(R.id.txtContactMobileNumber);
		edTxtMobile = (EditText) findViewById(R.id.edTxtContactMobileNumber);
		imgMobile = (ImageView) findViewById(R.id.imgContactMobile);
		txtFax = (TextView) findViewById(R.id.txtContactFaxName);
		edTxtFax = (EditText) findViewById(R.id.edTxtContactFaxName);
		dividerContactPerson = (View) findViewById(R.id.contactPersonDivider);
		dividerDesignation = (View) findViewById(R.id.designationDivider);
		dividerPhone = (View) findViewById(R.id.contactPhoneDivider);
		dividerEmail = (View) findViewById(R.id.contactEmailDivider);
		dividerAddress = (View) findViewById(R.id.contactAddressDivider);
		dividerMobile = (View) findViewById(R.id.contactMobileDivider);
		dividerFax = (View) findViewById(R.id.contactFaxDivider);
	}

	@Override
	protected void subscribeEvents() {

		imgBack.setOnClickListener(this);
		txtEdit.setOnClickListener(this);
		imgPhone.setOnClickListener(this);
		imgEmail.setOnClickListener(this);
		imgMobile.setOnClickListener(this);
		edTxtEmail.addTextChangedListener(new B2BTextWatcher(edTxtEmail));
		edTxtMobile.addTextChangedListener(new B2BTextWatcher(edTxtMobile));
		edTxtFax.addTextChangedListener(new B2BTextWatcher(edTxtFax));
		edTxtPhone.addTextChangedListener(new B2BTextWatcher(edTxtPhone));
	}

	@Override
	protected void applyDefaults() {

		boolean addMode = (Boolean) Content.resolve(Keys.CONTACT_BUSINESS_MODE);
		if (addMode) {
			mode = Mode.ADD;
		} else {
			mode = Mode.VIEW;
		}

		businessVM = (BusinessDetailViewModel) data;
		cDetail = (ContactDetail) Content.resolve(Keys.CONTACT_DETAIL_KEY);
		isCompleted = (Boolean) Content.resolve(Keys.CONTACT_BUSINESS_STATUS);

		setContactDetails();
	}

	private void setContactDetails() {
		manageControls();
		populateDatas();
	}

	private void populateDatas() {

		switch (mode) {
		case ADD:
			showTextValues(true);
			break;
		case EDIT:
		case VIEW:
			showTextValues(false);
			break;
		default:
			break;
		}
	}

	private void manageControls() {

		switch (mode) {
		case ADD:
		case EDIT:
			showTextViews(true);
			break;
		case VIEW:
			showTextViews(false);
			break;
		default:
			break;
		}
	}

	private void showTextViews(boolean editable) {

		txtContactPerson.setVisibility(editable ? View.GONE : View.VISIBLE);
		edTxtContactPerson.setVisibility(editable ? View.VISIBLE : View.GONE);
		txtDesignation.setVisibility(editable ? View.GONE : View.VISIBLE);
		edTxtDesignation.setVisibility(editable ? View.VISIBLE : View.GONE);
		txtPhone.setVisibility(editable ? View.GONE : View.VISIBLE);
		edTxtPhone.setVisibility(editable ? View.VISIBLE : View.GONE);
		imgPhone.setVisibility(editable ? View.GONE : View.VISIBLE);
		txtEmail.setVisibility(editable ? View.GONE : View.VISIBLE);
		edTxtEmail.setVisibility(editable ? View.VISIBLE : View.GONE);
		imgEmail.setVisibility(editable ? View.GONE : View.VISIBLE);
		txtAddress.setVisibility(editable ? View.GONE : View.VISIBLE);
		edTxtAddress.setVisibility(editable ? View.VISIBLE : View.GONE);
		txtMobile.setVisibility(editable ? View.GONE : View.VISIBLE);
		edTxtMobile.setVisibility(editable ? View.VISIBLE : View.GONE);
		imgMobile.setVisibility(editable ? View.GONE : View.VISIBLE);
		txtFax.setVisibility(editable ? View.GONE : View.VISIBLE);
		edTxtFax.setVisibility(editable ? View.VISIBLE : View.GONE);
		txtEdit.setVisibility(isCompleted ? View.GONE : View.VISIBLE);
		dividerContactPerson.setVisibility(editable ? View.GONE : View.VISIBLE);
		dividerDesignation.setVisibility(editable ? View.GONE : View.VISIBLE);
		dividerPhone.setVisibility(editable ? View.GONE : View.VISIBLE);
		dividerEmail.setVisibility(editable ? View.GONE : View.VISIBLE);
		dividerAddress.setVisibility(editable ? View.GONE : View.VISIBLE);
		dividerMobile.setVisibility(editable ? View.GONE : View.VISIBLE);
		dividerFax.setVisibility(editable ? View.GONE : View.VISIBLE);

		//only for edit button
		txtEdit.setBackgroundResource(editable ? R.drawable.ic_action_ok_icon_copy : 0);
		txtEdit.setText(editable ? Labels.EMPTY : Labels.EDIT);
	}

	private void showTextValues(boolean neww) {

		txtContactPerson.setText(neww ? Labels.EMPTY : cDetail.getContactPerson());
		edTxtContactPerson.setText(neww ? Labels.EMPTY : cDetail.getContactPerson());
		txtDesignation.setText(neww ? Labels.EMPTY : cDetail.getDesignation());
		edTxtDesignation.setText(neww ? Labels.EMPTY : cDetail.getDesignation());
		txtPhone.setText(neww ? Labels.EMPTY : cDetail.getPhoneNumber());
		edTxtPhone.setText(neww ? Labels.EMPTY : cDetail.getPhoneNumber());
		txtEmail.setText(neww ? Labels.EMPTY : cDetail.getEmailId());
		edTxtEmail.setText(neww ? Labels.EMPTY : cDetail.getEmailId());
		txtAddress.setText(neww ? Labels.EMPTY : cDetail.getAddress());
		edTxtAddress.setText(neww ? Labels.EMPTY : cDetail.getAddress());
		txtMobile.setText(neww ? Labels.EMPTY : cDetail.getMobileNumber());
		edTxtMobile.setText(neww ? Labels.EMPTY : cDetail.getMobileNumber());
		txtFax.setText(neww ? Labels.EMPTY : cDetail.getFax());
		edTxtFax.setText(neww ? Labels.EMPTY : cDetail.getFax());
	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.imgContactBack:
			goBack();
			break;
		case R.id.txtContactEdit:
			editDetails();
			break;
		case R.id.imgContactPhone:
			invokePhone(cDetail.getPhoneNumber());
			break;
		case R.id.imgContactEmail:
			invokeMail(cDetail);
			break;
		case R.id.imgContactMobile:
			invokePhone(cDetail.getMobileNumber());
			break;
		default:
			break;
		}
	}

	private void editDetails() {

		switch (mode) {
		case VIEW:
			mode = Mode.EDIT;
			setContactDetails();
			break;
		case EDIT:
		case ADD:
			saveBusinessContact();
			break;
		default:
			break;
		}
	}

	@Override
	public void processOutput(ServiceResponse result, RequestCode requestCode) {

		switch (requestCode) {
		case RETRIEVE_BUSINESS_DETAILS:
			processRetrieveBusinessDetails(result);
			break;
		case ADD_BUSINESS_CONTACT:
		case UPDATE_BUSINESS_CONTACT:
			processBusinessContact(result);
			break;
		default:
			break;
		}
	}

	private void processRetrieveBusinessDetails(ServiceResponse response) {

		if (response.isStatus()) {
			BusinessDetail detail = (BusinessDetail) ModelUtil.deserialize(response.getOutput(), BusinessDetail.class);
			businessVM.setSelectedBusiness(detail);
			Content.getInstance().addContent(Keys.RETRIEVE_BUSINESS_DETAILS_KEY, businessVM);
			Content.getInstance().addContent(Keys.FROM_CONTACT_DETAILS_KEY, true);
			openActivity(ShowContactDetailActivity.this, BusinessDetailActivity.class, getBundle(Keys.RETRIEVE_BUSINESS_DETAILS_KEY));
		} else {
			handleError(new AppException(response.getErrors()), Titles.BUSINESS_DETAILS_TITLE);
		}
	}

	private void processBusinessContact(ServiceResponse response) {

		if (response.isStatus()) {
			B2BContext.getInstance().setShowProgress(true);
			int index = businessVM.getSelectedIndex();
			executeService(RequestCode.RETRIEVE_BUSINESS_DETAILS, true, getBusinessDetailsInput(getBusinessFromIndex(index)));
		} else {
			handleError(new AppException(response.getErrors()), Titles.BUSINESS_DETAILS_TITLE);
		}
	}

	private void goBack() {

		ServiceInvoker.checkNetworkAvailability();

		B2BContext.getInstance().setShowProgress(true);
		int index = businessVM.getSelectedIndex();
		executeService(RequestCode.RETRIEVE_BUSINESS_DETAILS, true, getBusinessDetailsInput(getBusinessFromIndex(index)));
	}

	private Business getBusinessFromIndex(int index) {

		if (businessVM.getBusinesses() == null) {

			int position = index;
			Set<Date> dateSet = businessVM.getBusinessesMap().keySet();
			for (Date date : dateSet) {

				List<Business> businesses = businessVM.getBusinessesMap().get(date);
				int length = businesses.size();
				if (position >= length) {
					position = position - length;
				} else {
					return businesses.get(position);
				}
			}
		} else {
			return businessVM.getBusinesses().get(index);
		}

		return null;
	}

	private void invokePhone(String number) {

		Intent intent = new Intent(Intent.ACTION_CALL);
	    intent.setData(Uri.parse("tel:" + number));
	    startActivity(intent);
	}

	private void invokeMail(ContactDetail cDetail) {

		Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
		emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, cDetail.getEmailId());
		emailIntent.setType(HeaderValue.EMAIL_TYPE);
		startActivity(Intent.createChooser(emailIntent, "Choose mail..."));
	}

	private void saveBusinessContact() {

		try {

			collectDatas();

			new ContactDetailValidator().validateContactDetail(cDetail);

			RequestCode code = (mode == Mode.ADD) ? RequestCode.ADD_BUSINESS_CONTACT : RequestCode.UPDATE_BUSINESS_CONTACT;
			executeService(code, true, getBusinessContactInput());
		} catch (Exception e) {
			convertAndThrow(e, Titles.CONTACT_DETAIL_TITLE);
		}
	}

	private ServiceInput getBusinessContactInput() {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getBusinessContactJSON());
		input.setUrl((mode == Mode.ADD) ? URL.ADD_BUSINESS_CONTACT : URL.UPDATE_BUSINESS_CONTACT);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getBusinessContactJSON() {
		return ModelUtil.serialize(cDetail);
	}

	private void collectDatas() {

		cDetail.setBusinessId(businessVM.getSelectedBusiness().getBusinessId());
		cDetail.setContactPerson(edTxtContactPerson.getText().toString());
		cDetail.setDesignation(edTxtDesignation.getText().toString());
		cDetail.setPhoneNumber(edTxtPhone.getText().toString());
		cDetail.setEmailId(edTxtEmail.getText().toString());
		cDetail.setAddress(edTxtAddress.getText().toString());
		cDetail.setMobileNumber(edTxtMobile.getText().toString());
		cDetail.setFax(edTxtFax.getText().toString());
	}

	private ServiceInput getBusinessDetailsInput(Business business) {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getBusinessDetailsJSON(business));
		input.setUrl(URL.RETRIEVE_BUSSINESS_DETAIL);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getBusinessDetailsJSON(Business business) {

		RetrieveBusinessInput bdInput = new RetrieveBusinessInput();
		bdInput.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());
		bdInput.setAssignmentId(business.getAssignmentId());
		bdInput.setBusinessId(business.getBusinessId());
		return ModelUtil.serialize(bdInput);
	}

	private enum Mode {
		ADD,
		EDIT,
		VIEW;
	}
}

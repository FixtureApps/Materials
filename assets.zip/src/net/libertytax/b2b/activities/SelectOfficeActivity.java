package net.libertytax.b2b.activities;

import java.util.List;

import net.libertytax.b2b.R;
import net.libertytax.b2b.adapters.SelectOfficeAdapter;
import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.Misc;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.base.Constants.Titles;
import net.libertytax.b2b.base.Constants.URL;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.Error;
import net.libertytax.b2b.base.ErrorCode;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.base.ServiceInvoker;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.model.Office;
import net.libertytax.b2b.model.UpdateDefaultOffice;
import net.libertytax.b2b.util.B2BContext;
import net.libertytax.b2b.util.ModelUtil;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ImageButton;
import android.widget.ListView;

public class SelectOfficeActivity extends BaseActivity
					implements OnClickListener,
								OnItemClickListener {

	private ImageButton imgBtBack;
	private ImageButton imgBtDone;
	private ListView lstSelectOffice;
	private Button btReset;
	private Button btDefault;

	private List<Office> offices;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.select_office);
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void prepareControls() {

		imgBtBack = (ImageButton) findViewById(R.id.imgSelectOfficeBack);
		imgBtDone = (ImageButton) findViewById(R.id.imgSelectOfficeDone);
		lstSelectOffice = (ListView) findViewById(R.id.lstSelectOffice);
		btReset = (Button) findViewById(R.id.btReset);
		btDefault = (Button) findViewById(R.id.btDefault);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void applyDefaults() {

		offices = (List<Office>) data;
		offices.add(0, getAllOffice());

		populateList();
	}

	@Override
	protected void subscribeEvents() {

		imgBtBack.setOnClickListener(this);
		imgBtDone.setOnClickListener(this);
		lstSelectOffice.setOnItemClickListener(this);
		btReset.setOnClickListener(this);
		btDefault.setOnClickListener(this);
	}

	private Office getAllOffice() {

		Office office = new Office();
		office.setIsDefaultOffice(false);
		office.setOfficeId("0");
		office.setOfficeName(Labels.ALL_OFFICE);

		return office;
	}

	@Override
	public void onItemClick(AdapterView<?> adapterView, View view, int position, long layout) {

		ListView lstView = (ListView) adapterView;

		SelectOfficeAdapter adapter = (SelectOfficeAdapter) lstView.getAdapter();

		CheckedTextView txtView = (CheckedTextView) view;
		boolean checked = txtView.isChecked();
		Office office = (Office) txtView.getTag();

		if (checked) {
			if ("0".equals(office.getOfficeId())) {
				adapter.removeAll(true);
			} else {
				adapter.removeSelected(office.getOfficeId(), true);
			}
		} else {
			if ("0".equals(office.getOfficeId())) {
				adapter.addAll(true);
			} else {
				adapter.addSelected(office.getOfficeId(), true);
			}
		}
	}

	@Override
	public void onClick(View v) {

		try {
			switch (v.getId()) {
			case R.id.imgSelectOfficeBack:
				goBack();
				break;
			case R.id.imgSelectOfficeDone:
				saveOffices();
				goBack();
				break;
			case R.id.btReset:
				revertToDefault();
				break;
			case R.id.btDefault:
				makeDefault();
				break;
			default:
				break;
			}
		} catch (Exception e) {
			convertAndThrow(e, Titles.SELECT_OFFICE_TITLE);
		}
	}

	private void saveOffices() {

		SelectOfficeAdapter adapter = (SelectOfficeAdapter) lstSelectOffice.getAdapter();
		List<Office> offices = adapter.getSelectedOffices();
		Content.getInstance().addContent(Keys.SELECTED_OFFICES, offices);
	}

	private void revertToDefault() {

		SelectOfficeAdapter adapter = (SelectOfficeAdapter) lstSelectOffice.getAdapter();
		adapter.removeAll(false);
		adapter.addSelected(getDefaultOffice().getOfficeId(), true);
	}

	private void makeDefault() {

		SelectOfficeAdapter adapter = (SelectOfficeAdapter) lstSelectOffice.getAdapter();
		List<Office> selectedOffices = adapter.getSelectedOffices();
		if (selectedOffices.size() > 1 || selectedOffices.size() < 1) {
			throw new AppException(new Error(ErrorCode.NOT_HAS_ONE_OFFICE));
		}

		B2BContext.getInstance().setShowProgress(true);
		executeService(RequestCode.UPDATE_MARKETER_DEFAULT_OFFICE, true, getUpdateDefaultOfficeInput(selectedOffices.get(0)));
	}

	private ServiceInput getUpdateDefaultOfficeInput(Office defaultOffice) {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getUpdateDefaultOfficeJSON(defaultOffice));
		input.setUrl(URL.UPDATE_MARKETER_DEFAULT_OFFICE);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getUpdateDefaultOfficeJSON(Office defaultOffice) {

		UpdateDefaultOffice udoInput = new UpdateDefaultOffice();
		udoInput.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());
		udoInput.setDefaultOfficeId(defaultOffice.getOfficeId());
		return ModelUtil.serialize(udoInput);
	}

	@Override
	public void processOutput(ServiceResponse result, RequestCode requestCode) {

		switch (requestCode) {
		case UPDATE_MARKETER_DEFAULT_OFFICE:
			processUpdateDefaultOfficeOutput(result);
			break;
		default:
			break;
		}
	}

	private void processUpdateDefaultOfficeOutput(ServiceResponse result) {

		if (result.isStatus()) {
			UpdateDefaultOffice office = (UpdateDefaultOffice) ModelUtil.deserialize(result.getOutput(), UpdateDefaultOffice.class);
			setDefaultOffice(office.getDefaultOfficeId());
		} else {
			handleError(new AppException(result.getErrors()), Titles.SELECT_OFFICE_TITLE);
		}
	}

	private void setDefaultOffice(String defaultOffice) {

		for (Office office : offices) {
			if (office.getOfficeId().equals(defaultOffice)) {
				office.setIsDefaultOffice(true);
			} else {
				office.setIsDefaultOffice(false);
			}
		}
	}

	private void goBack() {

		ServiceInvoker.checkNetworkAvailability();
		showProgress(SelectOfficeActivity.this, Labels.EMPTY, Misc.KEY_LOADING);
		openActivity(SelectOfficeActivity.this, DashboardActivity.class, null);
	}

	@Override
	public void onBackPressed() {

		try {
			goBack();
		} catch (Exception e) {
			convertAndThrow(e, Titles.SELECT_OFFICE_TITLE);
		}
	}

	@SuppressWarnings("unchecked")
	private void populateList() {

		SelectOfficeAdapter adapter = new SelectOfficeAdapter(SelectOfficeActivity.this, offices);
		if (Content.containsKey(Keys.SELECTED_OFFICES)) {

			List<Office> offices = (List<Office>) Content.resolve(Keys.SELECTED_OFFICES);
			for (Office office : offices) {
				adapter.addSelected(office.getOfficeId(), false);
			}
		} else {
			Office defaultOffice = getDefaultOffice();
			if (defaultOffice != null) {
				adapter.addSelected(defaultOffice.getOfficeId(), false);
			}
		}
		lstSelectOffice.setAdapter(adapter);
	}

	private Office getDefaultOffice() {

		for (Office office : offices) {
			if (office.isIsDefaultOffice()) {
				return office;
			}
		}
		return null;
	}
}
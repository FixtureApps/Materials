package net.libertytax.b2b.activities;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import net.libertytax.b2b.R;
import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.Misc;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.base.Constants.Titles;
import net.libertytax.b2b.base.Constants.URL;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.Error;
import net.libertytax.b2b.base.ErrorCode;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.base.ServiceInvoker;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.fragments.B2BMapFragment;
import net.libertytax.b2b.fragments.B2BMapFragment.OnMapAttachedListener;
import net.libertytax.b2b.fragments.B2BMapFragment.OnMapViewCreatedListener;
import net.libertytax.b2b.maputils.ui.TextIconGenerator;
import net.libertytax.b2b.model.AlternateRoute;
import net.libertytax.b2b.model.Business;
import net.libertytax.b2b.model.BusinessDetail;
import net.libertytax.b2b.model.BusinessDetailViewModel;
import net.libertytax.b2b.model.RetrieveBusinessInput;
import net.libertytax.b2b.model.TimeLine;
import net.libertytax.b2b.util.B2BContext;
import net.libertytax.b2b.util.B2BLocationManager;
import net.libertytax.b2b.util.LocationUtils;
import net.libertytax.b2b.util.LocationValue;
import net.libertytax.b2b.util.ModelUtil;
import net.libertytax.b2b.util.RouteUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.IntentSender;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.location.LocationClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.gson.reflect.TypeToken;

public class ShowBusinessRouteActivity extends BaseActivity
		implements ConnectionCallbacks,
					OnConnectionFailedListener,
					LocationListener,
					OnClickListener,
					OnMapAttachedListener,
					OnMapViewCreatedListener {

	private Business business;
	private BusinessDetailViewModel bDetailViewModel;
	private boolean fromDetails;
    private GoogleMap gMap;
	private B2BMapFragment mapFragment;

    private ImageButton btBack;
    private ImageButton btAlternate;
    private WebView webDirections;
    private TextView txtDistance;
    private TextView txtTime;

    // Stores the current instantiation of the location client in this object
    private LocationClient mLocationClient;

    // A request to connect to Location Services
    private LocationRequest mLocationRequest;

    private List<AlternateRoute> alternateRoutes;

    /*
     * Note if updates have been turned on. Starts out as "false"; is set to "true" in the
     * method handleRequestSuccess of LocationUpdateReceiver.
     *
     */
    boolean mUpdatesRequested = false;

    Location currentLocation;

    private PolylineOptions polyLineOptions;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.business_route);
		super.onCreate(savedInstanceState);
	}

    @Override
    protected void prepareControls() {

		addMapFragment(R.id.relBusinessRouteMap, getMapFragment());

        // Create a new global location parameters object
        mLocationRequest = LocationRequest.create();

        /*
         * Set the update interval
         */
        mLocationRequest.setInterval(LocationUtils.UPDATE_INTERVAL_IN_MILLISECONDS);

        // Use high accuracy
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        // Set the interval ceiling to one minute
        mLocationRequest.setFastestInterval(LocationUtils.FAST_INTERVAL_CEILING_IN_MILLISECONDS);

        // Note that location updates are off until the user turns them on
        mUpdatesRequested = false;

        /*
         * Create a new location client, using the enclosing class to
         * handle callbacks.
         */
        mLocationClient = new LocationClient(ShowBusinessRouteActivity.this, this, this);

        btBack = (ImageButton) findViewById(R.id.imgBusinessRouteBack);
        btAlternate = (ImageButton) findViewById(R.id.imgBusinessRouteDone);
        webDirections = (WebView) findViewById(R.id.webDirections);
        txtDistance = (TextView) findViewById(R.id.txtDistance);
        txtTime = (TextView) findViewById(R.id.txtTime);
    }

    @Override
    protected void subscribeEvents() {
    	btBack.setOnClickListener(this);
    	btAlternate.setOnClickListener(this);
    }

    @Override
    protected void applyDefaults() {

    	business = (Business) data;
		fromDetails = (Boolean) Content.resolve(Keys.SHOW_ROUTE_BUSINESS_FROM_DETAILS);
		if (Content.containsKey(Keys.SHOW_ROUTE_BUSINESS_DETAIL)) {
			bDetailViewModel = (BusinessDetailViewModel) Content.resolve(Keys.SHOW_ROUTE_BUSINESS_DETAIL);
			Content.remove(Keys.SHOW_ROUTE_BUSINESS_DETAIL);
		}
		if (Content.containsKey(Keys.ALTERNATE_ROUTE_VM)) {
			bDetailViewModel = (BusinessDetailViewModel) Content.resolve(Keys.ALTERNATE_ROUTE_VM);
			Content.remove(Keys.ALTERNATE_ROUTE_VM);
		}
    }

	private void addMapFragment(int resource, Fragment fragment) {

        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();

        ft.add(resource, fragment);
        ft.commitAllowingStateLoss();
    }

	private B2BMapFragment getMapFragment() {

		if (mapFragment == null) {
			mapFragment = new B2BMapFragment();
			mapFragment.setListener(this);
			mapFragment.setViewListener(this);
		}
		return mapFragment;
	}

    private void setUpMapIfNeeded() {

    	// Do a null check to confirm that we have not already instantiated the map.
        if (gMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            gMap = mapFragment.getMap();
        }
    }

	private void setMapViewParams() {
    	mapFragment.getView().getLayoutParams().width = LayoutParams.MATCH_PARENT;
		mapFragment.getView().getLayoutParams().height = LayoutParams.MATCH_PARENT;
	}

	@Override
	public void onConnectionFailed(ConnectionResult connectionResult) {

        /*
         * Google Play services can resolve some errors it detects.
         * If the error has a resolution, try sending an Intent to
         * start a Google Play services activity that can resolve
         * error.
         */
        if (connectionResult.hasResolution()) {
            try {

                // Start an Activity that tries to resolve the error
                connectionResult.startResolutionForResult(
                        ShowBusinessRouteActivity.this,
                        LocationUtils.CONNECTION_FAILURE_RESOLUTION_REQUEST);

                /*
                * Thrown if Google Play services canceled the original
                * PendingIntent
                */

            } catch (IntentSender.SendIntentException e) {

                // Log the error
                e.printStackTrace();
            }
        } else {

            // If no resolution is available, display a dialog to the user with the error.
            handleError(new AppException(new Error(ErrorCode.UNABLE_TO_CONNECT_MAP)), Titles.MY_MAP_TITLE);
        }
	}

	@Override
	public void onConnected(Bundle arg0) {

        if (mUpdatesRequested) {

        	startPeriodicUpdates();

        	getCurrentLocation();
        }
	}

    private void getCurrentLocation() {
        B2BLocationManager.getB2BLocationManager().getCurrentLocation(ShowBusinessRouteActivity.this, locationValue);
    }

    public LocationValue locationValue = new LocationValue() {

    	@Override
        public void getCurrentLocation(Location location) {
            // You will get location here if the GPS is enabled
            if(location != null) {

            	currentLocation = location;

            	if (currentLocation != null) {

            		gMap.clear();

            		LatLng currLatLng = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
	            	addMarker(currLatLng,
	            			Misc.CURRENT_LOCATION,
	            			Labels.EMPTY,
	            			BitmapDescriptorFactory.fromResource(R.drawable.map_marketer));

	            	addMarkerForRoutes();
            	}
            }
        }
    };

	private void startPeriodicUpdates() {
        mLocationClient.requestLocationUpdates(mLocationRequest, this);
    }

    private void addMarkerForRoutes() {

    	// If Google Play Services is available
        if (servicesConnected()) {

    		addMarkersToMap();

        	drawPolyLines();
        }
    }

    private boolean servicesConnected() {

        // Check that Google Play services is available
        int resultCode =
                GooglePlayServicesUtil.isGooglePlayServicesAvailable(ShowBusinessRouteActivity.this);

        // If Google Play services is available
        if (ConnectionResult.SUCCESS == resultCode) {
            // In debug mode, log the status
            Log.d(LocationUtils.APPTAG, getString(R.string.play_services_available));

            // Continue
            return true;
        // Google Play services was not available for some reason
        } else {
        	handleError(new AppException(new Error(ErrorCode.UNABLE_TO_CONNECT_MAP)), Titles.MY_MAP_TITLE);
            return false;
        }
    }

    private void addMarkersToMap() {

    	LatLngBounds.Builder builder = new LatLngBounds.Builder();

    	TextIconGenerator iconFactory = new TextIconGenerator(ShowBusinessRouteActivity.this);
		if (Misc.STATUS_COMPLETED.toLowerCase(Locale.getDefault()).equals(
				business.getStatus().toLowerCase(Locale.getDefault()))) {

			iconFactory.setStyle(TextIconGenerator.STYLE_GREEN);
		} else {
			iconFactory.setStyle(TextIconGenerator.STYLE_RED);
		}

		BitmapDescriptor descriptor = BitmapDescriptorFactory.fromBitmap(iconFactory.makeIcon(business.getSeqNumber().toString()));

		Double lat = 0.0;
		Double lng = 0.0;
		if (!Labels.EMPTY.equals(business.getLattitude().trim())) {
			lat = Double.parseDouble(business.getLattitude());
		}
		if (!Labels.EMPTY.equals(business.getLattitude().trim())) {
			lng = Double.parseDouble(business.getLongitude());
		}
		LatLng latLng = new LatLng(lat, lng);
		addMarker(latLng,
    			business.getBusinessName(),
    			business.getAddress(),
    			descriptor);

		builder.include(latLng);

    	CameraUpdate cu = null;

    	cu = CameraUpdateFactory.newLatLngZoom(latLng, 16);

    	gMap.moveCamera(cu);

    	gMap.animateCamera(cu);
    }

    private void addMarker(LatLng latLng, String title, String snippet, BitmapDescriptor bitmap) {

    	// Uses a colored icon.
        gMap.addMarker(new MarkerOptions()
                .position(latLng)
                .title(title)
                .snippet(snippet)
                .icon(bitmap));
    }

    private void drawPolyLines() {

		polyLineOptions = getPolyLineOptions();

    	B2BContext.getInstance().setShowProgress(true);

    	fetchLatLng(business, currentLocation, true);
    }

    private PolylineOptions getPolyLineOptions() {

    	if (polyLineOptions == null) {
	    	polyLineOptions = new PolylineOptions();
	    	polyLineOptions.width(5);
	    	polyLineOptions.color(getResources().getColor(R.color.map_polyline));
	    	polyLineOptions.geodesic(true);
    	}

    	return polyLineOptions;
    }

    private void fetchLatLng(Business source, Location destination, boolean startProgress) {

    	try {
			executeService(RequestCode.GOOGLE_BUSINESS_ROUTE_SERVICE, true, startProgress,
					getGoogleMapInput(source.getLattitude(), source.getLongitude(),
									  String.valueOf(destination.getLatitude()),
									  String.valueOf(destination.getLongitude())));
    	} catch (Exception e) {
    		handleError(new AppException(new Error(ErrorCode.MAP_ROAD_FETCH_FAILED)), Titles.MY_MAP_TITLE);
    	}
    }

    private ServiceInput getGoogleMapInput(String sourceLat, String sourceLong, String destLat, String destLong) {

    	ServiceInput input = new ServiceInput();
    	input.setHeaderRequired(false);
    	input.setInput("");
    	input.setRequestType(RequestType.GET);
    	input.setUrl(makeURL(sourceLat, sourceLong, destLat, destLong));

    	return input;
    }

    public String makeURL (String sourceLat, String sourceLong, String destLat, String destLong ){
    	
        StringBuilder urlString = new StringBuilder();
        urlString.append("http://maps.googleapis.com/maps/api/directions/json");
        urlString.append("?origin=");// from
        urlString.append(sourceLat);
        urlString.append(",");
        urlString.append(sourceLong);
        urlString.append("&destination=");// to
        urlString.append(destLat);
        urlString.append(",");
        urlString.append(destLong);
        urlString.append("&sensor=false&mode=driving&alternatives=true");
        return urlString.toString();
    }

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.imgBusinessRouteBack:
			goBack();
			break;
		case R.id.imgBusinessRouteDone:
			showAlternateRoutes();
			break;
		default:
			break;
		}
	}

	private void showAlternateRoutes() {

		try {
			if (alternateRoutes.size() <= 1) {
				throw new AppException(new Error(ErrorCode.NO_ALT_ROUTE));
			}
			Content.getInstance().addContent(Keys.ALT_BUSINESS_ROUTES, alternateRoutes);
			Content.getInstance().addContent(Keys.ALTERNATE_ROUTE_BUSINESS, business);
			Content.getInstance().addContent(Keys.ALTERNATE_ROUTE_CURR_LOC, currentLocation);
			Content.getInstance().addContent(Keys.ALTERNATE_ROUTE_VM, bDetailViewModel);
			openActivity(ShowBusinessRouteActivity.this, AlternateRouteActivity.class, getBundle(Keys.ALT_BUSINESS_ROUTES));
		} catch (Exception e) {
			convertAndThrow(e, Titles.SHOW_ROUTE_TITLE);
		}
	}

	@Override
    public void processOutput(ServiceResponse result, RequestCode requestCode) {

		try {
			switch (requestCode) {
			case GOOGLE_BUSINESS_ROUTE_SERVICE:
				displayOutput(result);
				break;
			case BUSINESS_TODAY:
				processRoutesOutput(result);
				break;
			case BUSINESS_WEEK:
				processTimelineOutput(result);
				break;
			case BUSINESS_MONTH:
				processTimelineOutput(result);
				break;
			case BUSINESS_SEASON:
				processTimelineOutput(result);
				break;
			case RETRIEVE_BUSINESS_DETAILS:
				processRetrieveBusinessDetailsOutput(result);
				break;
			default:
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    }

	private void processRoutesOutput(ServiceResponse result) {
		if (result.isStatus()) {
			List<Business> businesses = ModelUtil.deserializeArray(
					result.getOutput(),
					new TypeToken<List<Business>>(){}.getType());
			Content.getInstance().addContent(Keys.MY_ROUTE_CONTENT, businesses);
			Content.getInstance().addContent(Keys.FROM_SHOW_ROUTE, "dummy");
			openActivity(ShowBusinessRouteActivity.this, RouteActivity.class, getBundle(Keys.MY_ROUTE_CONTENT));
		} else {
			handleError(new AppException(result.getErrors()), Titles.MY_ROUTE_TITLE);
		}
	}

	private void processTimelineOutput(ServiceResponse result) {

		if (result.isStatus()) {
			List<Business> businesses = ModelUtil.deserializeArray(
					result.getOutput(),
					new TypeToken<List<Business>>(){}.getType());
			Content.getInstance().addContent(Keys.MY_ROUTE_CONTENT, businesses);
			Content.getInstance().addContent(Keys.FROM_BUSINESS_DETAIL, "dummy");
			openActivity(this, RouteActivity.class, getBundle(Keys.MY_ROUTE_CONTENT));
		} else {
			handleError(new AppException(result.getErrors()), Titles.MY_ROUTE_TITLE);
		}
	}

	private void processRetrieveBusinessDetailsOutput(ServiceResponse response) {

		if (response.isStatus()) {
			BusinessDetail detail = (BusinessDetail) ModelUtil.deserialize(response.getOutput(), BusinessDetail.class);
			bDetailViewModel.setSelectedBusiness(detail);
			Content.getInstance().addContent(Keys.RETRIEVE_BUSINESS_DETAILS_KEY, bDetailViewModel);
			openActivity(ShowBusinessRouteActivity.this, BusinessDetailActivity.class, getBundle(Keys.RETRIEVE_BUSINESS_DETAILS_KEY));
		} else {
			handleError(new AppException(response.getErrors()), Titles.BUSINESS_DETAILS_TITLE);
		}
	}

    @SuppressLint("SetJavaScriptEnabled")
	private void displayOutput(ServiceResponse result) {

    	decodeAllRoutes(result.getOutput());
    	polyLineOptions.addAll(alternateRoutes.get(0).getPaths());
		gMap.addPolyline(polyLineOptions);

		txtDistance.setText(alternateRoutes.get(0).getDistance());
		txtTime.setText(alternateRoutes.get(0).getTime());
		String htmlData = alternateRoutes.get(0).getRoute();
		webDirections.getSettings().setJavaScriptEnabled(true);
		webDirections.loadData(htmlData, "text/html", "UTF-8");
    }

    private String getDistance(JSONObject route) {

	    try {

	    	JSONArray legsArray = route.getJSONArray(Misc.LEGS_PARAM_NAME);
			JSONObject legs = legsArray.getJSONObject(0);
			JSONObject distance = legs.getJSONObject(Misc.DISTANCE_PARAM_NAME);
			return distance.getString(Misc.DISTANCE_TEXT_PARAM_NAME);
	    } catch (JSONException e) {
		}

	    return Labels.EMPTY;
    }

	private String getTime(JSONObject route) {

	    try {

	    	JSONArray legsArray = route.getJSONArray(Misc.LEGS_PARAM_NAME);
			JSONObject legs = legsArray.getJSONObject(0);
			JSONObject distance = legs.getJSONObject(Misc.DURATION_PARAM_NAME);
			return distance.getString(Misc.DURATION_TEXT_PARAM_NAME);
	    } catch (JSONException e) {
		}

	    return Labels.EMPTY;
	}

    private String getDirections(JSONObject route) {

	    try {

	    	JSONArray legsArray = route.getJSONArray(Misc.LEGS_PARAM_NAME);
			JSONObject legs = legsArray.getJSONObject(0);
			JSONArray stepsArray = legs.getJSONArray(Misc.STEPS_PARAM_NAME);
			JSONObject step = stepsArray.getJSONObject(0);
			return step.getString(Misc.STEPS_HTML_PARAM_NAME);
	    } catch (JSONException e) {
		}

	    return Labels.EMPTY;
    }

    private String getSummary(JSONObject route) {

	    try {
			return route.getString(Misc.SUMMARY_PARAM_NAME);
	    } catch (JSONException e) {
		}

	    return Labels.EMPTY;
    }

    private void decodeAllRoutes(String json) {

	    try {

	    	alternateRoutes = new ArrayList<AlternateRoute>();
	    	JSONObject jsonObj = new JSONObject(json);
			JSONArray routeArray = jsonObj.getJSONArray(Misc.ROUTE_PARAM_NAME);
			AlternateRoute aRoute;
			for (int i = 0; i < routeArray.length(); i++) {
				JSONObject routes = routeArray.getJSONObject(i);
				JSONObject overviewPolylines = routes.getJSONObject(Misc.OVERVIEW_POLYLINE_PARAM_NAME);
				String encodedString = overviewPolylines.getString(Misc.POINTS_PARAM_NAME);
				aRoute = new AlternateRoute();
				aRoute.setPaths(decodePoly(encodedString));
				aRoute.setDistance(getDistance(routes));
				aRoute.setTime(getTime(routes));
				aRoute.setRoute(getDirections(routes));
				aRoute.setSummary(getSummary(routes));
				alternateRoutes.add(aRoute);
			}
	    } catch (JSONException e) {
		}
	}

	private List<LatLng> decodePoly(String encoded) {

	    List<LatLng> poly = new ArrayList<LatLng>();
	    int index = 0, len = encoded.length();
	    int lat = 0, lng = 0;

	    while (index < len) {
	        int b, shift = 0, result = 0;
	        do {
	            b = encoded.charAt(index++) - 63;
	            result |= (b & 0x1f) << shift;
	            shift += 5;
	        } while (b >= 0x20);
	        int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
	        lat += dlat;

	        shift = 0;
	        result = 0;
	        do {
	            b = encoded.charAt(index++) - 63;
	            result |= (b & 0x1f) << shift;
	            shift += 5;
	        } while (b >= 0x20);
	        int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
	        lng += dlng;

	        LatLng p = new LatLng( (((double) lat / 1E5)),
	                 (((double) lng / 1E5) ));
	        poly.add(p);
	    }

	    return poly;
	}

    /*
     * Called when the Activity is restarted, even before it becomes visible.
     */
    @Override
    public void onStart() {

        super.onStart();

        mUpdatesRequested = true;

        /*
         * Connect the client. Don't re-start any requests here;
         * instead, wait for onResume()
         */
        mLocationClient.connect();
    }

    @Override
    public void onStop() {

        // If the client is connected
        if (mLocationClient.isConnected()) {
            stopPeriodicUpdates();
        }

        // After disconnect() is called, the client is considered "dead".
        mLocationClient.disconnect();

        super.onStop();
    }

    private void stopPeriodicUpdates() {
        mLocationClient.removeLocationUpdates(this);
    }

	@Override
	public void onDisconnected() {
	}

	@Override
	public void onLocationChanged(Location location) {
	}

	@Override
	public void OnMapViewCreated() {
		setUpMapIfNeeded();
		setMapViewParams();
	}

	@Override
	public void OnMapAttached(Activity activity) {
	}

	@Override
	public void onBackPressed() {

		try {
			goBack();
		} catch (Exception e) {
			convertAndThrow(e, Titles.SHOW_ROUTE_TITLE);
		}
	}

	private void goBack() {

		ServiceInvoker.checkNetworkAvailability();

		B2BContext.getInstance().setShowProgress(true);
		if (fromDetails) {
			executeService(RequestCode.RETRIEVE_BUSINESS_DETAILS, true, getBusinessDetailsInput(bDetailViewModel.getSelectedBusiness()));
		} else {
			callTimelineService();
		}
	}

	public void callTimelineService() {

		TimeLine timeLine = (TimeLine) Content.resolve(Keys.SELECTED_TIMELINE);
		try {
			switch (timeLine) {
			case TODAY:
				B2BContext.getInstance().setShowProgress(true);
				executeService(RequestCode.BUSINESS_TODAY, true, RouteUtil.getRouteInput(TimeLine.TODAY, 0));
				break;
			case WEEK:
				B2BContext.getInstance().setShowProgress(true);
				executeService(RequestCode.BUSINESS_WEEK, true, RouteUtil.getRouteInput(TimeLine.WEEK, 0));
				break;
			case MONTH:
				B2BContext.getInstance().setShowProgress(true);
				executeService(RequestCode.BUSINESS_MONTH, true, RouteUtil.getRouteInput(TimeLine.MONTH, 0));
				break;
			case TAX_SEASON:
				int month = 0;
				if (!Content.containsKey(Keys.SELECTED_TAX_SEASON)) {
					month = Calendar.JANUARY;
				} else {
					Button button = (Button) Content.resolve(Keys.SELECTED_TAX_SEASON);
					month = RouteUtil.getMonth(button);
				}
				B2BContext.getInstance().setShowProgress(true);
				executeService(RequestCode.BUSINESS_SEASON, true, RouteUtil.getRouteInput(TimeLine.TAX_SEASON, month));
				break;
			}
		} catch (Exception e) {
			convertAndThrow(e, Titles.MY_ROUTE_TITLE);
		}
	}

	private ServiceInput getBusinessDetailsInput(BusinessDetail bDetail) {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getBusinessDetailsJSON(bDetail));
		input.setUrl(URL.RETRIEVE_BUSSINESS_DETAIL);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getBusinessDetailsJSON(BusinessDetail bDetail) {

		RetrieveBusinessInput bdInput = new RetrieveBusinessInput();
		bdInput.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());
		bdInput.setAssignmentId(bDetail.getAssignmentId());
		bdInput.setBusinessId(bDetail.getBusinessId());
		return ModelUtil.serialize(bdInput);
	}
}

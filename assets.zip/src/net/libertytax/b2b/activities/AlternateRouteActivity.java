package net.libertytax.b2b.activities;

import java.util.List;

import net.libertytax.b2b.R;
import net.libertytax.b2b.adapters.AlternatePathAdapter;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.Misc;
import net.libertytax.b2b.base.Constants.Titles;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.ServiceInvoker;
import net.libertytax.b2b.fragments.B2BMapFragment;
import net.libertytax.b2b.fragments.B2BMapFragment.OnMapAttachedListener;
import net.libertytax.b2b.fragments.B2BMapFragment.OnMapViewCreatedListener;
import net.libertytax.b2b.maputils.ui.TextIconGenerator;
import net.libertytax.b2b.model.AlternateRoute;
import net.libertytax.b2b.model.Business;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout.LayoutParams;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class AlternateRouteActivity extends BaseActivity
				implements OnItemClickListener,
						   OnMapAttachedListener,
						   OnMapViewCreatedListener,
						   OnClickListener {

	private ListView lstAlternatePath;
    private GoogleMap gMap;
	private B2BMapFragment mapFragment;
	private ImageButton imgBtBack;

	private List<AlternateRoute> alternateRoutes;
	private Business business;
	private Location currentLocation;

    private PolylineOptions polyLineOptions;
    private boolean mapCreated;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.alternate_path);
		super.onCreate(savedInstanceState);
		addMapFragment(R.id.relAlternateRouteMap, getMapFragment());
	}

	@Override
	protected void prepareControls() {

		if (!mapCreated) return;

		lstAlternatePath = (ListView) findViewById(R.id.lstAlternateRoute);
		imgBtBack = (ImageButton) findViewById(R.id.imgAlternateRouteBack);
	}

	private B2BMapFragment getMapFragment() {

		if (mapFragment == null) {
			mapFragment = new B2BMapFragment();
			mapFragment.setListener(this);
			mapFragment.setViewListener(this);
		}
		return mapFragment;
	}

	@Override
	protected void subscribeEvents() {
		if (!mapCreated) return;
		lstAlternatePath.setOnItemClickListener(this);
		imgBtBack.setOnClickListener(this);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void applyDefaults() {

		if (!mapCreated) return;

		alternateRoutes = (List<AlternateRoute>) data;
		business = (Business) Content.resolve(Keys.ALTERNATE_ROUTE_BUSINESS);
		currentLocation = (Location) Content.resolve(Keys.ALTERNATE_ROUTE_CURR_LOC);
	}

	private void addMapFragment(int resource, Fragment fragment) {

        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();

        ft.add(resource, fragment);
        ft.commitAllowingStateLoss();
    }

    private void setUpMapIfNeeded() {

    	// Do a null check to confirm that we have not already instantiated the map.
        if (gMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            gMap = mapFragment.getMap();
        }
    }

	private void setMapViewParams() {
		mapFragment.getView().getLayoutParams().width = LayoutParams.MATCH_PARENT;
		mapFragment.getView().getLayoutParams().height = LayoutParams.MATCH_PARENT;
	}

	@Override
	public void onItemClick(AdapterView<?> adapterView, View view, int position, long layout) {
		Content.getInstance().addContent(Keys.SELECTED_ALTERNATE_PATH_INDEX, position);
		markRoute(position + 1);
	}

	@Override
	public void OnMapViewCreated() {

		mapCreated = true;
		prepareControls();
		subscribeEvents();
		applyDefaults();
		setUpMapIfNeeded();
		setMapViewParams();
		populateList();
		getRoutes();
		markRoute(0);
	}

	private void populateList() {

		AlternatePathAdapter adapter = new AlternatePathAdapter(AlternateRouteActivity.this, alternateRoutes.subList(1, alternateRoutes.size()));
		lstAlternatePath.setAdapter(adapter);
	}

	@SuppressWarnings("unchecked")
	private void getRoutes() {
		alternateRoutes = (List<AlternateRoute>) data;
	}

	private void markRoute(int position) {

		AlternateRoute route = alternateRoutes.get(position);

		gMap.clear();

    	addMarkerForRoutes(route);
	}

    private void addMarkerForRoutes(AlternateRoute paths) {

    	addMarkersToMap();

    	drawPolyLines(paths);
    }

    private void drawPolyLines(AlternateRoute paths) {

		polyLineOptions = getPolyLineOptions();
		polyLineOptions.addAll(paths.getPaths());
		gMap.addPolyline(polyLineOptions);
    }

    private PolylineOptions getPolyLineOptions() {

    	polyLineOptions = new PolylineOptions();
    	polyLineOptions.width(5);
    	polyLineOptions.color(getResources().getColor(R.color.map_polyline));
    	polyLineOptions.geodesic(true);

    	return polyLineOptions;
    }

    private void addMarkersToMap() {

    	LatLngBounds.Builder builder = new LatLngBounds.Builder();

    	TextIconGenerator iconFactory = new TextIconGenerator(AlternateRouteActivity.this);
		if (Labels.COMPLETED.equals(business.getStatus())) {
			iconFactory.setStyle(TextIconGenerator.STYLE_GREEN);
		} else {
			iconFactory.setStyle(TextIconGenerator.STYLE_RED);
		}

		BitmapDescriptor descriptor = BitmapDescriptorFactory.fromBitmap(iconFactory.makeIcon(business.getSeqNumber().toString()));

		Double lat = 0.0;
		Double lng = 0.0;
		if (!Labels.EMPTY.equals(business.getLattitude().trim())) {
			lat = Double.parseDouble(business.getLattitude());
		}
		if (!Labels.EMPTY.equals(business.getLattitude().trim())) {
			lng = Double.parseDouble(business.getLongitude());
		}
		LatLng latLng = new LatLng(lat, lng);
		addMarker(latLng,
    			business.getBusinessName(),
    			business.getAddress(),
    			descriptor);

		LatLng currLatLng = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
    	addMarker(currLatLng,
    			Misc.CURRENT_LOCATION,
    			Labels.EMPTY,
    			BitmapDescriptorFactory.fromResource(R.drawable.map_marketer));

		builder.include(latLng);
		builder.include(currLatLng);

    	CameraUpdate cu = null;

    	cu = CameraUpdateFactory.newLatLngZoom(latLng, 16);

    	gMap.moveCamera(cu);

    	gMap.animateCamera(cu);
    }

    private void addMarker(LatLng latLng, String title, String snippet, BitmapDescriptor bitmap) {

    	// Uses a colored icon.
        gMap.addMarker(new MarkerOptions()
                .position(latLng)
                .title(title)
                .snippet(snippet)
                .icon(bitmap));
    }

	@Override
	public void OnMapAttached(Activity activity) {
	}

	@Override
	public void onBackPressed() {

		try {
			goBack();
		} catch (Exception e) {
			convertAndThrow(e, Titles.ADD_NOTE_TITLE);
		}
	}

	@Override
	public void onClick(View v) {

		try {
			switch (v.getId()) {
			case R.id.imgAlternateRouteBack:
				goBack();
				break;
			default:
				break;
			}
		} catch (Exception e) {
			convertAndThrow(e, Titles.ALTERNATE_PATH_TITLE);
		}
	}

	private void goBack() {

		try {
			showProgress(AlternateRouteActivity.this, Labels.EMPTY, Misc.KEY_LOADING);
			ServiceInvoker.checkNetworkAvailability();
			openActivity(AlternateRouteActivity.this, ShowBusinessRouteActivity.class, getBundle(Keys.ALTERNATE_ROUTE_BUSINESS));
		} catch (Exception e) {
			convertAndThrow(e, Titles.ALTERNATE_PATH_TITLE);
		} finally {
			dismissProgress();
		}
	}
}
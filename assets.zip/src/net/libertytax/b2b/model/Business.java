package net.libertytax.b2b.model;

import java.util.Date;

import net.libertytax.b2b.util.DateUtil;


public class Business {

	private String BusinessId;
	private int AssignmentId;
	private String BusinessName;
	private String CompletedDate;
	private String CompletedTime;
	private String AssignedDate;
	private String Address;
	private String Office;
	private String Status;
	private Integer SeqNumber;
	private String Lattitude;
	private String Longitude;
	private int ItemCount;
	private int CouponCount;

	public void setBusinessId(String businessId) { BusinessId = businessId; }
	public void setAssignmentId(int assignmentId) { AssignmentId = assignmentId; }
	public void setBusinessName(String businessName) { BusinessName = businessName; }
	public void setCompletedDate(String completedDate) { CompletedDate = completedDate; }
	public void setCompletedTime(String completedTime) { CompletedTime = completedTime; }
	public void setAssignedDate(String assignedDate) { AssignedDate = assignedDate; }
	public void setAddress(String address) { Address = address; }
	public void setOffice(String office) { Office = office; }
	public void setLattitude(String lattitude) { Lattitude = lattitude; }
	public void setLongitude(String longitude) { Longitude = longitude; }
	public void setItemCount(int itemCount) { ItemCount = itemCount; }
	public void setCouponCount(int couponCount) { CouponCount = couponCount; }
	public void setStatus(String status) { Status = status; }
	public void setSeqNumber(Integer seqNumber) { SeqNumber = seqNumber; }

	public String getBusinessId() { return BusinessId; }
	public int getAssignmentId() { return AssignmentId; }
	public String getBusinessName() { return BusinessName; }
	public String getCompletedDate() { return CompletedDate; }
	public String getCompletedTime() { return CompletedTime; }
	public String getAssignedDate() { return AssignedDate; }
	public String getAddress() { return Address; }
	public String getOffice() { return Office; }
	public String getStatus() { return Status; }
	public Integer getSeqNumber() { return SeqNumber; } 
	public String getLattitude() { return Lattitude; }
	public String getLongitude() { return Longitude; }
	public int getItemCount() { return ItemCount; }
	public int getCouponCount() { return CouponCount; }
	public Date getCompletedDateObj() {
		if (CompletedDate == null || "".equals(CompletedDate.trim())) return null;
		return DateUtil.toDate(CompletedDate);
	}
	public Date getAssignedDateObj() {
		if (AssignedDate == null || "".equals(AssignedDate.trim())) return null;
		return DateUtil.toDate(AssignedDate);
	}
}

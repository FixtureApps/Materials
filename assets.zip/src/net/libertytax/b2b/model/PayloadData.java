package net.libertytax.b2b.model;

public class PayloadData {

	private String Content;

	public String getContent() { return Content; }

	public void setContent(String content) { Content = content; }
}

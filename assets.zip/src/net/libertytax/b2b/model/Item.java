package net.libertytax.b2b.model;

public class Item {

	private int ItemId;
	private String ItemName;
	private int ItemCount;
	private int updatedItemCount;

	public void setItemId(int itemId) { ItemId = itemId; }
	public void setItemName(String itemName) { ItemName = itemName; }
	public void setItemCount(int itemCount) { ItemCount = itemCount; }
	public void setUpdatedItemCount(int updatedItemCount) { this.updatedItemCount = updatedItemCount; }

	public int getItemId() { return ItemId; }
	public String getItemName() { return ItemName; }
	public int getItemCount() { return ItemCount; }
	public int getUpdatedItemCount() { return updatedItemCount; }
}

package net.libertytax.b2b.model;

import java.util.List;

public class CompleteAssignment {

	private String CompletedDate;
	private int AssignmentId;
	private int MarketerId;
	private String Status;
	private String Feedback;
	private int Ratings;
	private List<Item> Items;
	private List<Coupon> Coupons;

	public void setCompletedDate(String completedDate) { CompletedDate = completedDate; }
	public void setAssignmentId(int assignmentId) { AssignmentId = assignmentId; }
	public void setMarketerId(int marketerId) { MarketerId = marketerId; }
	public void setStatus(String status) { Status = status; }
	public void setFeedback(String feedback) { Feedback = feedback; }
	public void setRatings(int ratings) { Ratings = ratings; }
	public void setItems(List<Item> items) { Items = items; }
	public void setCoupons(List<Coupon> coupons) { Coupons = coupons; }

	public String getCompletedDate() { return CompletedDate; }
	public int getAssignmentId() { return AssignmentId; }
	public int getMarketerId() { return MarketerId; }
	public String getStatus() { return Status; }
	public String getFeedback() { return Feedback; }
	public int getRatings() { return Ratings; }
	public List<Item> getItems() { return Items; }
	public List<Coupon> getCoupons() { return Coupons; }
}
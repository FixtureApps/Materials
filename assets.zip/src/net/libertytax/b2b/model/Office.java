package net.libertytax.b2b.model;

public class Office {

	private String OfficeId;
	private String OfficeName;
	private boolean IsDefaultOffice;

	public void setOfficeId(String officeId) { OfficeId = officeId; }
	public void setOfficeName(String officeName) { OfficeName = officeName; }
	public void setIsDefaultOffice(boolean isDefaultOffice) { IsDefaultOffice = isDefaultOffice; }

	public String getOfficeId() { return OfficeId; }
	public String getOfficeName() { return OfficeName; }
	public boolean isIsDefaultOffice() { return IsDefaultOffice; }
}

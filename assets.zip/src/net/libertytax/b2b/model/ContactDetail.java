package net.libertytax.b2b.model;

public class ContactDetail {

	private int BusinessContactId;
	private String BusinessId;
	private String ContactPerson;
	private String PhoneNumber;
	private String Designation;
	private String EmailId;
	private String Address;
	private String MobileNumber;
	private String Fax;

	public void setBusinessContactId(int businessContactId) { BusinessContactId = businessContactId; }
	public void setBusinessId(String businessId) { BusinessId = businessId; }
	public void setContactPerson(String contactPerson) { ContactPerson = contactPerson; }
	public void setPhoneNumber(String phoneNumber) { PhoneNumber = phoneNumber; }
	public void setDesignation(String designation) { Designation = designation; }
	public void setEmailId(String emailId) { EmailId = emailId; }
	public void setAddress(String address) { Address = address; }
	public void setMobileNumber(String mobileNumber) { MobileNumber = mobileNumber; }
	public void setFax(String fax) { Fax = fax; }

	public int getBusinessContactId() { return BusinessContactId; }
	public String getBusinessId() { return BusinessId; }
	public String getContactPerson() { return ContactPerson; }
	public String getPhoneNumber() { return PhoneNumber; }
	public String getDesignation() { return Designation; }
	public String getEmailId() { return EmailId; }
	public String getAddress() { return Address; }
	public String getMobileNumber() { return MobileNumber; }
	public String getFax() { return Fax; }
}

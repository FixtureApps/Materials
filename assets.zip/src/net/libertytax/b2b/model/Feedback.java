package net.libertytax.b2b.model;

public enum Feedback {

	NONE,
	GOOD,
	FAIR,
	BAD;
}

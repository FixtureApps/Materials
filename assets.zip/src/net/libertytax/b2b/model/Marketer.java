package net.libertytax.b2b.model;

public class Marketer {

	private int MarketerId;
	private String MarketerName;
	private int Status;
	private String DefaultOfficeId;
	private String DefaultOfficeName;
	private String Lattitude;
	private String Longitude;
	private String LastUpdatedTime;

	public void setMarketerId(int marketerId) { MarketerId = marketerId; }
	public void setMarketerName(String marketerName) { MarketerName = marketerName; }
	public void setStatus(int status) { Status = status; }
	public void setDefaultOfficeId(String defaultOfficeId) { DefaultOfficeId = defaultOfficeId; }
	public void setDefaultOfficeName(String defaultOfficeName) { DefaultOfficeName = defaultOfficeName; }
	public void setLattitude(String lattitude) { Lattitude = lattitude; }
	public void setLongitude(String longitude) { Longitude = longitude; }
	public void setLastUpdatedTime(String lastUpdatedTime) { LastUpdatedTime = lastUpdatedTime; }

	public int getMarketerId() { return MarketerId; }
	public String getMarketerName() { return MarketerName; }
	public int getStatus() { return Status; }
	public String getDefaultOfficeId() { return DefaultOfficeId; }
	public String getDefaultOfficeName() { return DefaultOfficeName; }
	public String getLattitude() { return Lattitude; }
	public String getLongitude() { return Longitude; }
	public String getLastUpdatedTime() { return LastUpdatedTime; }
} 
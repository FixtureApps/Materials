package net.libertytax.b2b.model;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class BusinessDetailViewModel {

	private List<Business> businesses;
	private Map<Date, List<Business>> businessesMap;
	private TimeLine timeLine;
	private BusinessDetail selectedBusiness;
	private int selectedIndex;

	public void setBusinesses(List<Business> businesses) { this.businesses = businesses; }
	public void setSelectedBusiness(BusinessDetail selectedBusiness) { this.selectedBusiness = selectedBusiness; }
	public void setBusinessesMap(Map<Date, List<Business>> businessesMap) { this.businessesMap = businessesMap; }
	public void setTimeLine(TimeLine timeLine) { this.timeLine = timeLine; }
	public void setSelectedIndex(int selectedIndex) { this.selectedIndex = selectedIndex; }

	public List<Business> getBusinesses() { return businesses; }
	public BusinessDetail getSelectedBusiness() { return selectedBusiness; }
	public Map<Date, List<Business>> getBusinessesMap() { return businessesMap; }
	public TimeLine getTimeLine() { return timeLine; }
	public int getSelectedIndex() { return selectedIndex; }
}

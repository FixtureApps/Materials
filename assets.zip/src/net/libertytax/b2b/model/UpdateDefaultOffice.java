package net.libertytax.b2b.model;

public class UpdateDefaultOffice {

	private int MarketerId;
	private String DefaultOfficeId;

	public void setMarketerId(int marketerId) { MarketerId = marketerId; }
	public void setDefaultOfficeId(String defaultOfficeId) { DefaultOfficeId = defaultOfficeId; }

	public int getMarketerId() { 		return MarketerId; }
	public String getDefaultOfficeId() { return DefaultOfficeId; }
}

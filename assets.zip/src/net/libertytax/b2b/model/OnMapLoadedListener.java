package net.libertytax.b2b.model;

public interface OnMapLoadedListener {
	void mapLoaded();
}

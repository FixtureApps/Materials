package net.libertytax.b2b.model;

public enum TaxSeasons {

	JAN,
	FEB,
	MAR,
	APR,
	MAY
}

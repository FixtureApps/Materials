package net.libertytax.b2b.model;

import java.util.List;

public class BusinessDetail {

	private int AssignmentId;
	private String BusinessId;
	private String BusinessName;
	private String OfficeId;
	private String Address;
	private String AssignmentDate;
	private String Status;
	private List<Note> Notes;
	private String Feedback;
	private int Ratings;
	private List<ContactDetail> BusinessContactDetails;
	private List<Item> Items;
	private List<Coupon> Coupons;

	public void setAssignmentId(int assignmentId) { AssignmentId = assignmentId; }
	public void setBusinessId(String businessId) { BusinessId = businessId; }
	public void setBusinessName(String businessName) { BusinessName = businessName; }
	public void setOfficeId(String officeId) { OfficeId = officeId; }
	public void setAddress(String address) { Address = address; }
	public void setAssignmentDate(String assignmentDate) { AssignmentDate = assignmentDate; }
	public void setStatus(String status) { Status = status; }
	public void setNotes(List<Note> notes) { Notes = notes; }
	public void setFeedback(String feedback) { Feedback = feedback; }
	public void setRatings(int ratings) { Ratings = ratings; }
	public void setBusinessContactDetails(List<ContactDetail> businessContactDetails) { BusinessContactDetails = businessContactDetails; }
	public void setItems(List<Item> items) { Items = items; }
	public void setCoupons(List<Coupon> coupons) { Coupons = coupons; }

	public int getAssignmentId() { return AssignmentId; }
	public String getBusinessId() { return BusinessId; }
	public String getBusinessName() { return BusinessName; }
	public String getOfficeId() { return OfficeId; }
	public String getAddress() { return Address; }
	public String getAssignmentDate() { return AssignmentDate; }
	public String getStatus() { return Status; }
	public List<Note> getNotes() { return Notes; }
	public String getFeedback() { return Feedback; }
	public int getRatings() { return Ratings; }
	public List<ContactDetail> getBusinessContactDetails() { return BusinessContactDetails; }
	public List<Item> getItems() { return Items; }
	public List<Coupon> getCoupons() { return Coupons; }
}

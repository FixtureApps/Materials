package net.libertytax.b2b.model;

import java.util.HashMap;
import java.util.Map;

public class DetailDisplay {

	private int layoutId;
	private String viewId;
	private ViewType viewType;
	private Map<String, Object> valuesMap;

	public void setLayoutId(int layoutId) { this.layoutId = layoutId; }
	public void setViewId(String viewId) { this.viewId = viewId; }
	public void setViewType(ViewType viewType) { this.viewType = viewType; }

	public int getLayoutId() { return layoutId; }
	public String getViewId() { return viewId; }
	public ViewType getViewType() { return viewType; }
	public Map<String, Object> getValuesMap() {

		if (valuesMap == null) {
			valuesMap = new HashMap<String, Object>();
		}
		return valuesMap;
	}

	public static class DetailConst {

		public static final String HEADER_KEY = "header_key";
		public static final String HEADER_ADD_KEY = "header_add_key";

		public static final String DETAIL_HEADER_VALUE = "BUSINESS DETAILS";
		public static final String CONTACT_HEADER_VALUE = "CONTACT DETAILS";
		public static final String ITEM_HEADER_VALUE = "ITEM DETAILS";
		public static final String COUPON_HEADER_VALUE = "COUPONS";
		public static final String FEEDBACK_HEADER_VALUE = "FEEDBACK";
		public static final String NOTES_HEADER_VALUE = "NOTES";
		public static final String EMPTY_HEADER_VALUE = "";

		public static final String NO_NOTES_VALUE = "No note(s) added";

		public static final String BUSINESS_DETAIL_KEY = "business_detail_key";
		public static final String BUSINESS_DETAIL_VALUE = "business_detail_value";
		public static final String BUSINESS_DETAIL_ADDRESS = "business_detail_address";

		public static final String BUSINESS_NAME = "Business Name";
		public static final String BUSINESS_ADDRESS = "Address";

		public static final String CONTACT_DETAIL_TEXT1 = "contact_header_text1";
		public static final String CONTACT_DETAIL_TEXT2 = "contact_header_text2";
		public static final String CONTACT_DETAIL_TAG = "contact_header_tag";

		public static final String ITEM_NAME = "item_name";
		public static final String ITEM_COUNT = "item_count";
		public static final String ITEM_KEY = "item_key";
		public static final String ITEM_STATUS = "item_status";

		public static final String COUPON_NAME = "coupon_name";
		public static final String COUPON_COUNT = "coupon_count";
		public static final String COUPON_KEY = "coupon_key";
		public static final String COUPON_STATUS = "coupon_status";

		public static final String FEEDBACK_VALUE = "feedback_value";
		public static final String FEEDBACK_STATUS = "feedback_status";

		public static final String NOTE_VALUE = "note_value";

		public static final String RATING_VALUE = "rating_value";

		public static final String STATUS_VALUE = "status_value";

		public static final String SHOW_DIVIDER = "show_divider";
	}

	public enum ViewType {
		HEADER,
		BUSINESS_DETAIL,
		CONTACT_DETAIL,
		ITEM,
		COUPON,
		FEEDBACK,
		NOTE,
		DELIVERED,
		RATING,
		EMPTY;
	}
}

package net.libertytax.b2b.model;

public class Note {

	private int NoteId;
	private String Description;

	public void setNoteId(int noteId) { NoteId = noteId; }
	public void setDescription(String description) { Description = description; }

	public int getNoteId() { return NoteId; }
	public String getDescription() { return Description; }
}

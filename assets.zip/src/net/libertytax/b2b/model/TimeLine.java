package net.libertytax.b2b.model;

public enum TimeLine {

	TODAY,
	WEEK,
	MONTH,
	TAX_SEASON;
}

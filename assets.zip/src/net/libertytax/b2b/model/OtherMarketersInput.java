package net.libertytax.b2b.model;

import java.util.List;

public class OtherMarketersInput {

	private int MarketerId;
	private List<String> OfficeIds;

	public void setMarketerId(int marketerId) { MarketerId = marketerId; }
	public void setOfficeIds(List<String> officeIds) { OfficeIds = officeIds; }

	public int getMarketerId() { return MarketerId; }
	public List<String> getOfficeIds() { return OfficeIds; }
}

package net.libertytax.b2b.model;

public class Coupon {

	private int CouponId;
	private String CouponName;
	private int CouponCount;

	public void setCouponId(int couponId) { CouponId = couponId; }
	public void setCouponName(String couponName) { CouponName = couponName; }
	public void setCouponCount(int couponCount) { CouponCount = couponCount; }

	public int getCouponId() { return CouponId; }
	public String getCouponName() { return CouponName; }
	public int getCouponCount() { return CouponCount; }
}

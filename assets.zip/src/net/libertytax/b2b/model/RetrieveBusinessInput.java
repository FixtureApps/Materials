package net.libertytax.b2b.model;

public class RetrieveBusinessInput {

	private int MarketerId;
	private int AssignmentId;
	private String BusinessId;

	public void setMarketerId(int marketerId) { MarketerId = marketerId; }
	public void setAssignmentId(int assignmentId) { AssignmentId = assignmentId; }
	public void setBusinessId(String businessId) { BusinessId = businessId; }

	public int getMarketerId() { return MarketerId; }
	public int getAssignmentId() { return AssignmentId; }
	public String getBusinessId() { return BusinessId; }
}

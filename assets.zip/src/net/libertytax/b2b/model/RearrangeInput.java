package net.libertytax.b2b.model;

import java.util.Date;
import java.util.List;

public class RearrangeInput {

	private int MarketerId;
	private Date AssignmentDate;
	private List<RearrangeSequence> AssignmentSequence;

	public void setMarketerId(int marketerId) { MarketerId = marketerId; }
	public void setAssignmentDate(Date assignmentDate) { AssignmentDate = assignmentDate; }
	public void setAssignmentSequence(List<RearrangeSequence> assignmentSequence) { AssignmentSequence = assignmentSequence; }

	public int getMarketerId() { return MarketerId; }
	public Date getAssignmentDate() { return AssignmentDate; }
	public List<RearrangeSequence> getAssignmentSequence() { return AssignmentSequence; }

	public static class RearrangeSequence {

		private int AssignmentId;
		private int SequenceNumber;

		public void setAssignmentId(int assignmentId) { AssignmentId = assignmentId; }
		public void setSequenceNumber(int sequenceNumber) { SequenceNumber = sequenceNumber; }

		public int getAssignmentId() { return AssignmentId; }
		public int getSequenceNumber() { return SequenceNumber; }
	}
}
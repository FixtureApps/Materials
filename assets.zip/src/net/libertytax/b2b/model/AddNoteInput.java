package net.libertytax.b2b.model;

public class AddNoteInput {

	private int AssignmentId;
	private String Description;

	public void setAssignmentId(int assignmentId) { AssignmentId = assignmentId; }
	public void setDescription(String description) { Description = description; }

	public int getAssignmentId() { return AssignmentId; }
	public String getDescription() { return Description; }
}

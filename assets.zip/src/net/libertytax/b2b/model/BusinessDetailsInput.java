package net.libertytax.b2b.model;

import java.util.Date;

public class BusinessDetailsInput {

	private int MarketerId;
	private Date StartDate;
	private Date EndDate;

	public void setMarketerId(int marketerId) { MarketerId = marketerId; }
	public void setStartDate(Date startDate) { StartDate = startDate; }
	public void setEndDate(Date endDate) { EndDate = endDate; }

	public int getMarketerId() { return MarketerId; }
	public Date getStartDate() { return StartDate; }
	public Date getEndDate() { return EndDate; }
}

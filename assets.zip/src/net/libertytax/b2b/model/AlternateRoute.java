package net.libertytax.b2b.model;

import java.util.List;

import com.google.android.gms.maps.model.LatLng;

public class AlternateRoute {

	private List<LatLng> paths;
	private String route;
	private String distance;
	private String time;
	private String summary;

	public void setPaths(List<LatLng> paths) { this.paths = paths; }
	public void setRoute(String route) { this.route = route; }
	public void setDistance(String distance) { this.distance = distance; }
	public void setTime(String time) { this.time = time; }
	public void setSummary(String summary) { this.summary = summary; }

	public List<LatLng> getPaths() { return paths; }
	public String getRoute() { return route; }
	public String getDistance() { return distance; }
	public String getTime() { return time; }
	public String getSummary() { return summary; }
}

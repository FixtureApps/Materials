package net.libertytax.b2b.model;

public class LoginResult {

	private int MarketerId;

	public int getMarketerId() { return MarketerId; }

	public void setMarketerId(int marketerId) { MarketerId = marketerId; }
}

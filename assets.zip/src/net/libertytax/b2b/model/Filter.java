package net.libertytax.b2b.model;

public enum Filter {

	ALL,
	COMPLETED,
	INPROGRESS,
	INCOMPLETE,
	CLOSEST;
}

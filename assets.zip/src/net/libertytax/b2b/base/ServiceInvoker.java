/*
* @(#)ServiceInvoker.java
*
* Copyright (c) 2013, Liberty Tax Service.
* All rights reserved.
*
* Use is subject to license terms. This software is protected by
* copyright law and international treaties. Unauthorized reproduction or
* distribution of this program, or any portion of it, may result in severe
* civil and criminal penalties, and will be prosecuted to the maximum extent.
*/
package net.libertytax.b2b.base;

import java.io.InputStream;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import net.libertytax.b2b.base.Constants.HeaderKey;
import net.libertytax.b2b.base.Constants.HeaderValue;
import net.libertytax.b2b.util.B2BContext;
import net.libertytax.b2b.util.ModelUtil;
import net.libertytax.b2b.util.Vault;
import net.libertytax.b2b.util.ZipDecryptInputStream;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpResponse;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;

import android.content.Context;
import android.net.ConnectivityManager;

import com.google.gson.reflect.TypeToken;

public class ServiceInvoker {

	public static HttpContext httpContext;
	private final static byte[] zipperByteArr = { -127, -108, -117, -18, -52, 13, 64, 53, -109, -97, -34, 97, -44, 90, 97, -80, 27, 39, 122, -50, 115, 60, 45, -58, -79, -58, -19, -38, 21, -55, -25,
		-35 };

	private static HttpClient getHttpClient() {

		if (httpContext == null) {

			// Create a local instance of cookie store
			CookieStore cookieStore = new BasicCookieStore();
			// Create local httpContext
			httpContext = new BasicHttpContext();
			// Bind custom cookie store to the httpContext
			httpContext.setAttribute(ClientContext.COOKIE_STORE, cookieStore);
		}

		HttpParams params = new BasicHttpParams();
		return new DefaultHttpClient(params);
	}

	public static String encryptData(String data, String vaultKey) throws Exception {

		byte[] key = Vault.encryptPayload(data, vaultKey.getBytes());
		return new String(Base64.encodeBase64(key));
	}

	public static ServiceResponse invokeGetService(String url) throws Exception {

		checkNetworkAvailability();
		HttpResponse httpResponse = getHttpClient().execute(getHttpGet(url), httpContext);
		processHttpResponse(httpResponse);
		return processServiceResponse(httpResponse);
	}

	public static ServiceResponse invokeDeleteService(String url) throws Exception {

		checkNetworkAvailability();
		HttpResponse httpResponse = getHttpClient().execute(getHttpDelete(url), httpContext);
		processHttpResponse(httpResponse);
		return processServiceResponse(httpResponse);
	}

	public static ServiceResponse invokePutService(String url) throws Exception {

		checkNetworkAvailability();
		HttpResponse httpResponse = getHttpClient().execute(getHttpPut(url), httpContext);
		processHttpResponse(httpResponse);
		return processServiceResponse(httpResponse);
	}

	public static ServiceResponse invokePostService(String url,
										   String jsonString,
										   boolean isHeaderRequired) throws Exception {

		checkNetworkAvailability();
		HttpResponse httpResponse = getHttpClient().execute(getHttpPost(url, jsonString, isHeaderRequired), httpContext);
		processHttpResponse(httpResponse);
		return processServiceResponse(httpResponse);
	}

	private static void processHttpResponse(HttpResponse response) throws Exception {

		if ((response.getStatusLine().getStatusCode() >= 400 &&
			response.getStatusLine().getStatusCode() <= 403)) {
			throw new AppException(ErrorCode.INVALID_REQUEST);
		} else if (response.getStatusLine().getStatusCode() == 404) {
			throw new AppException(ErrorCode.RESOURCE_NOT_FOUND);
		}
	}

	private static ServiceResponse processServiceResponse(HttpResponse httpResponse) throws Exception {

		ServiceResponse response = null;
		if (httpResponse.getStatusLine().getStatusCode() == 200) {

			response = new ServiceResponse();
			response.setStatus(true);
			String output = EntityUtils.toString(httpResponse.getEntity());
			response.setOutput(output);
		} else if (httpResponse.getStatusLine().getStatusCode() == 500) {

			response = new ServiceResponse();
			response.setStatus(false);
			@SuppressWarnings("unchecked")
			List<Error> errs = (List<Error>)ModelUtil.deserializeArray(
					EntityUtils.toString(httpResponse.getEntity()), new TypeToken<List<Error>>(){}.getType());
			response.setErrors(errs);
		}
		return response;
	}

	private static HttpPost getHttpPost(String url,
										String jsonString,
										boolean headerRequired) throws Exception {

		HttpPost httpPost = new HttpPost(url);
		httpPost.setHeader(HeaderKey.CONTENT_TYPE, HeaderValue.CONTENT_TYPE);
		StringEntity entity = new StringEntity(jsonString);
		httpPost.setEntity(entity);
		return httpPost;
	}

	private static HttpGet getHttpGet(String url) {

		HttpGet httpGet = new HttpGet(url);
		return httpGet;
	}

	private static HttpDelete getHttpDelete(String url) {

		HttpDelete httpDelete = new HttpDelete(url);
		return httpDelete;
	}

	private static HttpPut getHttpPut(String url) {

		HttpPut httpPut = new HttpPut(url);
		return httpPut;
	}

	public static void checkNetworkAvailability() {

		ConnectivityManager connectivityManager =
				(ConnectivityManager) (B2BContext.getInstance().getActiveContext()).
				getSystemService(Context.CONNECTIVITY_SERVICE);

		boolean availabe = (connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected() && connectivityManager.getActiveNetworkInfo().isAvailable());

		if (!availabe) { throw new AppException(ErrorCode.NETWORK_NOT_CONNECTED); }
	}

	public static byte[] getPayloadData(InputStream fis) throws Exception {

		ZipDecryptInputStream zdis = new ZipDecryptInputStream(fis, new String(Vault.decrypt(zipperByteArr, true)));
		ZipInputStream zis = new ZipInputStream(zdis);
		ZipEntry ze = null;
		byte[] buffer = null;

		while ( (ze = zis.getNextEntry()) != null ) {
			buffer = new byte[(int) ze.getSize()];
			while ( zis.read(buffer) != -1 ) {}
		}

		zis.close();
		zdis.close();
		fis.close();

		return buffer;
	}
}

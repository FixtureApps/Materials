package net.libertytax.b2b.base;

import java.util.HashMap;
import java.util.Map;

public class Content {
	
	private Content() { }

	private Map<String, Object> ContentMap;
	private static Content instance;

	public static Content getInstance() {

		if (instance == null) {
			instance = new Content();
		}

		return instance;
	}

	public static Object resolve(String id) {

		Content cnt = getInstance();

		Object content = cnt.getContentMap().containsKey(id) ? cnt.getContentMap().get(id) : null;

		return content;
	}

	public static void remove(String key) {

		Content cnt = getInstance();

		if (!cnt.getContentMap().containsKey(key)) return;

		cnt.getContentMap().remove(key);
	}

	public static void removeAll() {

		Content cnt = getInstance();

		cnt.ContentMap = null;
//		((HashMap<String, Object>) cnt.getContentMap()).clear();
	}

	public void addContent(String key, Object obj) {
		getContentMap().put(key, obj);
	}

	public static boolean containsKey(String key) {

		Content cnt = getInstance();

		return cnt.getContentMap().containsKey(key);
	}

	private Map<String, Object> getContentMap() {

		if (ContentMap == null) {
			ContentMap = new HashMap<String, Object>();
		}

		return ContentMap;
	}
}

/*
* @(#)AppException.java
*
* Copyright (c) 2013, Liberty Tax Service.
* All rights reserved.
*
* Use is subject to license terms. This software is protected by
* copyright law and international treaties. Unauthorized reproduction or
* distribution of this program, or any portion of it, may result in severe
* civil and criminal penalties, and will be prosecuted to the maximum extent.
*/
package net.libertytax.b2b.base;

import java.util.ArrayList;
import java.util.List;

import net.libertytax.b2b.util.MessageUtil;

public class AppException extends RuntimeException {

	private static final long serialVersionUID = -8281380243317748227L;
	private List<Error> errors;

	public AppException() { this.errors = new ArrayList<Error>(); }
	public AppException(List<Error> errors) { this.errors = errors; }

	public AppException(Error error) {

		super(error.toString());
		errors = new ArrayList<Error>(1);
		errors.add(error);
	}

	public AppException(Error error, Throwable cause) {

		super(error.toString(), cause);
		errors = new ArrayList<Error>(1);
		errors.add(error);
	}

	public AppException(String  code) { this(new Error(code)); }

	public AppException(String code, String data) { this(new Error(code, data)); }

	public AppException(String code, Throwable cause) {

		super(code.toString(), cause);
		errors = new ArrayList<Error>(1);
		errors.add(new Error(code, cause.getMessage()));
	}

	public AppException(Throwable cause) { this(Error.Unknown, cause); }

	public AppException(String data, Exception e) {

		super(data, e);
		errors = new ArrayList<Error>(1);
		errors.add(new Error(Error.Unknown, data));
	}

	public List<Error> getErrors() { return errors; }

	public List<String> getErrCodes() {

		ArrayList<String> codes = new ArrayList<String>(errors.size());
		for (Error err : errors) {
			codes.add(err.getCode());
		}
		return codes;
	}

	public boolean hasError(String code) { return getErrCodes().contains(code); }

	@Override
	public String getMessage() {

		int count = 0;
		String message = "";
		for (Error err : errors) {

			if (err.getCode() == Error.Unknown) return err.getData().get(0);

			if(count != 0) { message += "\n"; }
			count++;
			message += getMessage(err.getCode());
			if(err.getData()!= null) {
				for(String data : err.getData()){
					message = data == null ? message.replaceFirst("%", "") : message.replaceFirst("%", data);
				}
			}
		}
		return message;
	}

	public String getMessage(List<Error> errors) {

		this.errors = errors;
		return getMessage();
	}

	private String getMessage(String code) { return MessageUtil.getMessage(code); }

	@Override
	public String toString() {

		StringBuilder sb = new StringBuilder(AppException.class.getName());
		for (Error err : errors) {
			sb.append("\n").append(err.toString());
		}
		return sb.toString();
	}
}

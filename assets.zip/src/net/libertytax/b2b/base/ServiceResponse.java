/*
* @(#)ServiceResponse.java
*
* Copyright (c) 2013, Liberty Tax Service.
* All rights reserved.
*
* Use is subject to license terms. This software is protected by
* copyright law and international treaties. Unauthorized reproduction or
* distribution of this program, or any portion of it, may result in severe
* civil and criminal penalties, and will be prosecuted to the maximum extent.
*/
package net.libertytax.b2b.base;

import java.util.ArrayList;
import java.util.List;

public class ServiceResponse {

	private boolean Status;
	private String Output;
	private List<Error> Errors = new ArrayList<Error>();

 	public boolean isStatus() { return Status; }
 	public String getOutput() { return Output; }
 	public List<Error> getErrors() { return Errors; }

 	public void setStatus(boolean status) { Status = status; }
	public void setOutput(String output) { Output = output; }
	public void setErrors(List<Error> errors) { Errors = errors; }
}
package net.libertytax.b2b.base;

public class ErrorCode {

	public final static String UNHANDLED_ERROR = "UNHANDLED_ERROR"; 
	public final static String UNKNOWN = "B2B.0.0.1.1"; 

	public final static String SESSION_EXPIRED = "B2B.0.0.2.1";
	public final static String USERNAME_PASS_EMPTY = "B2B.0.0.2.2";
	public final static String USERNAME_PASS_INVALID = "B2B.0.0.2.3";
	public final static String ACCOUNT_INACTIVE = "B2B.0.0.2.4";

	//Business
	public final static String DATE_INVALID = "B2B.0.0.3.1";
	public final static String SEQUENCE_EMPTY = "B2B.0.0.3.2";
	public final static String FETCH_ROUTE_FAILED = "B2B.0.0.3.3";

	//Marketer
	public final static String USERNAME_ALREADY_EXISTS = "B2B.0.0.4.1";
	public final static String CREATE_MARKETER_FAILED = "B2B.0.0.4.2";
	public final static String UPDATE_MARKETER_FAILED = "B2B.0.0.4.3";
	public final static String EMAIL_INVALID = "B2B.0.0.4.4";
	public final static String MOBILE_NUMBER_EMPTY = "B2B.0.0.4.5";
	public final static String ADDRESS_EMPTY = "B2B.0.0.4.6";
	public final static String USERID_EMPTY = "B2B.0.0.4.7";
	public final static String PASS_EMPTY = "B2B.0.0.4.8";
	public final static String WAGE_EMPTY = "B2B.0.0.4.9";
	public final static String FRANCHISE_EMPTY = "B2B.0.0.4.10";
	public final static String OFFICES_EMPTY = "B2B.0.0.4.11";
	public final static String OFFICE_EMPTY = "B2B.0.0.4.12";
	public final static String OFFICE_NAME_EMPTY = "B2B.0.0.4.13";
	public final static String MARKETER_EMPTY = "B2B.0.0.4.14";
	public final static String MARKETER_WITH_ASSIGNMENTS = "B2B.0.0.4.15";

	public final static String EMAIL_FAILED = "B2B.0.0.5.1";

	//Common
	public final static String NETWORK_NOT_CONNECTED = "BBC.0.0.0.1";
	public final static String INVALID_REQUEST = "BBC.0.0.0.2";
	public final static String RESOURCE_NOT_FOUND = "BBC.0.0.0.3";
	public final static String SERVER_NOT_FOUND = "BBC.0.0.0.4";

	//Client
	public static final String USERNAME_EMPTY = "BBC.0.0.1.1";
	public static final String USERNAME_HAS_SPACE = "BBC.0.0.1.2";
	public static final String PASSWORD_EMPTY = "BBC.0.0.1.3";
	public static final String PASSWORD_HAS_SPACE = "BBC.0.0.1.4";
	public static final String INVALID_DATE = "BBC.0.0.1.5";
	public static final String UNABLE_TO_CONNECT_MAP = "BBC.0.0.1.6";
	public static final String REARRANGE_FAILED = "BBC.0.0.1.7";
	public static final String MAP_ROAD_FETCH_FAILED = "BBC.0.0.1.8";
	public static final String MAP_LISTENER_NOT_ATTACHED = "BBC.0.0.1.9";
	public static final String USERNAME_PASS_HAS_SPACE = "BBC.0.0.1.10";
	public static final String CONTACT_DETAIL_ADDRESS_EMPTY = "BBC.0.0.1.11";
	public static final String CONTACT_DETAIL_EMAIL_EMPTY = "BBC.0.0.1.12";
	public static final String CONTACT_DETAIL_PHONE_EMPTY = "BBC.0.0.1.13";
	public static final String CONTACT_DETAIL_PERSON_EMPTY = "BBC.0.0.1.14";
	public static final String NO_FEEDBACK_SELECTED = "BBC.0.0.1.15";
	public static final String SELECT_FEEDBACK = "BBC.0.0.1.16";
	public static final String GIVE_RATING = "BBC.0.0.1.17";
	public static final String NO_ALT_ROUTE = "BBC.0.0.1.18";
	public static final String UNKNOWN_GMAP = "BBC.0.0.1.19";
	public static final String NOT_HAS_ONE_OFFICE = "BBC.0.0.1.20";
	public static final String FETCH_ADDRESS_FAILED = "BBC.0.0.1.21";
	public static final String UNABLE_TO_LOCATE_MARKETER = "BBC.0.0.1.22";
	public static final String CONTACT_DETAIL_INVALID_EMAIL = "BBC.0.0.1.23";
	public static final String CONTACT_DETAIL_INVALID_PHONE = "BBC.0.0.1.24";
	public static final String CONTACT_DETAIL_INVALID_MOBILE = "BBC.0.0.1.25";
	public static final String CONTACT_DETAIL_INVALID_FAX = "BBC.0.0.1.26";
}

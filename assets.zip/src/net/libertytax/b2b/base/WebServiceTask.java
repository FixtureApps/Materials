/*
* @(#)WebServiceTask.java
*
* Copyright (c) 2013, Liberty Tax Service.
* All rights reserved.
*
* Use is subject to license terms. This software is protected by
* copyright law and international treaties. Unauthorized reproduction or
* distribution of this program, or any portion of it, may result in severe
* civil and criminal penalties, and will be prosecuted to the maximum extent.
*/
package net.libertytax.b2b.base;

import java.io.IOException;
import java.net.UnknownHostException;

import net.libertytax.b2b.activities.BaseActivity;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.Misc;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.util.B2BContext;
import android.os.AsyncTask;

import com.google.gson.JsonParseException;

public class WebServiceTask extends AsyncTask<ServiceInput, Boolean, ServiceResponse> {

	private BaseActivity context;
	private RequestCode requestCode;
	private boolean singleCall;
	private boolean canStartProgress;

	public WebServiceTask(BaseActivity context, RequestCode requestCode, Boolean singleCall) {
		this(context, requestCode, singleCall, true);
	}

	public WebServiceTask(BaseActivity context, RequestCode requestCode, Boolean singleCall, boolean canStartProgress) {
		this.context = context;
		this.requestCode = requestCode;
		this.singleCall = singleCall;
		this.canStartProgress = canStartProgress;
	}

	@Override
	protected void onPreExecute() {
		if (B2BContext.getInstance().getShowProgress() && canStartProgress) {
			context.showProgress(context, Labels.EMPTY, Misc.KEY_LOADING);
		}
	}

	@Override
	protected ServiceResponse doInBackground(ServiceInput... urls) {

		publishProgress(true);
		ServiceResponse response = new ServiceResponse();

		try {

			if (urls[0].getRequestType().equals(RequestType.GET)) {
				return ServiceInvoker.invokeGetService(urls[0].getUrl());
			} else if (urls[0].getRequestType().equals(RequestType.POST)) {
				return ServiceInvoker.invokePostService(urls[0].getUrl(), urls[0].getInput(), urls[0].isHeaderRequired());
			} else if (urls[0].getRequestType().equals(RequestType.DELETE)) {
				return ServiceInvoker.invokeDeleteService(urls[0].getUrl());
			} else if (urls[0].getRequestType().equals(RequestType.PUT)) {
				return ServiceInvoker.invokePutService(urls[0].getUrl());
			}
		} catch (JsonParseException e) {
			response.getErrors().add(new Error(ErrorCode.UNKNOWN));
		} catch (UnknownHostException e) {
			response.getErrors().add(new Error(ErrorCode.SERVER_NOT_FOUND));
		} catch (IOException e) {
			response.getErrors().add(new Error(ErrorCode.UNKNOWN));
		} catch (Exception e) {
			if (e instanceof AppException) {
				AppException ae = (AppException)e;
				response.setErrors(ae.getErrors());
			} else {
				response.getErrors().add(new Error(ErrorCode.UNKNOWN));
			}
		}

		return response;
	}

	@Override
	protected void onPostExecute(ServiceResponse result) {

		if (singleCall) {
			B2BContext.getInstance().setShowProgress(false);
			context.dismissProgress();
		}
		context.processOutput(result, requestCode);
	}
}

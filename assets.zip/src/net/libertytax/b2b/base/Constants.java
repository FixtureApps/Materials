package net.libertytax.b2b.base;

import net.libertytax.b2b.util.MessageUtil;

public class Constants {

	public static class Titles {
		public final static String GET_CONFIG = "Get Config";
		public final static String APPROVE_CLIENT = "Approve Client";
		public final static String LOGIN_TITLE = "Login";
		public final static String DASHBOARD_TITLE = "Dashboard Error";
		public final static String MY_ROUTE_TITLE = "My Routes";
		public final static String MY_MAP_TITLE = "My Routes Maps";
		public final static String REARRANGE_TITLE = "Rearrange Priority";
		public final static String LOGOUT_TITLE = "Logout Confirmation";
		public final static String BUSINESS_DETAILS_TITLE = "Business Details Error";
		public final static String SHOW_ROUTE_TITLE = "Show Business Route";
		public final static String CONTACT_DETAIL_TITLE = "Business Contact Details";
		public final static String ADD_NOTE_TITLE = "Add Notes";
		public final static String ALTERNATE_PATH_TITLE = "Alternate Path";
		public final static String SELECT_OFFICE_TITLE = "Select Office";
		public final static String OTHER_MARKETERS_TITLE = "Marketers";
	}

	public static class HeaderKey {
		public final static String CONTENT_TYPE = "Content-Type";
	}

	public static class HeaderValue {
		public final static String CONTENT_TYPE = "application/json";
		public final static String EMAIL_TYPE = "text/plain";
	}

	public static class Labels {
		public final static String EMPTY = "";
		public final static String ALERT_BUTTON_TEXT = "Ok";
		public final static String TAB_LIST = "tabList";
		public final static String TAB_MAP = "tabMap";
		public final static String TAB_SPLIT = "tabSplit";
		public final static String LIST_VIEW = "List View";
		public final static String MAP_VIEW = "Map View";
		public final static String SPLIT_VIEW = "Split View";
		public final static String FILTER = "Filter";
		public final static String ALL = "All";
		public final static String COMPLETED = "Completed";
		public final static String IN_PROGRESS = "In Progress";
		public final static String CLOSEST = "Closest";
		public final static String IN_COMPLETE = "Incompleted";
		public final static String MY_ROUTE = "My Route";
		public final static String GOOD = "Good";
		public final static String FAIR = "Fair";
		public final static String BAD = "Bad";
		public final static String FILTER_TOAST = "Filtered to %s";
		public final static String BUSINESS_DETAIL_ADD_CONTACT = "Add Contact";
		public final static String BUSINESS_DETAIL_ADD_NOTE = "Add Note";
		public final static String SELECT_FEEDBACK = "Select Feedback";
		public final static String NO_MARKETERS = "No Marketer(s) Found";
		public final static String CURRENT_LOCATION = "Current Location";
		public final static String ALL_OFFICE = "All office(s)";
		public final static String EDIT = "Edit";
	}

	public static class Keys {
		public final static String MESSAGE_KEY = "msg";
		public final static String BUNDLE_KEY = "info";
		public final static String BUNDLE_CONTENT_KEY = "bundle_content_key";
		public final static String LOGIN_CONTENT = "login_content";
		public final static String LOGOUT_CONTENT = "logout_content";
		public final static String MY_ROUTE_CONTENT = "my_route_content";
		public final static String SELECT_OFFICE_CONTENT = "select_office_content";
		public final static String OTHER_MARKETER_CONTENT = "other_marketer_content";
		public final static String FROM_REARRANGE = "from_rearrange";
		public final static String FROM_SHOW_ROUTE = "from_show_route";
		public final static String FROM_BUSINESS_DETAIL = "from_business_detail";
		public final static String BASE_URL = "BASEURL";
		public final static String HOST_ADDED_KEY = "host_added";
		public final static String MAP_VIEW_KEY = "map_view";
		public final static String MAP_SPLIT_VIEW_KEY = "map_view_split";
		public final static String SELECTED_MONTH_KEY = "selected_month_split";
		public final static String REARRANGE_CONTENT = "rearrange_content";
		public final static String SELECTED_FILTER_TODAY = "selected_filter_today";
		public final static String SELECTED_FILTER_WEEK = "selected_filter_week";
		public final static String SELECTED_FILTER_MONTH = "selected_filter_month";
		public final static String SELECTED_FILTER_TAX_SEASON = "selected_filter_tax_season";
		public final static String SELECTED_TAB_TODAY = "selected_tab_today";
		public final static String SELECTED_TAX_SEASON = "selected_tax_season";
		public final static String SELECTED_TIMELINE = "selected_timeline";
		public final static String SELECTED_WEEK_INDEX = "selected_week_index";
		public final static String GOOGLE_MAP_POLY_LINE_COUNTER = "google_map_poly_line_counter";
		public final static String GOOGLE_MAP_ADDRESS_COUNTER = "google_map_address_counter";
		public final static String GOOGLE_MAP_ADDRESS_TAG = "google_map_address_tag";
		public final static String GOOGLE_SPLIT_POLY_LINE_COUNTER = "google_split_poly_line_counter";
		public final static String SHOW_ROUTE_BUSINESS = "show_route_business";
		public final static String SHOW_ROUTE_BUSINESS_FROM_DETAILS = "show_route_business_from_details";
		public final static String SHOW_ROUTE_BUSINESS_DETAIL = "show_route_business_detail";
		public final static String RETRIEVE_BUSINESS_DETAILS_KEY = "retrieve_business_details_key";
		public final static String FROM_CONTACT_DETAILS_KEY = "from_contact_details_key";
		public final static String SHOW_BUSINESS_CONTACT_DETAIL_KEY = "show_contact_detail_key";
		public final static String CONTACT_BUSINESS_MODE = "contact_business_mode";
		public final static String CONTACT_BUSINESS_STATUS = "contact_business_status";
		public final static String CONTACT_DETAIL_KEY = "contact_detail_key";
		public final static String ADD_NOTE_KEY = "add_note_key";
		public final static String ADD_NOTE_ASSIGNMENT_KEY = "add_note_assignment_key";
		public final static String ADD_NOTE_BUSINESS_KEY = "add_note_business_key";
		public final static String SELECTED_FEEDBACK = "selected_feedback";
		public final static String TEMP_SELECTED_FEEDBACK = "temp_selected_feedback";
		public final static String ALT_BUSINESS_ROUTES = "alt_business_routes";
		public final static String ALTERNATE_ROUTE_BUSINESS = "alternate_route_business";
		public final static String ALTERNATE_ROUTE_CURR_LOC = "alternate_route_curr_loc";
		public final static String ALTERNATE_ROUTE_VM = "alternate_route_vm";
		public final static String SELECTED_OFFICES = "selected_offices";
		public final static String SELECTED_ALTERNATE_PATH_INDEX = "selected_alternate_path_index";
		public final static String ITEM_CACHE = "item_cache";
		public final static String COUPON_CACHE = "coupon_cache";
		public final static String FEEDBACK_CACHE = "feedback_cache";
		public final static String FROM_ADD_NOTE = "from_add_note";
	}

	public static class Misc {
		public final static String KEY_LOADING = "Loading...";
		public final static String POSITIVE_BUTTON = "Yes";
		public final static String NEGATIVE_BUTTON = "No";
		public final static String STATUS_COMPLETED = "Completed";
		public final static String STATUS_IN_PROGRESS = "In Progress";
		public final static String STATUS_CLOSEST = "Closest";
		public final static String STATUS_IN_COMPLETE = "Incompleted";
		public final static String CURRENT_LOCATION = "Current Location";
		public final static String ROUTE_PARAM_NAME = "routes";
		public final static String OVERVIEW_POLYLINE_PARAM_NAME = "overview_polyline";
		public final static String POINTS_PARAM_NAME = "points";
		public final static String LEGS_PARAM_NAME = "legs";
		public final static String DISTANCE_PARAM_NAME = "distance";
		public final static String DISTANCE_TEXT_PARAM_NAME = "text";
		public final static String DURATION_PARAM_NAME = "duration";
		public final static String DURATION_TEXT_PARAM_NAME = "text";
		public final static String STEPS_PARAM_NAME = "steps";
		public final static String STEPS_HTML_PARAM_NAME = "html_instructions";
		public final static String SUMMARY_PARAM_NAME = "summary";
		public final static String RESULTS_PARAM_NAME = "results";
		public final static String FORMATTED_ADDRESS_PARAM_NAME = "formatted_address";
		public final static String ADDRESS_VIEW_ID = "address_view_id";
		public final static String CONTACT_VIEW_ID = "contact_view_id";
	}

	public static class Services {
		public final static String GET_CONFIG = "GetConfig";
		public final static String APPROVE_CLIENT = "ApproveClient";
		public final static String LOGIN = "GetAuthenticated%s";
		public final static String BUSSINESS_DETAILS = "MyBusinessDetails";
		public final static String SELECT_OFFICE = "GetOfficesForMarketer";
		public final static String OTHER_MARKETERS = "GetOtherMarketerList";
		public final static String RETRIEVE_BUSSINESS_DETAIL = "RetrieveBusinessDetail";
		public final static String COMPLETE_MARKETER_ASSIGNMENT = "CompleteMarketerAssignments";
		public final static String ADD_BUSINESS_CONTACT = "AddBusinessContact";
		public final static String UPDATE_BUSINESS_CONTACT = "UpdateBusinessContact";
		public final static String REARRANGE_BUSINESS = "ReArrangeSequence";
		public final static String ADD_NOTE = "AddAssignmentNotes";
		public final static String UPDATE_MARKETER_DEFAULT_OFFICE = "UpdateMarketerDefaultOffice";
		public final static String LOG_OUT = "LogOff";
	}

	public static class Module {
		public final static String SECURITY = "B2BSecurity/";
		public final static String MARKETER_ASSIGNMENT = "B2BMarketerAssignments/";
		public final static String MARKETER = "B2BMarketer/";
		public final static String REPOSITORY = "B2BRepository/";
	}

	public static class URL {
		public final static String GET_CONFIG = MessageUtil.getMessage(Keys.BASE_URL) + Module.SECURITY + Services.GET_CONFIG;
		public final static String APPROVE_CLIENT = MessageUtil.getMessage(Keys.BASE_URL) + Module.SECURITY + Services.APPROVE_CLIENT;
		public final static String LOGIN = MessageUtil.getMessage(Keys.BASE_URL) + Module.SECURITY + Services.LOGIN;
		public final static String LOG_OUT = MessageUtil.getMessage(Keys.BASE_URL) + Module.SECURITY + Services.LOG_OUT;
		public final static String BUSINESS_DETAILS = MessageUtil.getMessage(Keys.BASE_URL) + Module.MARKETER_ASSIGNMENT + Services.BUSSINESS_DETAILS;
		public final static String SELECT_OFFICE = MessageUtil.getMessage(Keys.BASE_URL) + Module.MARKETER + Services.SELECT_OFFICE;
		public final static String OTHER_MARKETERS = MessageUtil.getMessage(Keys.BASE_URL) + Module.MARKETER + Services.OTHER_MARKETERS;
		public final static String RETRIEVE_BUSSINESS_DETAIL = MessageUtil.getMessage(Keys.BASE_URL) + Module.MARKETER_ASSIGNMENT + Services.RETRIEVE_BUSSINESS_DETAIL;
		public final static String COMPLETE_MARKETER_ASSIGNMENT = MessageUtil.getMessage(Keys.BASE_URL) + Module.MARKETER_ASSIGNMENT + Services.COMPLETE_MARKETER_ASSIGNMENT;
		public final static String ADD_BUSINESS_CONTACT = MessageUtil.getMessage(Keys.BASE_URL) + Module.MARKETER_ASSIGNMENT + Services.ADD_BUSINESS_CONTACT;
		public final static String UPDATE_BUSINESS_CONTACT = MessageUtil.getMessage(Keys.BASE_URL) + Module.MARKETER_ASSIGNMENT + Services.UPDATE_BUSINESS_CONTACT;
		public final static String ADD_NOTE = MessageUtil.getMessage(Keys.BASE_URL) + Module.MARKETER_ASSIGNMENT + Services.ADD_NOTE;
		public final static String REARRANGE_BUSINESS = MessageUtil.getMessage(Keys.BASE_URL) + Module.MARKETER_ASSIGNMENT + Services.REARRANGE_BUSINESS;
		public final static String UPDATE_MARKETER_DEFAULT_OFFICE = MessageUtil.getMessage(Keys.BASE_URL) + Module.MARKETER + Services.UPDATE_MARKETER_DEFAULT_OFFICE;
	}

	public static class Messages {
		public final static String LOGOUT_MSG = "Are you sure you want to logout from the application?";
	}

	public enum RequestType {
		GET,
		POST,
		PUT,
		DELETE,
		OPTIONS
	}

	public enum RequestCode {
		GET_CONFIG,
		APPROVE_CLIENT,
		LOGIN,
		BUSINESS_TODAY,
		BUSINESS_WEEK,
		BUSINESS_MONTH,
		BUSINESS_SEASON,
		BUSINESS_SEASON_FROM_TAX_SEASON,
		MY_REPORT,
		OTHER_MARKETERS,
		SELECT_OFFICE,
		REARRANGE_BUSINESS,
		GOOGLE_MAP_ROAD_SERVICES,
		GOOGLE_MAP_ROAD_SERVICES_LAST,
		GOOGLE_MAP_ADDRESS_SERVICES,
		GOOGLE_MAP_ADDRESS_SERVICES_LAST,
		GOOGLE_SPLIT_ROAD_SERVICES,
		GOOGLE_SPLIT_ROAD_SERVICES_LAST,
		GOOGLE_BUSINESS_ROUTE_SERVICE,
		RETRIEVE_BUSINESS_DETAILS,
		RETRIEVE_BUSINESS_DETAILS_FROM_MAP,
		ADD_BUSINESS_CONTACT,
		UPDATE_BUSINESS_CONTACT,
		COMPLETE_MARKETER_ASSIGNMENTS,
		ADD_NOTE,
		UPDATE_MARKETER_DEFAULT_OFFICE,
		LOG_OUT;
	}
}

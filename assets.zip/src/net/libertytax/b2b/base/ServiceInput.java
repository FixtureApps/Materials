/*
* @(#)ServiceInput.java
*
* Copyright (c) 2013, Liberty Tax Service.
* All rights reserved.
*
* Use is subject to license terms. This software is protected by
* copyright law and international treaties. Unauthorized reproduction or
* distribution of this program, or any portion of it, may result in severe
* civil and criminal penalties, and will be prosecuted to the maximum extent.
*/
package net.libertytax.b2b.base;

import net.libertytax.b2b.base.Constants.RequestType;

public class ServiceInput {

	private String url;
	private String input;
	private RequestType requestType;
	private boolean headerRequired;

	public void setUrl(String url) { this.url = url; }
	public void setInput(String input) { this.input = input; }
	public void setRequestType(RequestType requestType) { this.requestType = requestType; }
	public void setHeaderRequired(Boolean headerRequired) { this.headerRequired = headerRequired; }

	public String getUrl() { return url; }
	public String getInput() { return input; }
	public RequestType getRequestType() { return requestType; }
	public boolean isHeaderRequired() { return headerRequired; }
}

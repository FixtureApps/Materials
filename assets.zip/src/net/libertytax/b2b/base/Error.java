/*
* @(#)Error.java
*
* Copyright (c) 2013, Liberty Tax Service.
* All rights reserved.
*
* Use is subject to license terms. This software is protected by
* copyright law and international treaties. Unauthorized reproduction or
* distribution of this program, or any portion of it, may result in severe
* civil and criminal penalties, and will be prosecuted to the maximum extent.
*/
package net.libertytax.b2b.base;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Error  implements Serializable{

	private static final long serialVersionUID = 4969322383999215133L;

	public static String Unknown = "UNKNOWN";
	private String Code;
	private List<String> Data;

	public Error() { }
	public Error(String code, List<String> data) {

		this.Code = code;
		Data = data;
	}

	public Error(String code, String data) {

		this.Code = code;

		Data = new ArrayList<String>(1);
		Data.add(data);
	}

 	public Error(String code) { this.Code = code; }

	public Error(String code, String[] errData) { this(code, Arrays.asList(errData)); }

	public String getCode() { return Code; }
	public List<String> getData() { return Data; }

	public void setCode(String code) { this.Code = code; }
	public void setData(List<String> data) { Data = data; }

	@Override
	public String toString() {
		return Data == null ? String.valueOf(Code) : Code + ";" + Data;
	}
}

package net.libertytax.b2b.util;

import net.libertytax.b2b.R;
import net.libertytax.b2b.base.Constants.Labels;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

public class B2BTextWatcher implements TextWatcher {

	private EditText mEditText;

    public B2BTextWatcher(EditText e) { 
        mEditText = e;
    }

    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }

    public void afterTextChanged(Editable s) {

    	switch (mEditText.getId()) {
		case R.id.edTxtContactEmailName:
			break;
		case R.id.edTxtContactPhoneNumberName:
			validatePhoneNumber(s.toString());
			break;
		case R.id.edTxtContactFaxName:
			validateFaxNumber(s.toString());
			break;
		case R.id.edTxtContactMobileNumber:
			validateMobileNumber(s.toString());
			break;
		default:
			break;
		}
    }

    private void validatePhoneNumber(String str) {
    	validateAndPrintPhoneFormat(str);
    }

    private void validateFaxNumber(String str) {
    	validateAndPrintPhoneFormat(str);
    }

    private void validateMobileNumber(String str) {
    	validateAndPrintPhoneFormat(str);
    }

    private void validateAndPrintPhoneFormat(String phone) {

    	mEditText.removeTextChangedListener(this);
		String text = phone.toString();
		if (Labels.EMPTY.equals(text.trim())) {
			if (text.length() > 0) {
				text = Labels.EMPTY;
			}
		} else {
			char last = text.charAt(text.length() - 1);
			if (Character.isDigit(last)) {
				if (text.length() == 3 || text.length() == 7) {
					text = text + "-";
				} else if (text.length() > 12) {
					text = text.substring(0, text.length() - 1);
				}
			} else {
				text = text.substring(0, text.length() - 1);
			}
		}

		mEditText.setText(text);
		mEditText.setSelection(text.length());
		mEditText.addTextChangedListener(this);
    }
}

package net.libertytax.b2b.util;

import java.util.Comparator;

import net.libertytax.b2b.model.Business;

public class PriorityComparator implements Comparator<Business> {

	@Override
    public int compare(Business o1, Business o2) {
        return o1.getSeqNumber().compareTo(o2.getSeqNumber());
    }
}

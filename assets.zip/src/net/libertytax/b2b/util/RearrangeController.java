package net.libertytax.b2b.util;

import android.view.MotionEvent;
import android.view.View;
import net.libertytax.b2b.R;
import net.libertytax.b2b.adapters.RearrangeAdapter;
import net.libertytax.b2b.customviews.DragSortController;
import net.libertytax.b2b.customviews.DragSortListView;

public class RearrangeController extends DragSortController {

    private DragSortListView mDslv;
    private RearrangeAdapter mAdapter;

    public RearrangeController(DragSortListView dslv, RearrangeAdapter adapter) {
        super(dslv);
        setDragHandleId(R.id.imgRearrangeHolder);
        mDslv = dslv;
        mAdapter = adapter;
    }

    @Override
    public View onCreateFloatView(int position) {

    	View v = mAdapter.getView(position, null, mDslv);
        v.getBackground().setLevel(10000);
        return v;
    }

    @Override
    public void onDestroyFloatView(View floatView) {
        //do nothing; block super from crashing
    }

    @Override
    public int startDragPosition(MotionEvent ev) {
    	return super.dragHandleHitPosition(ev);
//    	int res = super.dragHandleHitPosition(ev);
//        int width = mDslv.getWidth();
//
//        if ((int) ev.getX() < width / 3) {
//        	return DragSortController.MISS;
//        } else {
//        	return res;
//        }
    }
}

/*
* @(#)MessageUtil.java
*
* Copyright (c) 2013, Liberty Tax Service.
* All rights reserved.
*
* Use is subject to license terms. This software is protected by
* copyright law and international treaties. Unauthorized reproduction or
* distribution of this program, or any portion of it, may result in severe
* civil and criminal penalties, and will be prosecuted to the maximum extent.
*/
package net.libertytax.b2b.util;

import java.util.Properties;

public class MessageUtil {

	public static Properties messageProperties;

	public static String getMessage(String key){

		Object obj = messageProperties.get(key);
		return obj != null ? obj.toString() : key;
	}
}
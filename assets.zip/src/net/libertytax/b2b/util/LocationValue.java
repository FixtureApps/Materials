package net.libertytax.b2b.util;

import android.location.Location;

public abstract class LocationValue {
    public abstract void getCurrentLocation(Location location);
}
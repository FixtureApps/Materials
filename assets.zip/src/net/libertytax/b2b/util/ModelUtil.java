/*
* @(#)ModelUtil.java
*
* Copyright (c) 2013, Liberty Tax Service.
* All rights reserved.
*
* Use is subject to license terms. This software is protected by
* copyright law and international treaties. Unauthorized reproduction or
* distribution of this program, or any portion of it, may result in severe
* civil and criminal penalties, and will be prosecuted to the maximum extent.
*/
package net.libertytax.b2b.util;

import java.lang.reflect.Type;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class ModelUtil {

	final public static String Content_Type = "application/json";

	public static Object deserialize(String json, Class<?> type) {
		GsonBuilder gsonBuilder = new GsonBuilder();
        return gsonBuilder.create().fromJson(json, type);
	}

	public static String serialize(Object obj) {
		GsonBuilder gsonBuilder = new GsonBuilder();
		return gsonBuilder.create().toJson(obj);
	}

	public static <T> T deserializeArray(String jsonArray, Type type) {

		Gson gson = new Gson();
		return gson.fromJson(jsonArray, type);
	}
}
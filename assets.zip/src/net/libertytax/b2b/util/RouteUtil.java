package net.libertytax.b2b.util;

import java.util.Calendar;
import java.util.Date;

import android.widget.Button;

import net.libertytax.b2b.R;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.base.Constants.URL;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.model.BusinessDetailsInput;
import net.libertytax.b2b.model.TimeLine;

public class RouteUtil {

	public static ServiceInput getRouteInput(TimeLine timeLine, int month) {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getInput(timeLine, month));
		input.setUrl(URL.BUSINESS_DETAILS);
		input.setRequestType(RequestType.POST);
		return input;
	}

	public static String getInput(TimeLine timeLine, int month) {

		BusinessDetailsInput bdInput = new BusinessDetailsInput();
		bdInput.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());

		switch (timeLine) {
		case TODAY:
			bdInput.setStartDate(new Date());
			bdInput.setEndDate(new Date());
			break;
		case WEEK:
			bdInput.setStartDate(DateUtil.getFirstDayOfWeek());
			bdInput.setEndDate(DateUtil.getLastDayOfWeek());
			break;
		case MONTH:
			bdInput.setStartDate(DateUtil.getFirstDayOfMonth(Calendar.getInstance().get(Calendar.MONTH)));
			bdInput.setEndDate(DateUtil.getLastDayOfMonth(Calendar.getInstance().get(Calendar.MONTH)));
			break;
		case TAX_SEASON:
			bdInput.setStartDate(DateUtil.getFirstDayOfMonth(month));
			bdInput.setEndDate(DateUtil.getLastDayOfMonth(month));
			break;
		default:
			break;
		}

		return ModelUtil.serialize(bdInput);
	}

	public static int getMonth(Button monthButton) {

		switch (monthButton.getId()) {
		case R.id.imgBtJan: return Calendar.JANUARY;
		case R.id.imgBtFeb: return Calendar.FEBRUARY;
		case R.id.imgBtMar: return Calendar.MARCH;
		case R.id.imgBtApr: return Calendar.APRIL;
		case R.id.imgBtMay: return Calendar.MAY;
		default: return Calendar.JANUARY;
		}
	}

}

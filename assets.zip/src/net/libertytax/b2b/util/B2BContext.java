package net.libertytax.b2b.util;

import net.libertytax.b2b.model.LoginResult;
import android.content.Context;

public class B2BContext {

	private static B2BContext instance;

	private Context activeContext;
	private boolean showProgress;
	private LoginResult loginResult;

	private B2BContext() { }

	public static B2BContext getInstance() {

		if (instance == null) {
			instance = new B2BContext();
		}
		return instance;
	}

	public void setActiveContext(Context activeContext) { this.activeContext = activeContext; }  
	public void setShowProgress(boolean showProgress) { this.showProgress = showProgress; }
	public void setLoginResult(LoginResult loginResult) { this.loginResult = loginResult; }

	public Context getActiveContext() { return activeContext; }  
	public boolean getShowProgress() { return showProgress; }
	public LoginResult getLoginResult() { return loginResult; }
}

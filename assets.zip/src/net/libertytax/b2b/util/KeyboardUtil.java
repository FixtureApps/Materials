package net.libertytax.b2b.util;

import android.content.Context;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

public class KeyboardUtil {

	public static EditText mEdTxt;
	public static void setImeVisibility(final boolean visible, EditText edTxt) {

		mEdTxt = edTxt;
		if (visible) {
			edTxt.post(mShowImeRunnable);
	    } else {
	    	edTxt.removeCallbacks(mShowImeRunnable);
	        InputMethodManager imm = (InputMethodManager) edTxt.getContext()
	                .getSystemService(Context.INPUT_METHOD_SERVICE);

	        if (imm != null) {
	            imm.hideSoftInputFromWindow(edTxt.getWindowToken(), 0);
	        }
	    }
	}

	private static Runnable mShowImeRunnable = new Runnable() {

		public void run() {
	        InputMethodManager imm = (InputMethodManager) mEdTxt.getContext()
	                .getSystemService(Context.INPUT_METHOD_SERVICE);

	        if (imm != null) {
	            imm.showSoftInput(mEdTxt,0);
	        }
	    }
	};
}

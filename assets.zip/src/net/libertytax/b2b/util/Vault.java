/*
* @(#)Vault.java
*
* Copyright (c) 2013, Liberty Tax Service.
* All rights reserved.
*
* Use is subject to license terms. This software is protected by
* copyright law and international treaties. Unauthorized reproduction or
* distribution of this program, or any portion of it, may result in severe
* civil and criminal penalties, and will be prosecuted to the maximum extent.
*/
package net.libertytax.b2b.util;

import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Vault {

	public static byte[] STATIC_KEY = "A3$1E*8^%ER256%$#526SDES85)(_@DS".getBytes();
	public static byte[] DYNAMIC_KEY;

	public static byte[] encrypt(String encryptString, boolean isDefaultKey)
	throws Exception {

		if (!isDefaultKey && DYNAMIC_KEY == null) {

			byte[] buf = new byte[16];
			Random random = new Random();
			random.nextBytes(buf);
			DYNAMIC_KEY = buf;
		}

		byte[] key = isDefaultKey ? STATIC_KEY : DYNAMIC_KEY;
		byte[] ivBytes = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		SecretKeySpec skey = new SecretKeySpec(key, "AES");
		final IvParameterSpec iv = new IvParameterSpec(ivBytes);
		final Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.ENCRYPT_MODE, skey, iv);
		byte[] cipherbyte = cipher.doFinal(encryptString.getBytes());
		return cipherbyte;
	}

	public static byte[] decrypt(byte[] encryptedBytes, boolean isDefaultKey)
	throws Exception {

		byte[] key = isDefaultKey ? STATIC_KEY: DYNAMIC_KEY;
		byte[] ivBytes = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		SecretKeySpec skey = new SecretKeySpec(key, "AES");
		final IvParameterSpec iv = new IvParameterSpec(ivBytes);
		final Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.DECRYPT_MODE, skey, iv);
		byte[] cipherbyte = cipher.doFinal(encryptedBytes);
		return cipherbyte;
	}

	public static byte[] encryptPayload(String encryptString, byte[] key)
	throws Exception {

		byte[] ivBytes = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		SecretKeySpec skey = new SecretKeySpec(key, "AES");
		final IvParameterSpec iv = new IvParameterSpec(ivBytes);
		final Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.ENCRYPT_MODE, skey, iv);
		byte[] cipherbyte = cipher.doFinal(encryptString.getBytes());
		return cipherbyte;
	}
}
package net.libertytax.b2b.util;

import net.libertytax.b2b.activities.BaseActivity;
import android.location.Location;

public class MapUtil {

	private static BaseActivity activity;
    public static void getCurrentLocation(BaseActivity activity) {
    	MapUtil.activity = activity;
        B2BLocationManager.getB2BLocationManager().getCurrentLocation(activity, locationValue);
	}

    public static LocationValue locationValue = new LocationValue() {

    	@Override
        public void getCurrentLocation(Location location) {
            if(location != null) {
            	activity.currentLocationFromUtil(location);
            }
        }
    };
}

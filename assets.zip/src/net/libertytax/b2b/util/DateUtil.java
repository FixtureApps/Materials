package net.libertytax.b2b.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.Error;
import net.libertytax.b2b.base.ErrorCode;

public class DateUtil {

	public static final String HEADER_FORMAT = "MMM dd, yyyy";

	public static Date toDate(String dateStr) {
		try {
			return new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).parse(dateStr);
		} catch (ParseException e) {
			throw new AppException(new Error(ErrorCode.INVALID_DATE));
		}
	}

	public static String toString(Date date, String format) {
		return new SimpleDateFormat(format, Locale.ENGLISH).format(date);
	}

	public static Date getFirstDayOfWeek() {

		Calendar weekFirst = Calendar.getInstance();
	    weekFirst.add(Calendar.DAY_OF_WEEK, weekFirst.getFirstDayOfWeek() - weekFirst.get(Calendar.DAY_OF_WEEK));
		return weekFirst.getTime();
	}

	public static Date getLastDayOfWeek() {

		Calendar weekLast = Calendar.getInstance();
		weekLast.add(Calendar.DAY_OF_WEEK, weekLast.getFirstDayOfWeek() - weekLast.get(Calendar.DAY_OF_WEEK));
	    weekLast.add(Calendar.DAY_OF_YEAR, 6);
		return weekLast.getTime();
	}

	public static Date getFirstDayOfMonth(int field) {

		Calendar monthFirst = Calendar.getInstance();
		monthFirst.set(Calendar.MONTH, field);
		monthFirst.set(Calendar.DAY_OF_MONTH, monthFirst.getActualMinimum(Calendar.DAY_OF_MONTH));
		return monthFirst.getTime();
	}

	public static Date getLastDayOfMonth(int field) {

		Calendar monthLast = Calendar.getInstance();
		monthLast.set(Calendar.MONTH, field);
		monthLast.set(Calendar.DAY_OF_MONTH, monthLast.getActualMaximum(Calendar.DAY_OF_MONTH));
		return monthLast.getTime();
	}
}

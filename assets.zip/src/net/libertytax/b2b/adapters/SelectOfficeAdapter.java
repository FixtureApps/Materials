package net.libertytax.b2b.adapters;

import java.util.ArrayList;
import java.util.List;

import net.libertytax.b2b.model.Office;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;

public class SelectOfficeAdapter extends ArrayAdapter<Office> {

	private Context context;
	private List<Office> offices;
	private List<String> selectedOffices;

	public SelectOfficeAdapter(Context context, List<Office> offices) {
		super(context, android.R.layout.simple_list_item_multiple_choice, offices);
		this.context = context;
		this.offices = offices;
		this.selectedOffices = new ArrayList<String>();
	}

	public void addSelected(String officeId, boolean refresh) {

		selectedOffices.add(officeId);
		if (selectedOffices.size() == offices.size() - 1) {
			selectedOffices.add("0");
		}
		if (refresh) {
			notifyDataSetChanged();
		}
	}

	public void removeSelected(String officeId, boolean refresh) {

		selectedOffices.remove(officeId);
		if (selectedOffices.contains("0")) {
			selectedOffices.remove("0");
		}
		if (refresh) {
			notifyDataSetChanged();
		}
	}

	public void removeAll(boolean refresh) {

		selectedOffices.clear();
		if (refresh) {
			notifyDataSetChanged();
		}
	}

	public void addAll(boolean refresh) {

		selectedOffices.clear();

		for (Office office : offices) {
			selectedOffices.add(office.getOfficeId());
		}
		
		if (refresh) {
			notifyDataSetChanged();
		}
	}

	public List<Office> getSelectedOffices() {

		List<Office> selOffices = new ArrayList<Office>();

		for (Office office : offices) {

			if (selectedOffices.contains(office.getOfficeId())) {
				selOffices.add(office);
			}
		}

		return selOffices;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(android.R.layout.simple_list_item_multiple_choice, null);
		}

		Office office = offices.get(position);
		CheckedTextView txtView = (CheckedTextView) convertView.findViewById(android.R.id.text1);
		txtView.setText(office.getOfficeName());
		txtView.setTextSize(14);
		txtView.setChecked(selectedOffices.contains(office.getOfficeId()));
		txtView.setTag(office);

		return convertView;
	}
}

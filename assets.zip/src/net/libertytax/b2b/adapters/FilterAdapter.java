package net.libertytax.b2b.adapters;

import java.util.List;
import java.util.Locale;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;

public class FilterAdapter extends ArrayAdapter<String> {

	private Context context;
	private List<String> filters;
	private String selectedFilter;

	public FilterAdapter(Context context, List<String> filters) {

		super(context, android.R.layout.simple_list_item_single_choice, filters);
		this.context = context;
		this.filters = filters;
	}

	public void setSelected(String selectedFilter) {
		this.selectedFilter = selectedFilter;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(android.R.layout.simple_list_item_single_choice, null);
		}

		CheckedTextView txtView = (CheckedTextView) convertView.findViewById(android.R.id.text1);
		txtView.setText(filters.get(position));
		txtView.setChecked(filters.get(position).toLowerCase(Locale.getDefault()).equals(selectedFilter.toLowerCase(Locale.getDefault())));

		return convertView;
	}
}

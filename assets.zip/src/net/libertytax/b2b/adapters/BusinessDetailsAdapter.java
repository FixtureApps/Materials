package net.libertytax.b2b.adapters;

import java.util.ArrayList;
import java.util.List;

import net.libertytax.b2b.R;
import net.libertytax.b2b.activities.BusinessDetailActivity;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.model.ContactDetail;
import net.libertytax.b2b.model.Coupon;
import net.libertytax.b2b.model.DetailDisplay;
import net.libertytax.b2b.model.DetailDisplay.DetailConst;
import net.libertytax.b2b.model.DetailDisplay.ViewType;
import net.libertytax.b2b.model.Item;
import net.libertytax.b2b.model.Note;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class BusinessDetailsAdapter extends BaseAdapter {

	private BusinessDetailActivity context;
	private List<DetailDisplay> displays;
//	private View ratingView;

	public BusinessDetailsAdapter(Context context, List<DetailDisplay> displays) {
		this.context = (BusinessDetailActivity) context;
		this.displays = displays;
	}

	@Override
	public int getCount() {
		return displays.size();
	}

	@Override
	public Object getItem(int position) {
		return displays.get(position);
	}

	@Override
	public long getItemId(int position) {
		return displays.get(position).getLayoutId();
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		DetailDisplay detailDisplay = displays.get(position);

		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		convertView = inflater.inflate(detailDisplay.getLayoutId(), null);
		convertView.setTag(detailDisplay);
		if (detailDisplay.getViewId() != null && !("".equals(detailDisplay.getViewId().trim()))) {
			convertView.setTag(R.string.business_detail_address_key, detailDisplay.getViewId());
		}

		setDatas(convertView, detailDisplay.getViewType());

		return convertView;
	}

	private void setDatas(View convertView, ViewType type) {

		switch (type) {
		case HEADER:
			setHeader(convertView);
			break;
		case BUSINESS_DETAIL:
			setBusinessDetails(convertView);
			break;
		case CONTACT_DETAIL:
			setContactDetails(convertView);
			break;
		case ITEM:
			setItems(convertView);
			break;
		case COUPON:
			setCoupons(convertView);
			break;
		case FEEDBACK:
			setFeedback(convertView);
			break;
		case NOTE:
			setNotes(convertView);
			break;
		case DELIVERED:
			setDelivered(convertView);
			break;
		case RATING:
//			setRating(convertView);
			break;
		case EMPTY:
			break;
		default:
			break;
		}
	}

	private DetailDisplay getDetailDisplay(View view) {
		return (DetailDisplay) view.getTag();
	}

	private void setHeader(View view) {

		DetailDisplay dd = getDetailDisplay(view);

		TextView txtHeader = (TextView) view.findViewById(R.id.txtSectionHeader);

		String headerKey = dd.getValuesMap().get(DetailConst.HEADER_KEY).toString();
		txtHeader.setText(headerKey);

		if (dd.getValuesMap().containsKey(DetailConst.HEADER_ADD_KEY)) {
			String key = dd.getValuesMap().get(DetailConst.HEADER_ADD_KEY).toString();
			TextView txtAdd = (TextView) view.findViewById(R.id.txtSectionAdd);
			txtAdd.setText(key);
			txtAdd.setTag(key);
			txtAdd.setOnClickListener(context);
		}

		if (DetailConst.EMPTY_HEADER_VALUE.equals(headerKey)) {
			View seperator = view.findViewById(R.id.detailsSectionHeaderSeperator);
			seperator.setVisibility(View.GONE);
			RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) txtHeader.getLayoutParams();
			params.setMargins(10, 0, 0, 0);
		}
	}

	private void setBusinessDetails(View view) {

		DetailDisplay dd = getDetailDisplay(view);

		TextView txtName = (TextView) view.findViewById(R.id.txtDetailSectionName);
		TextView txtValue = (TextView) view.findViewById(R.id.txtDetailSectionValue);
		ImageView addrPin = (ImageView) view.findViewById(R.id.imgBusinessAddress);
		View divider = (View) view.findViewById(R.id.businessDetailImageDivider);

		txtName.setText(dd.getValuesMap().get(DetailConst.BUSINESS_DETAIL_KEY).toString());
		txtValue.setText(dd.getValuesMap().get(DetailConst.BUSINESS_DETAIL_VALUE).toString());

		if (!dd.getValuesMap().containsKey(DetailConst.BUSINESS_DETAIL_ADDRESS)) {
			addrPin.setVisibility(View.GONE);
		}
		manageDivider(divider, dd);
	}

	private void setContactDetails(View view) {

		DetailDisplay dd = getDetailDisplay(view);

		TextView txtDesignation = (TextView) view.findViewById(R.id.txtContactSectionName);
		TextView txtName = (TextView) view.findViewById(R.id.txtContactSectionValue);
		ImageView imgPhone = (ImageView) view.findViewById(R.id.imgContactSectionPhone);
		View divider = (View) view.findViewById(R.id.contactDetailDivider);

		txtDesignation.setText(dd.getValuesMap().get(DetailConst.CONTACT_DETAIL_TEXT1).toString());
		txtName.setText(dd.getValuesMap().get(DetailConst.CONTACT_DETAIL_TEXT2).toString());

		ContactDetail cDetail = (ContactDetail) dd.getValuesMap().get(DetailConst.CONTACT_DETAIL_TAG);

		imgPhone.setTag(cDetail);

		imgPhone.setOnClickListener(context);
		manageDivider(divider, dd);
	}

	private void setItems(View view) {

		DetailDisplay dd = getDetailDisplay(view);

		TextView txtName = (TextView) view.findViewById(R.id.txtItemSectionName);
		TextView txtCount = (TextView) view.findViewById(R.id.txtItemSectionCount);
		ImageButton btIncrease = (ImageButton) view.findViewById(R.id.imgItemSectionPositive);
		ImageButton btDecrease = (ImageButton) view.findViewById(R.id.imgItemSectionNegative);
		View divider = (View) view.findViewById(R.id.itemDetailDivider);

		txtName.setText(dd.getValuesMap().get(DetailConst.ITEM_NAME).toString());
		txtCount.setText(dd.getValuesMap().get(DetailConst.ITEM_COUNT).toString());

		boolean completed = (Boolean) dd.getValuesMap().get(DetailConst.ITEM_STATUS);

		if (!completed) {
			btIncrease.setTag(dd.getValuesMap().get(DetailConst.ITEM_KEY));
			btDecrease.setTag(dd.getValuesMap().get(DetailConst.ITEM_KEY));
	
			btIncrease.setOnClickListener(context);
			btDecrease.setOnClickListener(context);

			btIncrease.setVisibility(View.VISIBLE);
			btDecrease.setVisibility(View.VISIBLE);
		} else {
			btIncrease.setVisibility(View.GONE);
			btDecrease.setVisibility(View.GONE);
		}

		manageDivider(divider, dd);
	}

	private void setCoupons(View view) {

		DetailDisplay dd = getDetailDisplay(view);

		TextView txtName = (TextView) view.findViewById(R.id.txtItemSectionName);
		TextView txtCount = (TextView) view.findViewById(R.id.txtItemSectionCount);
		ImageButton btIncrease = (ImageButton) view.findViewById(R.id.imgItemSectionPositive);
		ImageButton btDecrease = (ImageButton) view.findViewById(R.id.imgItemSectionNegative);
		View divider = (View) view.findViewById(R.id.itemDetailDivider);

		txtName.setText(dd.getValuesMap().get(DetailConst.COUPON_NAME).toString());
		txtCount.setText(dd.getValuesMap().get(DetailConst.COUPON_COUNT).toString());

		boolean completed = (Boolean) dd.getValuesMap().get(DetailConst.COUPON_STATUS);

		if (!completed) {
			btIncrease.setTag(dd.getValuesMap().get(DetailConst.COUPON_KEY));
			btDecrease.setTag(dd.getValuesMap().get(DetailConst.COUPON_KEY));
	
			btIncrease.setOnClickListener(context);
			btDecrease.setOnClickListener(context);

			btIncrease.setVisibility(View.VISIBLE);
			btDecrease.setVisibility(View.VISIBLE);
		} else {
			btIncrease.setVisibility(View.GONE);
			btDecrease.setVisibility(View.GONE);
		}

		manageDivider(divider, dd);
	}

	private void setFeedback(View view) {

		DetailDisplay dd = getDetailDisplay(view);

		boolean completed = (Boolean) dd.getValuesMap().get(DetailConst.FEEDBACK_STATUS);

		TextView txtFeedback = (TextView) view.findViewById(R.id.txtFeedbackSectionValue);
		View divider = (View) view.findViewById(R.id.feedbackDivider);

		txtFeedback.setText(dd.getValuesMap().get(DetailConst.FEEDBACK_VALUE).toString());

		if (!completed) {
			view.setOnClickListener(context);
		}

		manageDivider(divider, dd);
	}

	private void setNotes(View view) {

		DetailDisplay dd = getDetailDisplay(view);

		TextView txtNotes = (TextView) view.findViewById(R.id.txtNoteSectionDesc);
		View divider = (View) view.findViewById(R.id.notesDivider);

		Note note = (Note) dd.getValuesMap().get(DetailConst.NOTE_VALUE);

		txtNotes.setText(note.getDescription());

		manageDivider(divider, dd);
	}

	private void setDelivered(View view) {

		Button btDelivered = (Button) view.findViewById(R.id.btDelivered);
		btDelivered.setOnClickListener(context);
	}
//
//	private void setRating(View view) {
//
//		DetailDisplay dd = getDetailDisplay(view);
//
//		RatingBar rating = (RatingBar) view.findViewById(R.id.ratingBusiness);
//		TextView txtPending = (TextView) view.findViewById(R.id.txtViewPending);
//		RelativeLayout relStatus = (RelativeLayout) view.findViewById(R.id.relStatus);
//
//		String status = dd.getValuesMap().get(DetailConst.STATUS_VALUE).toString();
//		rating.setProgress((Integer) dd.getValuesMap().get(DetailConst.RATING_VALUE));
//		txtPending.setText(status);
//		if (Labels.COMPLETED.equals(status)) {
//			relStatus.setBackgroundColor(context.getResources().getColor(R.color.details_completed_BG));
//		} else {
//			relStatus.setBackgroundColor(context.getResources().getColor(R.color.details_pending_BG));
//		}
//
//		ratingView = view;
//	}

	private void manageDivider(View view, DetailDisplay dd) {

		if (dd.getValuesMap().containsKey(DetailConst.SHOW_DIVIDER)) {
			boolean show = (Boolean) dd.getValuesMap().get(DetailConst.SHOW_DIVIDER);
			if (!show) {
				view.setVisibility(View.GONE);
			}
		}
	}

	public void updateItem(Item updatedItem) {

		for (DetailDisplay dd : displays) {

			if (dd.getViewType() != ViewType.ITEM) continue;

			Item item = (Item) dd.getValuesMap().get(DetailConst.ITEM_KEY);

			if (item.getItemId() == updatedItem.getItemId()) {
				dd.getValuesMap().put(DetailConst.ITEM_KEY, updatedItem);
				dd.getValuesMap().put(DetailConst.ITEM_COUNT, updatedItem.getItemCount());
				break;
			}
		}
		this.notifyDataSetChanged();
	}

	public void updateCoupon(Coupon updatedCoupon) {

		for (DetailDisplay dd : displays) {

			if (dd.getViewType() != ViewType.COUPON) continue;

			Coupon coupon = (Coupon) dd.getValuesMap().get(DetailConst.COUPON_KEY);

			if (coupon.getCouponId() == updatedCoupon.getCouponId()) {
				dd.getValuesMap().put(DetailConst.COUPON_KEY, updatedCoupon);
				dd.getValuesMap().put(DetailConst.COUPON_COUNT, updatedCoupon.getCouponCount());
				break;
			}
		}
		this.notifyDataSetChanged();
	}

	public void updateFeedback(String newFeedback) {

		for (DetailDisplay dd : displays) {

			if (dd.getViewType() != ViewType.FEEDBACK) continue;

			dd.getValuesMap().put(DetailConst.FEEDBACK_VALUE, newFeedback);
		}

		this.notifyDataSetChanged();
	}

	public String getFeedback() {

		String feedback = null;
		for (DetailDisplay dd : displays) {

			if (dd.getViewType() != ViewType.FEEDBACK) continue;

			feedback = (String) dd.getValuesMap().get(DetailConst.FEEDBACK_VALUE);

			break;
		}

		if (Labels.SELECT_FEEDBACK.equals(feedback)) return null;

		return feedback;
	}

	public List<Item> getItems() {

		List<Item> items = new ArrayList<Item>();
		for (DetailDisplay dd : displays) {

			if (dd.getViewType() != ViewType.ITEM) continue;

			Item item = (Item) dd.getValuesMap().get(DetailConst.ITEM_KEY);
			items.add(item);
		}

		return items;
	}

	public List<Coupon> getCoupons() {

		List<Coupon> coupons = new ArrayList<Coupon>();
		for (DetailDisplay dd : displays) {

			if (dd.getViewType() != ViewType.COUPON) continue;

			Coupon coupon = (Coupon) dd.getValuesMap().get(DetailConst.COUPON_KEY);
			coupons.add(coupon);
		}

		return coupons;
	}
}

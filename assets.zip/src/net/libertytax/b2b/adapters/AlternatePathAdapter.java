package net.libertytax.b2b.adapters;

import java.util.List;

import net.libertytax.b2b.R;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.model.AlternateRoute;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class AlternatePathAdapter extends ArrayAdapter<AlternateRoute>{

	private List<AlternateRoute> alternateRoutes;

	public AlternatePathAdapter(Context context, List<AlternateRoute> alternateRoutes) {
		super(context, R.layout.alternate_path_cell, alternateRoutes);
		this.alternateRoutes = alternateRoutes;
	}

	@SuppressLint("SetJavaScriptEnabled")
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		if (convertView == null) {
			LayoutInflater vi = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = vi.inflate(R.layout.alternate_path_cell, null);
		}

		AlternateRoute alternateRoute = alternateRoutes.get(position);

		TextView txtRoute = (TextView) convertView.findViewById(R.id.webAlternatePath);
		TextView txtDistance = (TextView) convertView.findViewById(R.id.txtAlternateDistance);
		TextView txtTime = (TextView) convertView.findViewById(R.id.txtAlternateTime);

		txtRoute.setText(alternateRoute.getSummary());
		txtDistance.setText(alternateRoute.getDistance());
		txtTime.setText(alternateRoute.getTime());

		String key = Keys.SELECTED_ALTERNATE_PATH_INDEX;
		if (Content.containsKey(key)) {
			int index = (Integer) Content.resolve(key);
			if (position == index) {
				convertView.setBackgroundColor(Color.BLUE);
			} else {
				convertView.setBackgroundColor(Color.WHITE);
			}
		} else {
			convertView.setBackgroundColor(Color.WHITE);
		}
		return convertView;
	}

}

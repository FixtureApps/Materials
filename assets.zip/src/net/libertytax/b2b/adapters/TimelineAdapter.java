package net.libertytax.b2b.adapters;

import java.text.NumberFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import net.libertytax.b2b.R;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.Misc;
import net.libertytax.b2b.model.Business;
import net.libertytax.b2b.model.TimeLine;
import net.libertytax.b2b.util.DateUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;

public class TimelineAdapter extends BaseExpandableListAdapter {

	private LayoutInflater minflater;
	private Map<Date, List<Business>> timeLineBusinesses;
	private TimeLine timeLine;

	public TimelineAdapter(Map<Date, List<Business>> timeLineBusinesses, TimeLine timeLine) {
	  	this.timeLineBusinesses = timeLineBusinesses;
	  	this.timeLine = timeLine;
	}

	public void setInflater(LayoutInflater mInflater) {
		this.minflater = mInflater;
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		Date date = (Date)timeLineBusinesses.keySet().toArray()[groupPosition];
		return timeLineBusinesses.get(date).get(childPosition);
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return (groupPosition * 100) + childPosition;
	}

	@Override
	public View getChildView(int groupPosition, final int childPosition,
	    boolean isLastChild, View convertView, ViewGroup parent) {

		if (convertView == null) {
			convertView = minflater.inflate(R.layout.business_list_cell, null);
		}

		Date date = (Date)timeLineBusinesses.keySet().toArray()[groupPosition];
		Business business = timeLineBusinesses.get(date).get(childPosition);

		TextView txtPriority = (TextView) convertView.findViewById(R.id.txtPriority);
		TextView txtBusinessName = (TextView) convertView.findViewById(R.id.txtBusinessName);
		TextView txtDate = (TextView) convertView.findViewById(R.id.txtDate);
		TextView txtAddress = (TextView) convertView.findViewById(R.id.txtAddress);
		TextView txtTime = (TextView) convertView.findViewById(R.id.txtTime);
		TextView txtOffice = (TextView) convertView.findViewById(R.id.txtOffice);
		TextView txtItems = (TextView) convertView.findViewById(R.id.txtItems);

		txtPriority.setText(String.valueOf(business.getSeqNumber()));
		txtBusinessName.setText(business.getBusinessName());
		txtAddress.setText(business.getAddress());
		txtOffice.setText("# "+ business.getOffice());
		txtItems.setText("Item (" + business.getItemCount() + "), Coupons (" + business.getCouponCount() + ")" );

		if (Misc.STATUS_COMPLETED.toLowerCase(Locale.getDefault()).equals(business.getStatus().toLowerCase(Locale.getDefault()))) {
			txtPriority.setBackgroundResource(R.drawable.priority_count_green);
			txtDate.setText(business.getCompletedDate());
			txtDate.setTextColor(convertView.getContext().getResources().getColor(R.color.business_date_text));
			txtTime.setText(business.getCompletedTime());
			txtItems.setTextColor(convertView.getContext().getResources().getColor(R.color.business_coupon_text));
		} else {
			txtPriority.setBackgroundResource(R.drawable.priority_count_red);
			txtDate.setText(Misc.STATUS_IN_PROGRESS);
			txtDate.setTextColor(convertView.getContext().getResources().getColor(R.color.business_date_pending_text));
			txtTime.setText(Labels.EMPTY);
			txtItems.setTextColor(convertView.getContext().getResources().getColor(R.color.business_date_pending_text));
		}

		return convertView;
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		Date date = (Date)timeLineBusinesses.keySet().toArray()[groupPosition];
		return ((List<Business>)timeLineBusinesses.get(date)).size();
	}

	@Override
	public Object getGroup(int groupPosition) {
		Date date = (Date)timeLineBusinesses.keySet().toArray()[groupPosition];
		return timeLineBusinesses.get(date);
	}

	@Override
	public int getGroupCount() {
		return timeLineBusinesses.keySet().size();
	}

	@Override
	public void onGroupCollapsed(int groupPosition) {
		super.onGroupCollapsed(groupPosition);
	}

	@Override
	public void onGroupExpanded(int groupPosition) {
		super.onGroupExpanded(groupPosition);
	}

    @Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

    @Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {

		if (convertView == null) {
			convertView = minflater.inflate(R.layout.timeline_header, null);
		}

		Date date = (Date)timeLineBusinesses.keySet().toArray()[groupPosition];
		int count = timeLineBusinesses.get(date).size();

		NumberFormat numFormat = NumberFormat.getInstance();
		numFormat.setMinimumIntegerDigits(2);

		((TextView)convertView.findViewById(R.id.txtDate)).setText(DateUtil.toString(date, DateUtil.HEADER_FORMAT));
		String text = "Assignment";
		if (count > 1) {
			text = "Assignments";
		}
		((TextView)convertView.findViewById(R.id.txtAssignmentCount)).setText(numFormat.format(count) + " " + text);
		if (TimeLine.WEEK == timeLine) {
			if (isExpanded) {
				((ImageView)convertView.findViewById(R.id.imgExpand)).setBackgroundResource(R.drawable.collapse);
				LayoutParams params = (LayoutParams) ((ImageView)convertView.findViewById(R.id.imgExpand)).getLayoutParams();
				params.setMargins(0, 0, 0, 0);
				convertView.setBackgroundColor(minflater.getContext().getResources().getColor(R.color.timeline_expand_header));
			} else {
				((ImageView)convertView.findViewById(R.id.imgExpand)).setBackgroundResource(R.drawable.expand);
				LayoutParams params = (LayoutParams) ((ImageView)convertView.findViewById(R.id.imgExpand)).getLayoutParams();
				params.setMargins(0, 0, 3, 0);
				convertView.setBackgroundColor(minflater.getContext().getResources().getColor(R.color.timeline_collapse_header));
			}
		} else {
			((ImageView)convertView.findViewById(R.id.imgExpand)).setVisibility(View.GONE);
			((ExpandableListView)parent).expandGroup(groupPosition);
		}

		return convertView;
	}

	@Override
	public boolean hasStableIds() {
		return true;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}
}

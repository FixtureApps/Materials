package net.libertytax.b2b.adapters;

import java.util.List;
import java.util.Locale;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;

public class FeedbackAdapter extends ArrayAdapter<String> {

	private Context context;
	private List<String> feedbacks;
	private String selectedFeedback;

	public FeedbackAdapter(Context context, List<String> feedbacks) {

		super(context, android.R.layout.simple_list_item_single_choice, feedbacks);
		this.context = context;
		this.feedbacks = feedbacks;
	}

	public void setSelected(String selectedFeedback) {
		this.selectedFeedback = selectedFeedback;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(android.R.layout.simple_list_item_single_choice, null);
		}

		CheckedTextView txtView = (CheckedTextView) convertView.findViewById(android.R.id.text1);
		txtView.setGravity(Gravity.FILL);
		txtView.setText(feedbacks.get(position));
		txtView.setChecked(feedbacks.get(position).toLowerCase(Locale.getDefault()).equals(selectedFeedback.toLowerCase(Locale.getDefault())));

		return convertView;
	}
}

package net.libertytax.b2b.adapters;

import net.libertytax.b2b.R;
import net.libertytax.b2b.activities.RouteActivity;
import net.libertytax.b2b.model.Business;
import net.libertytax.b2b.util.ModelUtil;
import android.app.AlertDialog;
import android.content.Context;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.model.Marker;

public class B2BInfoWindowAdapter implements InfoWindowAdapter {

	private Context context;

	public B2BInfoWindowAdapter(Context context) {
		this.context = context;
	}

	@Override
	public View getInfoContents(Marker marker) {
		return createView(marker);
	}

	@Override
	public View getInfoWindow(Marker marker) {
		return createView(marker);
    }

	private View createView(Marker marker) {

		Business business = (Business) ModelUtil.deserialize(marker.getSnippet(), Business.class);
		ContextThemeWrapper cw = new ContextThemeWrapper(context, R.style.Transparent);

		LayoutInflater inflater = (LayoutInflater) cw.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.info_window, null);

        TextView txtName = (TextView) layout.findViewById(R.id.txtMapBusinessName);
        TextView txtAddress = (TextView) layout.findViewById(R.id.txtMapBusinessAddress);
        RelativeLayout relMap = (RelativeLayout) layout.findViewById(R.id.relMapInfo);
        ImageView imgRoute = (ImageView) layout.findViewById(R.id.imgMapRoute);

        txtName.setText(business.getBusinessName());
        txtAddress.setText(business.getAddress());
        relMap.setTag(business);
        relMap.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				AlertDialog.Builder build = new AlertDialog.Builder(context);
				build.setMessage("inside");
				build.setTitle("title");
				build.show();
			}
		});
        imgRoute.setOnClickListener((RouteActivity) context);

        return layout;
	}
}

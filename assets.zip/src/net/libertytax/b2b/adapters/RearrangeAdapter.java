package net.libertytax.b2b.adapters;

import java.util.List;
import java.util.Locale;

import net.libertytax.b2b.R;
import net.libertytax.b2b.base.Constants.Misc;
import net.libertytax.b2b.model.Business;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class RearrangeAdapter extends ArrayAdapter<Business> {

	private Context context;

	public RearrangeAdapter(Context context, List<Business> businesses) {

		super(context, R.layout.rearrange_item, businesses);
		this.context = context;
	}

	public View getView(int position, View convertView, ViewGroup parent) {

		View row = convertView;

		if (row == null) {													

			LayoutInflater inflater = ((Activity) context).getLayoutInflater();

			row = inflater.inflate(R.layout.rearrange_item, parent, false);
		}

		Business business = getItem(position);

		TextView txtPriority = (TextView) row.findViewById(R.id.txtRearrangePriority);
		TextView txtBusinessName = (TextView) row.findViewById(R.id.txtRearrangeBusinessName);
		TextView txtAddress = (TextView) row.findViewById(R.id.txtRearrangeAddress);
		TextView txtOffice = (TextView) row.findViewById(R.id.txtRearrangeOffice);
		TextView txtItems = (TextView) row.findViewById(R.id.txtRearrangeItems);

		txtPriority.setText(String.valueOf(business.getSeqNumber()));
		txtBusinessName.setText(business.getBusinessName());
		txtAddress.setText(business.getAddress());
		txtOffice.setText(business.getOffice());
		txtItems.setText("Item (" + business.getItemCount() + "), Coupons (" + business.getCouponCount() + ")" );

		if (Misc.STATUS_COMPLETED.toLowerCase(Locale.getDefault()).equals(business.getStatus().toLowerCase(Locale.getDefault()))) {
			txtPriority.setBackgroundResource(R.drawable.priority_count_green);
			txtItems.setTextColor(row.getContext().getResources().getColor(R.color.business_coupon_text));
		} else {
			txtPriority.setBackgroundResource(R.drawable.priority_count_red);
			txtItems.setTextColor(row.getContext().getResources().getColor(R.color.business_date_pending_text));
		}

		row.setTag(business.getBusinessName());
		row.getBackground().setLevel(3000);

		return row;
	}
}
package net.libertytax.b2b.adapters;

import java.util.List;
import java.util.Locale;

import net.libertytax.b2b.R;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.Misc;
import net.libertytax.b2b.model.Business;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class BusinessListAdapter extends ArrayAdapter<Business> {

	private List<Business> businesses;

	public BusinessListAdapter(Context context, List<Business> businesses) {
		super(context, R.layout.business_list_cell, businesses);
		this.businesses = businesses;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		if (convertView == null) {
			LayoutInflater vi = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = vi.inflate(R.layout.business_list_cell, null);
//			convertView.setOnTouchListener(this);
		}

		convertView.setTag(R.string.selected_business_key, position);

		Business business = businesses.get(position);

		TextView txtPriority = (TextView) convertView.findViewById(R.id.txtPriority);
		TextView txtBusinessName = (TextView) convertView.findViewById(R.id.txtBusinessName);
		TextView txtDate = (TextView) convertView.findViewById(R.id.txtDate);
		TextView txtAddress = (TextView) convertView.findViewById(R.id.txtAddress);
		TextView txtTime = (TextView) convertView.findViewById(R.id.txtTime);
		TextView txtOffice = (TextView) convertView.findViewById(R.id.txtOffice);
		TextView txtItems = (TextView) convertView.findViewById(R.id.txtItems);

		txtPriority.setText(String.valueOf(business.getSeqNumber()));
		txtBusinessName.setText(business.getBusinessName());
		txtAddress.setText(business.getAddress());
		txtOffice.setText("# " + business.getOffice());
		txtItems.setText("Item (" + business.getItemCount() + "), Coupons (" + business.getCouponCount() + ")" );

		if (Misc.STATUS_COMPLETED.toLowerCase(Locale.getDefault()).equals(business.getStatus().toLowerCase(Locale.getDefault()))) {
			txtPriority.setBackgroundResource(R.drawable.priority_count_green);
			txtDate.setText(business.getCompletedDate());
			txtDate.setTextColor(convertView.getContext().getResources().getColor(R.color.business_date_text));
			txtTime.setText(business.getCompletedTime());
			txtItems.setTextColor(convertView.getContext().getResources().getColor(R.color.business_coupon_text));
		} else if (Misc.STATUS_IN_PROGRESS.toLowerCase(Locale.getDefault()).equals(business.getStatus().toLowerCase(Locale.getDefault()))) {
			txtPriority.setBackgroundResource(R.drawable.priority_count_orange);
			txtDate.setText(Misc.STATUS_IN_PROGRESS);
			txtDate.setTextColor(convertView.getContext().getResources().getColor(R.color.business_date_inprogress_text));
			txtTime.setText(Labels.EMPTY);
			txtItems.setTextColor(convertView.getContext().getResources().getColor(R.color.business_date_inprogress_text));
		} else {
			txtPriority.setBackgroundResource(R.drawable.priority_count_red);
			txtDate.setText(Misc.STATUS_IN_COMPLETE);
			txtDate.setTextColor(convertView.getContext().getResources().getColor(R.color.business_date_pending_text));
			txtTime.setText(Labels.EMPTY);
			txtItems.setTextColor(convertView.getContext().getResources().getColor(R.color.business_date_pending_text));
		}

		return convertView;
	}
}

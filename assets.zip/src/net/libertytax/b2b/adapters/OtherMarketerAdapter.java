package net.libertytax.b2b.adapters;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.model.Marketer;
import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;

public class OtherMarketerAdapter extends ArrayAdapter<String>
				implements Filterable {

	private List<Marketer> marketers;
	private List<String> suggestions;
	private Marketer noMarketer;
	private NameFilter nameFilter;

	public OtherMarketerAdapter(Context context, List<Marketer> marketers) {
		super(context, android.R.layout.simple_dropdown_item_1line);
		this.marketers = marketers;
		this.suggestions = new ArrayList<String>();
		nameFilter = new NameFilter();
		prepareNoMarketer();
	}

	private void prepareNoMarketer() {

		noMarketer = new Marketer();
		noMarketer.setMarketerName(Labels.NO_MARKETERS);
	}

	private Marketer getNoMarketer() {
		return noMarketer;
	}

	@Override
	public Filter getFilter() {
		return nameFilter;
	}

	private class NameFilter extends Filter {

		@Override
        protected FilterResults performFiltering(CharSequence constraint) {

			if(constraint != null) {

				suggestions.clear();
                for (Marketer marketer : marketers) {

                	if(marketer.getMarketerName().toLowerCase(Locale.getDefault()).startsWith(constraint.toString().toLowerCase(Locale.getDefault()))){
                        suggestions.add(marketer.getMarketerName());
                    }
                }

                if (suggestions.size() == 0) {
                	suggestions.add(getNoMarketer().getMarketerName());
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = suggestions;
                filterResults.count = suggestions.size();

                return filterResults;
            } else {
                return new FilterResults();
            }
        }

		@SuppressWarnings("unchecked")
		@Override
        protected void publishResults(CharSequence constraint, FilterResults results) {

			if (results != null && results.count > 0) {
				clear();
				addAll((ArrayList<String>) results.values);
                notifyDataSetChanged();
            } else {
                notifyDataSetInvalidated();
            }
        }
    };
}

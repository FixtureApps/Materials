package net.libertytax.b2b.maputils.projection;

/**
 * @deprecated since 0.2. Use {@link com.google.maps.android.geometry.Point} instead.
 */
@Deprecated
public class Point extends net.libertytax.b2b.maputils.geometry.Point {
    public Point(double x, double y) {
        super(x, y);
    }
}

package net.libertytax.b2b.maputils.ui;

/**
 * Use {@link TextIconGenerator} instead.
 */
@Deprecated
public class BubbleIconFactory {
}

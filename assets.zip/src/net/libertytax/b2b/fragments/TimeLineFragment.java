package net.libertytax.b2b.fragments;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import net.libertytax.b2b.R;
import net.libertytax.b2b.activities.BaseActivity;
import net.libertytax.b2b.activities.BusinessDetailActivity;
import net.libertytax.b2b.activities.RouteActivity;
import net.libertytax.b2b.activities.ShowBusinessRouteActivity;
import net.libertytax.b2b.adapters.TimelineAdapter;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.base.Constants.Titles;
import net.libertytax.b2b.base.Constants.URL;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.model.Business;
import net.libertytax.b2b.model.BusinessDetail;
import net.libertytax.b2b.model.BusinessDetailViewModel;
import net.libertytax.b2b.model.Filter;
import net.libertytax.b2b.model.RetrieveBusinessInput;
import net.libertytax.b2b.model.TimeLine;
import net.libertytax.b2b.util.B2BContext;
import net.libertytax.b2b.util.DateUtil;
import net.libertytax.b2b.util.ModelUtil;
import net.libertytax.b2b.util.PriorityComparator;
import net.libertytax.b2b.util.RouteUtil;
import net.libertytax.b2b.util.SwipeDetector;
import net.libertytax.b2b.util.SwipeDetector.GestureMotion;
import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class TimeLineFragment extends BaseFragment
 implements OnGroupClickListener,
 			OnClickListener,
 			OnChildClickListener {

	private TimeLine timeLine;

	private LinearLayout relTaxSeason;
	private RelativeLayout relWeek;
	private TextView txtWeekInterval;
	private Button imgBtJan;
	private Button imgBtFeb;
	private Button imgBtMar;
	private Button imgBtApr;
	private Button imgBtMay;
	private Button currentSelection;
	private ExpandableListView expLstBusiness;
	private TextView txtNoAssignments;

	private SwipeDetector listSwipeDetector;

	private Map<Date, List<Business>> weekBusinesses;
	private Map<Date, List<Business>> monthBusinesses;
	private Map<Date, List<Business>> taxSeasonBusinesses;

	private Location currentLocation;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		return inflater.inflate(R.layout.time_line, container, false);
	}

	@Override
	protected void prepareControls() {

		relTaxSeason = (LinearLayout) getView().findViewById(R.id.relTaxSeason);
		relWeek = (RelativeLayout) getView().findViewById(R.id.relWeek);
		imgBtJan = (Button) getView().findViewById(R.id.imgBtJan);
		imgBtFeb = (Button) getView().findViewById(R.id.imgBtFeb);
		imgBtMar = (Button) getView().findViewById(R.id.imgBtMar);
		imgBtApr = (Button) getView().findViewById(R.id.imgBtApr);
		imgBtMay = (Button) getView().findViewById(R.id.imgBtMay);
		txtWeekInterval = (TextView) getView().findViewById(R.id.txtWeekInterval);
		expLstBusiness = (ExpandableListView) getView().findViewById(R.id.expLstBusiness);
		txtNoAssignments = (TextView) getView().findViewById(R.id.txtNoAssignmentsTaxSeason);

		expLstBusiness.setGroupIndicator(null);
	}

	@Override
	protected void subscribeEvents() {

		expLstBusiness.setOnGroupClickListener(this);
		expLstBusiness.setOnChildClickListener(this);
		imgBtJan.setOnClickListener(this);
		imgBtFeb.setOnClickListener(this);
		imgBtMar.setOnClickListener(this);
		imgBtApr.setOnClickListener(this);
		imgBtMay.setOnClickListener(this);

		listSwipeDetector = new SwipeDetector();
		expLstBusiness.setOnTouchListener(listSwipeDetector);
	}

	@Override
	protected void applyDefaults() {

		manageLayout();
		checkAndPopulate();

		if (TimeLine.WEEK == timeLine) {
			txtWeekInterval.setText(getHeader(timeLine));
		} else if (TimeLine.MONTH == timeLine) {
			txtWeekInterval.setText(getHeader(timeLine));
		} else if (TimeLine.TAX_SEASON == timeLine) {

			if (Content.containsKey(Keys.SELECTED_TAX_SEASON)) {
				selectMonth(getSelectedButton(((Button) Content.resolve(Keys.SELECTED_TAX_SEASON)).getId()));
			} else {
				selectMonth(imgBtJan);
			}
		}
	}

	private Button getSelectedButton(int id) {

		switch (id) {
		case R.id.imgBtJan: return imgBtJan;
		case R.id.imgBtFeb: return imgBtFeb;
		case R.id.imgBtMar: return imgBtMar;
		case R.id.imgBtApr: return imgBtApr;
		case R.id.imgBtMay: return imgBtMay;
		default: return imgBtJan;
		}
	}

	private void manageLayout() {

		boolean taxSeason = (TimeLine.TAX_SEASON == timeLine);

		relTaxSeason.setVisibility(taxSeason ? View.VISIBLE : View.GONE);
		relWeek.setVisibility(!taxSeason ? View.VISIBLE : View.GONE);
	}

	private Map<Date, List<Business>> convertToBean() {

		switch(timeLine){
		case WEEK:
			prepareWeekBusinesses();
			return weekBusinesses;
		case MONTH:
			prepareMonthBusinesses();
			return monthBusinesses;
		case TAX_SEASON:
			prepareTaxSeasonBusinesses();
			return taxSeasonBusinesses;
		default:
			return null;
		}
	}

	private String getHeader(TimeLine timeLine) {

		if (TimeLine.WEEK == timeLine) {

			Date start = DateUtil.getFirstDayOfWeek();
			Date end = DateUtil.getLastDayOfWeek();

			return DateUtil.toString(start, DateUtil.HEADER_FORMAT)
					+ " to "
					+ DateUtil.toString(end, DateUtil.HEADER_FORMAT);

		} else if (TimeLine.MONTH == timeLine) {

			Calendar cal = Calendar.getInstance();
			String monthName = getMonthName(cal.get(Calendar.MONTH));
			int year = cal.get(Calendar.YEAR);

			return monthName + " " + year;
		}
		return null;
	}

	private String getMonthName(int month) {

		switch (month) {
		case Calendar.JANUARY: return "January";
		case Calendar.FEBRUARY: return "February";
		case Calendar.MARCH: return "March";
		case Calendar.APRIL: return "April";
		case Calendar.MAY: return "May";
		case Calendar.JUNE: return "June";
		case Calendar.JULY: return "July";
		case Calendar.AUGUST: return "August";
		case Calendar.SEPTEMBER: return "September";
		case Calendar.OCTOBER: return "October";
		case Calendar.NOVEMBER: return "November";
		case Calendar.DECEMBER: return "December";
		default: return null;
		}
	}

	private void prepareWeekBusinesses() {
		weekBusinesses = new HashMap<Date, List<Business>>();
		weekBusinesses = prepareAndSortMap(weekBusinesses);
	}

	private void prepareMonthBusinesses() {
		monthBusinesses = new HashMap<Date, List<Business>>();
		monthBusinesses = prepareAndSortMap(monthBusinesses);
	}

	private void prepareTaxSeasonBusinesses() {
		taxSeasonBusinesses = new HashMap<Date, List<Business>>();
		taxSeasonBusinesses = prepareAndSortMap(taxSeasonBusinesses);
	}

	private Map<Date, List<Business>> prepareAndSortMap(Map<Date, List<Business>> timeLineMap) {

		@SuppressWarnings("unchecked")
		List<Business> businesses = (List<Business>) data;
		Collections.sort(businesses, new PriorityComparator());

		List<Business> filtered = getFiltered(businesses);
		for (Business business : filtered) {

			if (timeLineMap.containsKey(business.getAssignedDateObj())) {
				List<Business> businexus = timeLineMap.get(business.getAssignedDateObj());
				businexus.add(business);
			} else {
				List<Business> businexus = new ArrayList<Business>();
				businexus.add(business);
				timeLineMap.put(business.getAssignedDateObj(), businexus);
			}
		}

		return new TreeMap<Date, List<Business>>(timeLineMap);
	}

	private List<Business> getFiltered(List<Business> businesses) {

		if (!Content.containsKey(getFilterKey())) {
			return businesses;
		}

		Filter filter = (Filter) Content.resolve(getFilterKey());

		if (Filter.ALL == filter) return businesses;

		List<Business> filtered = new ArrayList<Business>();
		for (Business business : businesses) {

			if (Filter.CLOSEST == filter) {
				if (isClosest(business)) {
					filtered.add(business);
				}
			} else if (filter == getFilter(business.getStatus())) {
				filtered.add(business);
			}
		}
		return filtered;
	}

	@SuppressWarnings("unused")
	private boolean isClosest(Business business) {

		if (Labels.COMPLETED.equals(business.getStatus())) return false;

		if (currentLocation != null) {
			float[] results = null;
			Location.distanceBetween(currentLocation.getLatitude(), currentLocation.getLongitude(),
					Double.parseDouble(business.getLattitude()),
					Double.parseDouble(business.getLongitude()),
					results);
			if (results != null && results[0] < 8046.72f) {
				return true;
			}
		}
		return false;
	}

	private Filter getFilter(String filter) {

		if (Labels.COMPLETED.equals(filter)) return Filter.COMPLETED;
		if (Labels.IN_PROGRESS.equals(filter)) return Filter.INPROGRESS;
		if (Labels.IN_COMPLETE.equals(filter)) return Filter.INCOMPLETE;
		if (Labels.CLOSEST.equals(filter)) return Filter.CLOSEST;
		return Filter.ALL;
	}

	private void populateList(Map<Date, List<Business>> timeLineBusinesses) {

		TimelineAdapter adapter = new TimelineAdapter(timeLineBusinesses, timeLine);
		adapter.setInflater((LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE));

		expLstBusiness.setAdapter(adapter);
	}

	@Override
	public boolean onGroupClick(ExpandableListView parent, View v,
			int groupPosition, long id) {

		if (TimeLine.WEEK != timeLine) {
			return false;
		} else {

			int count = parent.getChildCount();
			for (int i = 0; i < count; i++) {

				if (i == groupPosition) {
					parent.expandGroup(groupPosition);
				} else {
					parent.collapseGroup(i);
				}
			}
			return true;
		}
	}

	private void selectMonth(Button imgButton) {

		if (currentSelection != null) {
			currentSelection.setTextColor(getActivity().getResources().getColor(R.color.timeline_month_unselected));
		}
		imgButton.setTextColor(getActivity().getResources().getColor(R.color.timeline_month_selected));
		currentSelection = imgButton;
		Content.getInstance().addContent(Keys.SELECTED_TAX_SEASON, imgButton);
	}

	public void setTimeLine(TimeLine timeLine) { this.timeLine = timeLine; }

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.imgBtJan:
			Content.getInstance().addContent(Keys.SELECTED_MONTH_KEY, imgBtJan);
			invokeService(Calendar.JANUARY);
			break;
		case R.id.imgBtFeb:
			Content.getInstance().addContent(Keys.SELECTED_MONTH_KEY, imgBtFeb);
			invokeService(Calendar.FEBRUARY);
			break;
		case R.id.imgBtMar:
			Content.getInstance().addContent(Keys.SELECTED_MONTH_KEY, imgBtMar);
			invokeService(Calendar.MARCH);
			break;
		case R.id.imgBtApr:
			Content.getInstance().addContent(Keys.SELECTED_MONTH_KEY, imgBtApr);
			invokeService(Calendar.APRIL);
			break;
		case R.id.imgBtMay:
			Content.getInstance().addContent(Keys.SELECTED_MONTH_KEY, imgBtMay);
			invokeService(Calendar.MAY);
			break;
		default:
			break;
		} 
	}

	private void invokeService(int month) {
		B2BContext.getInstance().setShowProgress(true);
		((BaseActivity)getActivity()).executeService(RequestCode.BUSINESS_SEASON_FROM_TAX_SEASON, true, RouteUtil.getRouteInput(TimeLine.TAX_SEASON, month));
	}

	public void updateList(List<Business> business) {

		if (timeLine != TimeLine.TAX_SEASON) return;

		data = business;

		checkAndPopulate();

		Button button = (Button) Content.resolve(Keys.SELECTED_MONTH_KEY);
		selectMonth(button);
	}

	public void refreshTimeLines(Location currentLocation) {
		this.currentLocation = currentLocation;
		checkAndPopulate();
	}

	private void checkAndPopulate() {

		Map<Date, List<Business>> timeLineMap = convertToBean();

		if (timeLineMap.isEmpty()) {
			showList(false);
		} else {
			populateList(timeLineMap);
			showList(true);
		}

		if (TimeLine.WEEK == timeLine) {
			if (Content.containsKey(Keys.SELECTED_WEEK_INDEX)) {
				Integer groupPosition = (Integer) Content.resolve(Keys.SELECTED_WEEK_INDEX);
				expLstBusiness.expandGroup(groupPosition);
			}
		}
	}

	private void showList(boolean showList) {

		expLstBusiness.setVisibility(showList ? View.VISIBLE : View.GONE);
		txtNoAssignments.setVisibility(!showList ? View.VISIBLE : View.GONE);
		((RouteActivity) getActivity()).setTitle((Filter) Content.resolve(getFilterKey()));
	}

	private String getFilterKey() {

		if (timeLine == TimeLine.WEEK) return Keys.SELECTED_FILTER_WEEK;
		if (timeLine == TimeLine.MONTH) return Keys.SELECTED_FILTER_MONTH;
		if (timeLine == TimeLine.TAX_SEASON) return Keys.SELECTED_FILTER_TAX_SEASON;

		return null;
	}

	public void navigateToDetailActivity(ServiceResponse response) {

		BaseActivity activity = (BaseActivity) getActivity();
		try {

			BusinessDetailViewModel model = new BusinessDetailViewModel();

			BusinessDetail details = (BusinessDetail) ModelUtil.deserialize(response.getOutput(), BusinessDetail.class);

			model.setSelectedBusiness(details);
			model.setBusinessesMap(getBusinessMap());
			model.setTimeLine(timeLine);
			model.setSelectedIndex(findIndex(details.getAssignmentId()));

			Content.getInstance().addContent(Keys.RETRIEVE_BUSINESS_DETAILS_KEY, model);
			Content.getInstance().addContent(Keys.SELECTED_TIMELINE, timeLine);
			activity.openActivity(getActivity(), BusinessDetailActivity.class, activity.getBundle(Keys.RETRIEVE_BUSINESS_DETAILS_KEY));
		} catch (Exception e) {
			activity.convertAndThrow(e, Titles.MY_ROUTE_TITLE);
		}
	}

	private int findIndex(int assignmentId) {

		Map<Date, List<Business>> businessMap = getBusinessMap();
		int index = -1;
		for (Date date : businessMap.keySet()) {
			List<Business> businesses = businessMap.get(date);
			for (Business business : businesses) {
				index++;
				if (business.getAssignmentId() == assignmentId) {
					return index;
				}
			}
		}

		return -1;
	}

	private Map<Date, List<Business>> getBusinessMap() {

		switch (timeLine) {
		case WEEK:
			return weekBusinesses;
		case MONTH:
			return monthBusinesses;
		case TAX_SEASON:
			return taxSeasonBusinesses;
		default:
			return new HashMap<Date, List<Business>>();
		}
	}

	private ServiceInput getBusinessDetailsInput(Business business) {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getBusinessDetailsJSON(business));
		input.setUrl(URL.RETRIEVE_BUSSINESS_DETAIL);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getBusinessDetailsJSON(Business business) {

		RetrieveBusinessInput bdInput = new RetrieveBusinessInput();
		bdInput.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());
		bdInput.setAssignmentId(business.getAssignmentId());
		bdInput.setBusinessId(business.getBusinessId());
		return ModelUtil.serialize(bdInput);
	}

	@Override
	public boolean onChildClick(ExpandableListView parent, View v,
			int groupPosition, int childPosition, long id) {

		BaseActivity activity = (BaseActivity) getActivity();
		TimelineAdapter adapter = (TimelineAdapter) expLstBusiness.getExpandableListAdapter();
		Business business = (Business) adapter.getChild(groupPosition, childPosition);
		Content.getInstance().addContent(Keys.SELECTED_WEEK_INDEX, groupPosition);
		try {
			if (listSwipeDetector.swipeDetected()) {
	            if (listSwipeDetector.getAction() == SwipeDetector.GestureMotion.LR) {
	            	onSwipeRight(business);
	            }
	            if (listSwipeDetector.getAction() == SwipeDetector.GestureMotion.RL) {
	            	onSwipeLeft(business);
	            }
			} else {
				B2BContext.getInstance().setShowProgress(true);
				activity.executeService(RequestCode.RETRIEVE_BUSINESS_DETAILS, true, getBusinessDetailsInput(business));
			}
		} catch (Exception e) {
			activity.convertAndThrow(e, Titles.MY_ROUTE_TITLE);
		}
		return true;
	}

	public void onSwipeTop(Business business) {
		showRoute(GestureMotion.BT, business);
    }

	public void onSwipeRight(Business business) {
		showRoute(GestureMotion.LR, business);
    }

	public void onSwipeLeft(Business business) {
		showRoute(GestureMotion.RL, business);
    }

	public void onSwipeBottom(Business business) {
		showRoute(GestureMotion.TB, business);
    }

	public boolean showRoute(GestureMotion motion, Business business) {

		if (GestureMotion.BT == motion || GestureMotion.TB == motion) return false;

		Content.getInstance().addContent(Keys.SHOW_ROUTE_BUSINESS, business);
		Content.getInstance().addContent(Keys.SHOW_ROUTE_BUSINESS_FROM_DETAILS, false);
		Content.getInstance().addContent(Keys.SELECTED_TIMELINE, timeLine);
		BaseActivity activity = (BaseActivity) getActivity();
		Bundle  bundle = activity.getBundle(Keys.SHOW_ROUTE_BUSINESS);
		activity.openActivity(activity, ShowBusinessRouteActivity.class, bundle);

		return true;
	}
}
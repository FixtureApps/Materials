package net.libertytax.b2b.fragments;

import net.libertytax.b2b.R;
import net.libertytax.b2b.activities.RouteActivity;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.model.Business;
import net.libertytax.b2b.model.OnMapLoadedListener;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;

public class HostFragment extends BaseFragment
 implements OnTabChangeListener,
 			OnMapLoadedListener {

	private TabHost tabHost;
	private OnViewChangeListener listener;
	private BusinessListFragment bListFragment;
	private BusinessMapFragment bMapFragment;
	private BusinessSplitFragment bSplitFragment;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		return inflater.inflate(R.layout.host, container, false);
	}

	@Override
	protected void prepareControls() {

		tabHost = (TabHost) getView().findViewById(android.R.id.tabhost);
		tabHost.setup();

		tabHost.addTab(getTabSpec(Labels.TAB_LIST, R.id.tabList, Labels.LIST_VIEW));
		tabHost.addTab(getTabSpec(Labels.TAB_MAP, R.id.tabMap, Labels.MAP_VIEW));
		tabHost.addTab(getTabSpec(Labels.TAB_SPLIT, R.id.tabSplit, Labels.SPLIT_VIEW));
	}

	@Override
	protected void subscribeEvents() {
		tabHost.setOnTabChangedListener(this);
	}

	@Override
	protected void applyDefaults() {

		if (Content.containsKey(Keys.SELECTED_TAB_TODAY)) {

			int index = (int) getTabIndexFromId((String) Content.resolve(Keys.SELECTED_TAB_TODAY));
			if (index == 0) {
				addListFragment();
			} else {
				tabHost.setCurrentTab(index);
			}
		} else {
			addListFragment();
		}
	}

	private void addListFragment() {
		bListFragment = new BusinessListFragment();
		addFragment(R.id.tabList, bListFragment);
	}

	private int getTabIndexFromId (String tabId) {

		if (tabId.equals(Labels.TAB_LIST)) return 0;
		if (tabId.equals(Labels.TAB_MAP)) return 1;
		if (tabId.equals(Labels.TAB_SPLIT)) return 2;

		return 0;
	}

	private TabSpec getTabSpec(String tabName, int tabID, String tabIndicator) {

		TabSpec tabSpec = tabHost.newTabSpec(tabName);
		tabSpec.setContent(tabID);
		tabSpec.setIndicator(tabIndicator, null);
		return tabSpec;
	}

	public void setListener(OnViewChangeListener listener) { this.listener = listener; }

	@Override
	public void onTabChanged(String tabId) {

		int index = getTabIndexFromId(tabId);
		if (index != 0) {
			tabHost.getTabWidget().setEnabled(false);
		}

		if (listener != null) {
			if (index != 0) {
				listener.viewChanged(Labels.TAB_LIST.equals(tabId));
			}
		}

		removeFragments();
		if (Labels.TAB_LIST.equals(tabId)) {
			bListFragment = new BusinessListFragment();
			addFragment(R.id.tabList, bListFragment);
		} else if (Labels.TAB_MAP.equals(tabId)) {
			bMapFragment = new BusinessMapFragment();
			bMapFragment.setMapLoadedListener(this);
			addFragment(R.id.tabMap, bMapFragment);
		} else if (Labels.TAB_SPLIT.equals(tabId)) {
			bSplitFragment = new BusinessSplitFragment();
			bSplitFragment.setMapLoadedListener(this);
			addFragment(R.id.tabSplit, bSplitFragment);
		}

		Content.getInstance().addContent(Keys.SELECTED_TAB_TODAY, tabId);
	}

	private void removeFragments() {

		if (bListFragment != null) removeFragment(bListFragment);
		if (bMapFragment != null) removeFragment(bMapFragment);
		if (bSplitFragment != null) removeFragment(bSplitFragment);

		bListFragment = null;
		bMapFragment = null;
		bSplitFragment = null;
	}

	public void refreshHost(Location currLocation) {

		if (bListFragment != null) bListFragment.refreshList(currLocation);
		if (bMapFragment != null) bMapFragment.refreshMap(currLocation);
		if (bSplitFragment != null) bSplitFragment.refresh(currLocation);
	}

	public void navigateToDetailActivity(ServiceResponse response) {
		if (bListFragment != null) bListFragment.navigateToDetailActivity(response);
		if (bSplitFragment != null) bSplitFragment.navigateToDetailActivity(response);
	}

	public void navigateToDetailsFromMap(ServiceResponse response) {
		bMapFragment.navigateToDetailsFromMap(response);
	}

	public void navigateToDetailsFromSplit(ServiceResponse response) {
		bSplitFragment.navigateToDetailsFromSplit(response);
	}

	public void showRouteFromMap(Business business) {
		bMapFragment.showRouteFromMap(business);
	}

	public void showRouteFromSplit(Business business) {
		bSplitFragment.showRouteFromSplit(business);
	}

	public void onRouteFetching(ServiceResponse result) {
		bMapFragment.onRouteFetching(result);
	}

	public void onSplitRouteFetched(ServiceResponse result) {
		bSplitFragment.onRouteFetched(result);
	}

	public void onSplitRouteFetching(ServiceResponse result) {
		bSplitFragment.onRouteFetching(result);
	}

	public void onRouteFetched(ServiceResponse result) {
		bMapFragment.onRouteFetched(result);
	}

	@Override
	public void mapLoaded() {
		tabHost.getTabWidget().setEnabled(true);
		((RouteActivity) this.getActivity()).mapLoaded();
	}

	public interface OnViewChangeListener {
		void viewChanged(boolean tabId);
	}
}

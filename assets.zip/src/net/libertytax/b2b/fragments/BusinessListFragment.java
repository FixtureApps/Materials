package net.libertytax.b2b.fragments;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import net.libertytax.b2b.R;
import net.libertytax.b2b.activities.BaseActivity;
import net.libertytax.b2b.activities.BusinessDetailActivity;
import net.libertytax.b2b.activities.RouteActivity;
import net.libertytax.b2b.activities.ShowBusinessRouteActivity;
import net.libertytax.b2b.adapters.BusinessListAdapter;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.base.Constants.Titles;
import net.libertytax.b2b.base.Constants.URL;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.model.Business;
import net.libertytax.b2b.model.BusinessDetail;
import net.libertytax.b2b.model.BusinessDetailViewModel;
import net.libertytax.b2b.model.Filter;
import net.libertytax.b2b.model.RetrieveBusinessInput;
import net.libertytax.b2b.model.TimeLine;
import net.libertytax.b2b.util.B2BContext;
import net.libertytax.b2b.util.ModelUtil;
import net.libertytax.b2b.util.PriorityComparator;
import net.libertytax.b2b.util.SwipeDetector;
import net.libertytax.b2b.util.SwipeDetector.GestureMotion;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;

public class BusinessListFragment extends BaseFragment
 implements OnItemClickListener {

	private ListView lstBusiness;
	private TextView txtNoAssignments;
	private List<Business> businesses;
	private SwipeDetector listSwipeDetector;

	private Location currLocation;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		return inflater.inflate(R.layout.business_list, container, false);
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {

		super.onViewCreated(view, savedInstanceState);

		if (businesses == null || businesses.size() == 0) {
			showList(false);
		} else {
			showList(true);
			populateList();
		}
	}

	private void showList(boolean showList) {

		lstBusiness.setVisibility(showList ? View.VISIBLE : View.GONE);
		txtNoAssignments.setVisibility(!showList ? View.VISIBLE : View.GONE);
		((RouteActivity) getActivity()).setTitle((Filter) Content.resolve(Keys.SELECTED_FILTER_TODAY));
	}

	@Override
	protected void prepareControls() {
		lstBusiness = (ListView) getView().findViewById(R.id.lstBusiness);
		txtNoAssignments = (TextView) getView().findViewById(R.id.txtNoAssignments);
	}

	@Override
	protected void subscribeEvents() {

		lstBusiness.setOnItemClickListener(this);

		listSwipeDetector = new SwipeDetector();
		lstBusiness.setOnTouchListener(listSwipeDetector);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void applyDefaults() {
		businesses = (List<Business>)data;
		Collections.sort(businesses, new PriorityComparator());
	}

	private void populateList() {

		List<Business> filtered = getFiltered();
		BusinessListAdapter businessAdapter = new BusinessListAdapter(getActivity(), filtered);
		lstBusiness.setAdapter(businessAdapter);
//		businessAdapter.setRouteListener(this);
		showList(filtered.size() > 0);
	}

	private List<Business> getFiltered() {

		if (!Content.containsKey(Keys.SELECTED_FILTER_TODAY)) {
			return businesses;
		}

		Filter filter = (Filter) Content.resolve(Keys.SELECTED_FILTER_TODAY);

		if (Filter.ALL == filter) return businesses;

		List<Business> filtered = new ArrayList<Business>();
		for (Business business : businesses) {

			if (Filter.CLOSEST == filter) {
				if (isClosest(business)) {
					filtered.add(business);
				}
			} else if (filter == getFilter(business.getStatus())) {
				filtered.add(business);
			}
		}
		return filtered;
	}

	private boolean isClosest(Business business) {

		if (Labels.COMPLETED.equals(business.getStatus())) return false;

		if (currLocation != null) {
			float[] results = new float[5];
			Location.distanceBetween(currLocation.getLatitude(), currLocation.getLongitude(),
					Double.parseDouble(business.getLattitude()),
					Double.parseDouble(business.getLongitude()),
					results);
			if (results != null && results[0] < 1609.344) {// 8046.72f) {
				return true;
			}
		}
		return false;
	}

	private Filter getFilter(String filter) {

		if (Labels.COMPLETED.equals(filter)) return Filter.COMPLETED;
		if (Labels.IN_PROGRESS.equals(filter)) return Filter.INPROGRESS;
		if (Labels.IN_COMPLETE.equals(filter)) return Filter.INCOMPLETE;
		if (Labels.CLOSEST.equals(filter)) return Filter.CLOSEST;
		return Filter.ALL;
	}

	@Override
	public void onItemClick(AdapterView<?> adapterView, View view, int position, long arg3) {

		BaseActivity activity = (BaseActivity) getActivity();
		try {
			Business business = (Business) lstBusiness.getItemAtPosition(position);
			if (listSwipeDetector.swipeDetected()) {
	            if (listSwipeDetector.getAction() == SwipeDetector.GestureMotion.LR) {
	            	onSwipeRight(business);
	            }
	            if (listSwipeDetector.getAction() == SwipeDetector.GestureMotion.RL) {
	            	onSwipeLeft(business);
	            }
			} else {
				B2BContext.getInstance().setShowProgress(true);
				activity.executeService(RequestCode.RETRIEVE_BUSINESS_DETAILS, true, getBusinessDetailsInput(business));
			}
		} catch (Exception e) {
			activity.convertAndThrow(e, Titles.MY_ROUTE_TITLE);
		}
	}

	private ServiceInput getBusinessDetailsInput(Business business) {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getBusinessDetailsJSON(business));
		input.setUrl(URL.RETRIEVE_BUSSINESS_DETAIL);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getBusinessDetailsJSON(Business business) {

		RetrieveBusinessInput bdInput = new RetrieveBusinessInput();
		bdInput.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());
		bdInput.setAssignmentId(business.getAssignmentId());
		bdInput.setBusinessId(business.getBusinessId());
		return ModelUtil.serialize(bdInput);
	}

	@SuppressWarnings("unchecked")
	public void navigateToDetailActivity(ServiceResponse response) {

		BaseActivity activity = (BaseActivity) getActivity();
		try {

			BusinessDetailViewModel model = new BusinessDetailViewModel();
	
			BusinessDetail details = (BusinessDetail) ModelUtil.deserialize(response.getOutput(), BusinessDetail.class);
	
			model.setSelectedBusiness(details);
			model.setBusinesses((List<Business>) data);
			model.setTimeLine(TimeLine.TODAY);
			model.setSelectedIndex(findIndex(details.getAssignmentId()));
	
			Content.getInstance().addContent(Keys.RETRIEVE_BUSINESS_DETAILS_KEY, model);
			Content.getInstance().addContent(Keys.SELECTED_TIMELINE, TimeLine.TODAY);
			activity.openActivity(getActivity(), BusinessDetailActivity.class, activity.getBundle(Keys.RETRIEVE_BUSINESS_DETAILS_KEY));
		} catch (Exception e) {
			activity.convertAndThrow(e, Titles.MY_ROUTE_TITLE);
		}
	}

	@SuppressWarnings("unchecked")
	private int findIndex(int assignmentId) {

		List<Business> businesses = (List<Business>) data;
		for (int i = 0; i < businesses.size(); i++) {
			if (assignmentId == businesses.get(i).getAssignmentId()) {
				return i;
			}
		}

		return -1;
	}

	public void refreshList(Location currLocation) {
		this.currLocation = currLocation;
		populateList();
	}

	public boolean showRoute(GestureMotion motion, Business business) {

		if (GestureMotion.BT == motion || GestureMotion.TB == motion) return false;

		Content.getInstance().addContent(Keys.SHOW_ROUTE_BUSINESS, business);
		Content.getInstance().addContent(Keys.SHOW_ROUTE_BUSINESS_FROM_DETAILS, false);
		Content.getInstance().addContent(Keys.SELECTED_TIMELINE, TimeLine.TODAY);
		BaseActivity activity = (BaseActivity) getActivity();
		Bundle  bundle = activity.getBundle(Keys.SHOW_ROUTE_BUSINESS);
		activity.openActivity(activity, ShowBusinessRouteActivity.class, bundle);

		return true;
	}

	public void onSwipeTop(Business business) {
		showRoute(GestureMotion.BT, business);
    }

	public void onSwipeRight(Business business) {
		showRoute(GestureMotion.LR, business);
    }

	public void onSwipeLeft(Business business) {
		showRoute(GestureMotion.RL, business);
    }

	public void onSwipeBottom(Business business) {
		showRoute(GestureMotion.TB, business);
    }
}

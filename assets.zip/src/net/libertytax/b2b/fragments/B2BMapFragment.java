package net.libertytax.b2b.fragments;

import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.ErrorCode;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import com.google.android.gms.maps.MapFragment;

public class B2BMapFragment extends MapFragment {

	private OnMapAttachedListener listener;
	private OnMapViewCreatedListener viewListener;

	public void setListener(OnMapAttachedListener listener) {
		this.listener = listener;
	}

	public void setViewListener(OnMapViewCreatedListener viewListener) {
		this.viewListener = viewListener;
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		if (listener != null) {
			listener.OnMapAttached(activity);
		} else {
			throw new AppException(new Error(ErrorCode.MAP_LISTENER_NOT_ATTACHED));
		}
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		if (viewListener != null) {
			viewListener.OnMapViewCreated();
		} else {
			throw new AppException(new Error(ErrorCode.MAP_LISTENER_NOT_ATTACHED));
		}
	}

	public interface OnMapAttachedListener {
		void OnMapAttached(Activity activity);
	}

	public interface OnMapViewCreatedListener {
		void OnMapViewCreated();
	}
}

package net.libertytax.b2b.fragments;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import net.libertytax.b2b.R;
import net.libertytax.b2b.activities.BaseActivity;
import net.libertytax.b2b.activities.BusinessDetailActivity;
import net.libertytax.b2b.activities.RouteActivity;
import net.libertytax.b2b.activities.ShowBusinessRouteActivity;
import net.libertytax.b2b.adapters.BusinessListAdapter;
import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.Constants.Keys;
import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Constants.Misc;
import net.libertytax.b2b.base.Constants.RequestCode;
import net.libertytax.b2b.base.Constants.RequestType;
import net.libertytax.b2b.base.Constants.Titles;
import net.libertytax.b2b.base.Constants.URL;
import net.libertytax.b2b.base.Content;
import net.libertytax.b2b.base.Error;
import net.libertytax.b2b.base.ErrorCode;
import net.libertytax.b2b.base.ServiceInput;
import net.libertytax.b2b.base.ServiceResponse;
import net.libertytax.b2b.maputils.ui.TextIconGenerator;
import net.libertytax.b2b.model.Business;
import net.libertytax.b2b.model.BusinessDetail;
import net.libertytax.b2b.model.BusinessDetailViewModel;
import net.libertytax.b2b.model.Filter;
import net.libertytax.b2b.model.OnMapLoadedListener;
import net.libertytax.b2b.model.RetrieveBusinessInput;
import net.libertytax.b2b.model.TimeLine;
import net.libertytax.b2b.util.B2BContext;
import net.libertytax.b2b.util.B2BLocationManager;
import net.libertytax.b2b.util.LocationUtils;
import net.libertytax.b2b.util.LocationValue;
import net.libertytax.b2b.util.ModelUtil;
import net.libertytax.b2b.util.PriorityComparator;
import net.libertytax.b2b.util.SwipeDetector;
import net.libertytax.b2b.util.SwipeDetector.GestureMotion;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.IntentSender;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.location.LocationClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class BusinessSplitFragment extends BaseFragment
	implements  LocationListener,
				ConnectionCallbacks,
				OnConnectionFailedListener,
				OnItemClickListener {

	private List<Business> businesses;
	private List<Business> filteredBusinesses;
    private GoogleMap gMap;
	private TextView txtNoAssignments;
    private ListView lstBusiness;

    private SwipeDetector listSwipeDetector;

	// Stores the current instantiation of the location client in this object
    private LocationClient mLocationClient;

    // A request to connect to Location Services
    private LocationRequest mLocationRequest;

    /*
     * Note if updates have been turned on. Starts out as "false"; is set to "true" in the
     * method handleRequestSuccess of LocationUpdateReceiver.
     *
     */
    boolean mUpdatesRequested = false;

    Location currentLocation;

    private PolylineOptions polyLineOptions;

    private boolean canStopProgress;

    private LatLngBounds.Builder builder;

    @Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

    	boolean exists = Content.containsKey(Keys.MAP_SPLIT_VIEW_KEY);
    	View view = null;

    	if (exists) {

    		view = (View) Content.resolve(Keys.MAP_SPLIT_VIEW_KEY);

    		ViewGroup parent = (ViewGroup) view.getParent();
            if (parent != null)
                parent.removeView(view);
        }

    	try {

    		ViewGroup vg = (ViewGroup) inflater.inflate(R.layout.split_container, null);

    		view = inflater.inflate(R.layout.business_split, vg, true);

    		Content.getInstance().addContent(Keys.MAP_SPLIT_VIEW_KEY, view);
        } catch (InflateException e) {
            /* map is already there, just return view as it is */
        }

    	return view;
	}

    @Override
    protected void prepareControls() {

        // Create a new global location parameters object
        mLocationRequest = LocationRequest.create();

        /*
         * Set the update interval
         */
        mLocationRequest.setInterval(LocationUtils.UPDATE_INTERVAL_IN_MILLISECONDS);

        // Use high accuracy
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        // Set the interval ceiling to one minute
        mLocationRequest.setFastestInterval(LocationUtils.FAST_INTERVAL_CEILING_IN_MILLISECONDS);

        // Note that location updates are off until the user turns them on
        mUpdatesRequested = false;

        /*
         * Create a new location client, using the enclosing class to
         * handle callbacks.
         */
        mLocationClient = new LocationClient(this.getActivity(), this, this);

        lstBusiness = (ListView) getActivity().findViewById(R.id.lstBusinessSplit);

        txtNoAssignments = (TextView) getView().findViewById(R.id.txtNoAssignments);

        setUpMapIfNeeded();
    }

    @Override
    protected void subscribeEvents() {

		lstBusiness.setOnItemClickListener(this);

		listSwipeDetector = new SwipeDetector();
		lstBusiness.setOnTouchListener(listSwipeDetector);
    }

    private OnMapLoadedListener listener;
    public void setMapLoadedListener(OnMapLoadedListener listener) {
    	this.listener = listener;
    }

    @SuppressWarnings("unchecked")
	@Override
    protected void applyDefaults() {

    	businesses = (List<Business>)data;
		Collections.sort(businesses, new PriorityComparator());
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
    	super.onViewCreated(view, savedInstanceState);

		if (businesses == null || businesses.size() == 0) {
			showList(false);
		} else {
			showList(true);
			populateList();
		}
    }

	@Override
	public void onItemClick(AdapterView<?> adapterView, View view, int position, long arg3) {

		BaseActivity activity = (BaseActivity) getActivity();
		try {
			Business business = (Business) lstBusiness.getItemAtPosition(position);
			if (listSwipeDetector.swipeDetected()) {
	            if (listSwipeDetector.getAction() == SwipeDetector.GestureMotion.LR) {
	            	onSwipeRight(business);
	            }
	            if (listSwipeDetector.getAction() == SwipeDetector.GestureMotion.RL) {
	            	onSwipeLeft(business);
	            }
			} else {
				B2BContext.getInstance().setShowProgress(true);
				activity.executeService(RequestCode.RETRIEVE_BUSINESS_DETAILS, true, getBusinessDetailsInput(business));
			}
		} catch (Exception e) {
			activity.convertAndThrow(e, Titles.MY_ROUTE_TITLE);
		}
	}

	public void navigateToDetailsFromSplit(ServiceResponse response) {
		navigateToDetailActivity(response);
	}

	public boolean showRouteFromSplit(Business business) {

		Content.getInstance().addContent(Keys.SHOW_ROUTE_BUSINESS, business);
		Content.getInstance().addContent(Keys.SHOW_ROUTE_BUSINESS_FROM_DETAILS, false);
		Content.getInstance().addContent(Keys.SELECTED_TIMELINE, TimeLine.TODAY);
		BaseActivity activity = (BaseActivity) getActivity();
		Bundle  bundle = activity.getBundle(Keys.SHOW_ROUTE_BUSINESS);
		activity.openActivity(activity, ShowBusinessRouteActivity.class, bundle);

		return true;
	}

	@SuppressWarnings("unchecked")
	public void navigateToDetailActivity(ServiceResponse response) {

		BaseActivity activity = (BaseActivity) getActivity();
		try {

			BusinessDetailViewModel model = new BusinessDetailViewModel();
	
			BusinessDetail details = (BusinessDetail) ModelUtil.deserialize(response.getOutput(), BusinessDetail.class);
	
			model.setSelectedBusiness(details);
			model.setBusinesses((List<Business>) data);
			model.setTimeLine(TimeLine.TODAY);
			model.setSelectedIndex(findIndex(details.getAssignmentId()));
	
			Content.getInstance().addContent(Keys.RETRIEVE_BUSINESS_DETAILS_KEY, model);
			Content.getInstance().addContent(Keys.SELECTED_TIMELINE, TimeLine.TODAY);
			activity.openActivity(getActivity(), BusinessDetailActivity.class, activity.getBundle(Keys.RETRIEVE_BUSINESS_DETAILS_KEY));
		} catch (Exception e) {
			activity.convertAndThrow(e, Titles.MY_ROUTE_TITLE);
		}
	}

	@SuppressWarnings("unchecked")
	private int findIndex(int assignmentId) {

		List<Business> businesses = (List<Business>) data;
		for (int i = 0; i < businesses.size(); i++) {
			if (assignmentId == businesses.get(i).getAssignmentId()) {
				return i;
			}
		}

		return -1;
	}

	private ServiceInput getBusinessDetailsInput(Business business) {

		ServiceInput input = new ServiceInput();
		input.setHeaderRequired(false);
		input.setInput(getBusinessDetailsJSON(business));
		input.setUrl(URL.RETRIEVE_BUSSINESS_DETAIL);
		input.setRequestType(RequestType.POST);
		return input;
	}

	private String getBusinessDetailsJSON(Business business) {

		RetrieveBusinessInput bdInput = new RetrieveBusinessInput();
		bdInput.setMarketerId(B2BContext.getInstance().getLoginResult().getMarketerId());
		bdInput.setAssignmentId(business.getAssignmentId());
		bdInput.setBusinessId(business.getBusinessId());
		return ModelUtil.serialize(bdInput);
	}

	public boolean showRoute(GestureMotion motion, Business business) {

		if (GestureMotion.BT == motion || GestureMotion.TB == motion) return false;

		Content.getInstance().addContent(Keys.SHOW_ROUTE_BUSINESS, business);
		Content.getInstance().addContent(Keys.SHOW_ROUTE_BUSINESS_FROM_DETAILS, false);
		Content.getInstance().addContent(Keys.SELECTED_TIMELINE, TimeLine.TODAY);
		BaseActivity activity = (BaseActivity) getActivity();
		Bundle  bundle = activity.getBundle(Keys.SHOW_ROUTE_BUSINESS);
		activity.openActivity(activity, ShowBusinessRouteActivity.class, bundle);

		return true;
	}

	private void showList(boolean showList) {

		lstBusiness.setVisibility(showList ? View.VISIBLE : View.GONE);
		txtNoAssignments.setVisibility(!showList ? View.VISIBLE : View.GONE);
		((RouteActivity) getActivity()).setTitle((Filter) Content.resolve(Keys.SELECTED_FILTER_TODAY));
	}

    private void populateList() {

    	List<Business> filtered = getFiltered();
    	BusinessListAdapter businessAdapter = new BusinessListAdapter(getActivity(), filtered);
		lstBusiness.setAdapter(businessAdapter);
		showList(filtered.size() > 0);
	}

	private List<Business> getFiltered() {

		if (!Content.containsKey(Keys.SELECTED_FILTER_TODAY)) {
			return businesses;
		}

		Filter filter = (Filter) Content.resolve(Keys.SELECTED_FILTER_TODAY);

		if (Filter.ALL == filter) return businesses;

		List<Business> filtered = new ArrayList<Business>();
		for (Business business : businesses) {

			if (Filter.CLOSEST == filter) {
				if (isClosest(business)) {
					filtered.add(business);
				}
			} else if (filter == getFilter(business.getStatus())) {
				filtered.add(business);
			}
		}
		return filtered;
	}

	@SuppressWarnings("unused")
	private boolean isClosest(Business business) {

		if (Labels.COMPLETED.equals(business.getStatus())) return false;

		if (currentLocation != null) {
			float[] results = null;
			Location.distanceBetween(currentLocation.getLatitude(), currentLocation.getLongitude(),
					Double.parseDouble(business.getLattitude()),
					Double.parseDouble(business.getLongitude()),
					results);
			if (results != null && results[0] < 8046.72f) {
				return true;
			}
		}
		return false;
	}

	private Filter getFilter(String filter) {

		if (Labels.COMPLETED.equals(filter)) return Filter.COMPLETED;
		if (Labels.IN_PROGRESS.equals(filter)) return Filter.INPROGRESS;
		if (Labels.IN_COMPLETE.equals(filter)) return Filter.INCOMPLETE;
		if (Labels.CLOSEST.equals(filter)) return Filter.CLOSEST;
		return Filter.ALL;
	}

	private void addMarkerForRoutes(boolean clearMap) {

    	// If Google Play Services is available
        if (servicesConnected()) {

        	BaseActivity activity = (BaseActivity) getActivity();
        	activity.showProgress(activity, Labels.EMPTY, Misc.KEY_LOADING);

        	if (clearMap) {
        		gMap.clear();
        	}

        	getCurrentLocation();

        	filteredBusinesses = addMarkersToMap();

        	if (filteredBusinesses.size() == 0) {
        		canStopProgress = true;
        		stopProgress();
        		listener.mapLoaded();
        		return;
        	}

        	drawPolyLines();
        }
    }

    private void getCurrentLocation() {
        B2BLocationManager.getB2BLocationManager().getCurrentLocation(this.getActivity(), locationValue);
    }

    public LocationValue locationValue = new LocationValue() {

    	@Override
        public void getCurrentLocation(Location location) {
            // You will get location here if the GPS is enabled
            if(location != null) {

            	currentLocation = location;

            	if (currentLocation != null) {

            		LatLng currLatLng = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
	            	addMarker(currLatLng,
	            			Misc.CURRENT_LOCATION,
	            			Labels.EMPTY,
	            			BitmapDescriptorFactory.fromResource(R.drawable.map_marketer));

	            	CameraUpdate cu = CameraUpdateFactory.newLatLngZoom(currLatLng, 14);

	            	gMap.moveCamera(cu);

	            	gMap.animateCamera(cu);

	            	listener.mapLoaded();

	            	stopProgress();
            	}
            }
        }
    };

    private void stopProgress() {

    	if (canStopProgress) {
        	BaseActivity activity = (BaseActivity) getActivity();
        	activity.dismissProgress();
        	canStopProgress = false;
    	} else {
    		canStopProgress = true;
    	}
    }

    private List<Business> addMarkersToMap() {

    	List<Business> filtered = getFiltered();

    	if (filtered.size() <= 0) {
    		canStopProgress = true;
    		return filtered;
    	}

    	builder = new LatLngBounds.Builder();
    	for (Business business : filtered) {

    		TextIconGenerator iconFactory = new TextIconGenerator(getActivity());
    		if (Misc.STATUS_COMPLETED.toLowerCase(Locale.getDefault()).equals(
    				business.getStatus().toLowerCase(Locale.getDefault()))) {

    			iconFactory.setStyle(TextIconGenerator.STYLE_GREEN);
    		} else {
    			iconFactory.setStyle(TextIconGenerator.STYLE_RED);
    		}

    		BitmapDescriptor descriptor = BitmapDescriptorFactory.fromBitmap(iconFactory.makeIcon(business.getSeqNumber().toString()));

    		Double lat = 0.0;
    		Double lng = 0.0;
    		if (!Labels.EMPTY.equals(business.getLattitude().trim())) {
    			lat = Double.parseDouble(business.getLattitude());
    		}
    		if (!Labels.EMPTY.equals(business.getLattitude().trim())) {
    			lng = Double.parseDouble(business.getLongitude());
    		}
    		LatLng latLng = new LatLng(lat, lng);
    		addMarker(latLng,
        			business.getBusinessName(),
        			business.getAddress(),
        			descriptor);

            builder.include(latLng);
    	}

    	return filtered;
    }

    private void drawPolyLines() {

    	if (filteredBusinesses.size() <= 1) {
    		stopProgress();
    		listener.mapLoaded();
    		return;
    	}

		polyLineOptions = getPolyLineOptions();

//    	B2BContext.getInstance().setShowProgress(true);

    	Content.getInstance().addContent(Keys.GOOGLE_SPLIT_POLY_LINE_COUNTER, 0);
    	fetchLatLng(filteredBusinesses.get(0), filteredBusinesses.get(1), false, false);
    }

    private void fetchLatLng(Business source, Business destination, boolean isLastCall, boolean startProgress) {

    	BaseActivity activity = (BaseActivity) getActivity();
    	try {
    		if (isLastCall) {
    			activity.executeService(RequestCode.GOOGLE_SPLIT_ROAD_SERVICES_LAST, isLastCall, startProgress,
    					getGoogleMapInput(source.getLattitude(), source.getLongitude(),
    									  destination.getLattitude(), destination.getLongitude()));
    		} else {
    			activity.executeService(RequestCode.GOOGLE_SPLIT_ROAD_SERVICES, isLastCall, startProgress,
    					getGoogleMapInput(source.getLattitude(), source.getLongitude(),
								  destination.getLattitude(), destination.getLongitude()));
    		}
    	} catch (Exception e) {
    		activity.handleError(new AppException(new Error(ErrorCode.MAP_ROAD_FETCH_FAILED)), Titles.MY_MAP_TITLE);
    	}
    }

    private ServiceInput getGoogleMapInput(String sourceLat, String sourceLong, String destLat, String destLong) {

    	ServiceInput input = new ServiceInput();
    	input.setHeaderRequired(false);
    	input.setInput("");
    	input.setRequestType(RequestType.GET);
    	input.setUrl(makeURL(sourceLat, sourceLong, destLat, destLong));

    	return input;
    }

    private PolylineOptions getPolyLineOptions() {

    	if (polyLineOptions == null) {
	    	polyLineOptions = new PolylineOptions();
	    	polyLineOptions.width(5);
	    	polyLineOptions.color(getResources().getColor(R.color.map_polyline));
	    	polyLineOptions.geodesic(true);
    	}

    	return polyLineOptions;
    }

    public String makeURL (String sourceLat, String sourceLong, String destLat, String destLong ){
    	
        StringBuilder urlString = new StringBuilder();
        urlString.append("http://maps.googleapis.com/maps/api/directions/json");
        urlString.append("?origin=");// from
        urlString.append(sourceLat);
        urlString.append(",");
        urlString.append(sourceLong);
        urlString.append("&destination=");// to
        urlString.append(destLat);
        urlString.append(",");
        urlString.append(destLong);
        urlString.append("&sensor=false&mode=driving&alternatives=false");
        return urlString.toString();
    }

    @Override
    public void onStop() {

        // If the client is connected
        if (mLocationClient.isConnected()) {
            stopPeriodicUpdates();
        }

        // After disconnect() is called, the client is considered "dead".
        mLocationClient.disconnect();

        super.onStop();
    }

    /*
     * Called when the Activity is restarted, even before it becomes visible.
     */
    @Override
    public void onStart() {

        super.onStart();

        mUpdatesRequested = true;

        /*
         * Connect the client. Don't re-start any requests here;
         * instead, wait for onResume()
         */
        mLocationClient.connect();
    }

    private void stopPeriodicUpdates() {
        mLocationClient.removeLocationUpdates(this);
    }

    private void addMarker(LatLng latLng, String title, String snippet, BitmapDescriptor bitmap) {

    	// Uses a colored icon.
        gMap.addMarker(new MarkerOptions()
                .position(latLng)
                .title(title)
                .snippet(snippet)
                .icon(bitmap));
    }

    private boolean servicesConnected() {

        // Check that Google Play services is available
        int resultCode =
                GooglePlayServicesUtil.isGooglePlayServicesAvailable(this.getActivity());

        // If Google Play services is available
        if (ConnectionResult.SUCCESS == resultCode) {
            // In debug mode, log the status
            Log.d(LocationUtils.APPTAG, getString(R.string.play_services_available));

            // Continue
            return true;
        // Google Play services was not available for some reason
        } else {
        	((BaseActivity)getActivity()).handleError(new AppException(new Error(ErrorCode.UNABLE_TO_CONNECT_MAP)), Titles.MY_MAP_TITLE);
            return false;
        }
    }

    private void setUpMapIfNeeded() {

    	// Do a null check to confirm that we have not already instantiated the map.
        if (gMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            gMap = ((MapFragment)getFragmentManager().findFragmentById(R.id.mapSplit)).getMap();

            gMap.getUiSettings().setAllGesturesEnabled(true);
        }
    }

	@Override
	public void onConnectionFailed(ConnectionResult connectionResult) {

        /*
         * Google Play services can resolve some errors it detects.
         * If the error has a resolution, try sending an Intent to
         * start a Google Play services activity that can resolve
         * error.
         */
        if (connectionResult.hasResolution()) {
            try {

                // Start an Activity that tries to resolve the error
                connectionResult.startResolutionForResult(
                        this.getActivity(),
                        LocationUtils.CONNECTION_FAILURE_RESOLUTION_REQUEST);

                /*
                * Thrown if Google Play services canceled the original
                * PendingIntent
                */

            } catch (IntentSender.SendIntentException e) {

                // Log the error
                e.printStackTrace();
            }
        } else {

            // If no resolution is available, display a dialog to the user with the error.
            ((BaseActivity)getActivity()).handleError(new AppException(new Error(ErrorCode.UNABLE_TO_CONNECT_MAP)), Titles.MY_MAP_TITLE);
        }
	}

	@Override
	public void onConnected(Bundle arg0) {

        if (mUpdatesRequested) {

        	startPeriodicUpdates();

        	addMarkerForRoutes(true);
        }
	}

	private void startPeriodicUpdates() {
        mLocationClient.requestLocationUpdates(mLocationRequest, this);
    }

	@Override
	public void onDisconnected() {
	}

	@Override
	public void onLocationChanged(Location location) {
//        CURR_LOC = LocationUtils.getLatLng(this.getActivity(), location);
	}

	public void refresh(Location currLocation) {
		this.currentLocation = currLocation;
		populateList();
		addMarkerForRoutes(true);
	}

	public void onRouteFetching(ServiceResponse output) {

		BaseActivity activity = (BaseActivity) getActivity();
		try {
			polyLineOptions.addAll(decode(output.getOutput()));

			Integer counter = (Integer) Content.resolve(Keys.GOOGLE_SPLIT_POLY_LINE_COUNTER);
			counter++;

			boolean isLastCall = (counter >= (filteredBusinesses.size() - 2));

			Content.getInstance().addContent(Keys.GOOGLE_SPLIT_POLY_LINE_COUNTER, counter);
			fetchLatLng(filteredBusinesses.get(counter), filteredBusinesses.get(counter + 1), isLastCall, false);
		} catch (Exception e) {
			activity.handleError(new AppException(new Error(ErrorCode.UNKNOWN_GMAP)), Titles.MY_MAP_TITLE);
			listener.mapLoaded();
			stopProgress();
		}
	}

	public void onRouteFetched(ServiceResponse output) {

		BaseActivity activity = (BaseActivity) getActivity();
		try {

			polyLineOptions.addAll(decode(output.getOutput()));
			gMap.addPolyline(polyLineOptions);

			CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(builder.build(), 200, 200, 0);
	    	gMap.moveCamera(cu);
	    	gMap.animateCamera(cu);

		} catch (Exception e) {
			activity.handleError(new AppException(new Error(ErrorCode.UNKNOWN_GMAP)), Titles.MY_MAP_TITLE);
		} finally {
			listener.mapLoaded();
			stopProgress();
		}
	}

	private List<LatLng> decode(String json) {

	    try {
	
			JSONObject jsonObj = new JSONObject(json);
			JSONArray routeArray = jsonObj.getJSONArray(Misc.ROUTE_PARAM_NAME);
			JSONObject routes = routeArray.getJSONObject(0);
			JSONObject overviewPolylines = routes.getJSONObject(Misc.OVERVIEW_POLYLINE_PARAM_NAME);
			String encodedString = overviewPolylines.getString(Misc.POINTS_PARAM_NAME);
			return decodePoly(encodedString);
	    } catch (JSONException e) {
		}

	    return new ArrayList<LatLng>();
	}

	private List<LatLng> decodePoly(String encoded) {

	    List<LatLng> poly = new ArrayList<LatLng>();
	    int index = 0, len = encoded.length();
	    int lat = 0, lng = 0;

	    while (index < len) {
	        int b, shift = 0, result = 0;
	        do {
	            b = encoded.charAt(index++) - 63;
	            result |= (b & 0x1f) << shift;
	            shift += 5;
	        } while (b >= 0x20);
	        int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
	        lat += dlat;

	        shift = 0;
	        result = 0;
	        do {
	            b = encoded.charAt(index++) - 63;
	            result |= (b & 0x1f) << shift;
	            shift += 5;
	        } while (b >= 0x20);
	        int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
	        lng += dlng;

	        LatLng p = new LatLng( (((double) lat / 1E5)),
	                 (((double) lng / 1E5) ));
	        poly.add(p);
	    }

	    return poly;
	}

	public void onSwipeTop(Business business) {
		showRoute(GestureMotion.BT, business);
    }

	public void onSwipeRight(Business business) {
		showRoute(GestureMotion.LR, business);
    }

	public void onSwipeLeft(Business business) {
		showRoute(GestureMotion.RL, business);
    }

	public void onSwipeBottom(Business business) {
		showRoute(GestureMotion.TB, business);
    }
}

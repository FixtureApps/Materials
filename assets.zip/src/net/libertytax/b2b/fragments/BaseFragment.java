package net.libertytax.b2b.fragments;

import net.libertytax.b2b.activities.BaseActivity;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class BaseFragment extends EmptyFragmentWithCallbackOnResume {

	protected Object data;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		return super.onCreateView(inflater, container, savedInstanceState);
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {

		prepareControls();
		subscribeEvents();
		applyDefaults();

		super.onViewCreated(view, savedInstanceState);
	}

	@Override
	public void onAttach(Activity activity) {

		super.onAttach(activity);

		BaseActivity baseActivity = (BaseActivity)activity;
		data = baseActivity.getData();
	}

	protected void addFragment(int resource, Fragment fragment) {

        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();

        ft.add(resource, fragment);
        ft.commitAllowingStateLoss();
    }

	protected void replaceFragment(int resource, Fragment fragment) {

        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();

        ft.replace(resource, fragment);
        ft.commitAllowingStateLoss();
    }

	protected void removeFragment(Fragment fragment) {

        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();

        ft.remove(fragment);
        ft.commitAllowingStateLoss();
    }

	protected void prepareControls() {	}
	protected void subscribeEvents() {	}
	protected void applyDefaults() {	}
}

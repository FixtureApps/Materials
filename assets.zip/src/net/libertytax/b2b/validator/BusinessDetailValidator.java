package net.libertytax.b2b.validator;

import net.libertytax.b2b.base.Error;
import net.libertytax.b2b.base.ErrorCode;
import net.libertytax.b2b.model.CompleteAssignment;

public class BusinessDetailValidator extends BaseValidator {

	public void validateCompleteAssignment(CompleteAssignment cAssignment) {

		if (cAssignment.getFeedback() == null) {
			addError(new Error(ErrorCode.SELECT_FEEDBACK));
		}
		if (cAssignment.getRatings() == 0) {
			addError(new Error(ErrorCode.GIVE_RATING));
		}

		checkAndThrowError();
	}
}

package net.libertytax.b2b.validator;

import net.libertytax.b2b.base.Constants.Labels;
import net.libertytax.b2b.base.Error;
import net.libertytax.b2b.base.ErrorCode;
import net.libertytax.b2b.model.ContactDetail;

public class ContactDetailValidator extends BaseValidator {

	public void validateContactDetail(ContactDetail cDetail) {

		if (cDetail.getAddress() == null || Labels.EMPTY.equals(cDetail.getAddress().trim())) {
			addError(new Error(ErrorCode.CONTACT_DETAIL_ADDRESS_EMPTY));
		}
		if (cDetail.getEmailId() == null || Labels.EMPTY.equals(cDetail.getEmailId().trim())) {
			addError(new Error(ErrorCode.CONTACT_DETAIL_EMAIL_EMPTY));
		} else {
			matcher = emailPattern.matcher(cDetail.getEmailId());
			if (!matcher.matches()) {
				addError(new Error(ErrorCode.CONTACT_DETAIL_INVALID_EMAIL));
			}
		}
		if (cDetail.getPhoneNumber() == null || Labels.EMPTY.equals(cDetail.getPhoneNumber().trim())) {
			addError(new Error(ErrorCode.CONTACT_DETAIL_PHONE_EMPTY));
		} else {
			matcher = phonePattern.matcher(cDetail.getPhoneNumber());
			if (!matcher.matches()) {
				addError(new Error(ErrorCode.CONTACT_DETAIL_INVALID_PHONE));
			}
		}
		if (cDetail.getContactPerson() == null || Labels.EMPTY.equals(cDetail.getContactPerson().trim())) {
			addError(new Error(ErrorCode.CONTACT_DETAIL_PERSON_EMPTY));
		}
		if (cDetail.getMobileNumber() != null && !Labels.EMPTY.equals(cDetail.getMobileNumber().trim())) {
			matcher = phonePattern.matcher(cDetail.getMobileNumber());
			if (!matcher.matches()) {
				addError(new Error(ErrorCode.CONTACT_DETAIL_INVALID_MOBILE));
			}
		}
		if (cDetail.getFax() != null && !Labels.EMPTY.equals(cDetail.getFax().trim())) {
			matcher = phonePattern.matcher(cDetail.getFax());
			if (!matcher.matches()) {
				addError(new Error(ErrorCode.CONTACT_DETAIL_INVALID_FAX));
			}
		}

		checkAndThrowError();
	}
}

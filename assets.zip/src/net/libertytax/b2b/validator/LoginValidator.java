package net.libertytax.b2b.validator;

import net.libertytax.b2b.base.Error;
import net.libertytax.b2b.base.ErrorCode;

public class LoginValidator extends BaseValidator {

	public void validateLogin(String userName, String password) {

		if (userName == null || "".equals(userName)) {
			addError(new Error(ErrorCode.USERNAME_EMPTY));
		}
		if (userName.contains(" ") && password.contains(" ")) {
			addError(new Error(ErrorCode.USERNAME_PASS_HAS_SPACE));
			checkAndThrowError();
		}
		if (userName.contains(" ")) {
			addError(new Error(ErrorCode.USERNAME_HAS_SPACE));
		}
		if (password == null || "".equals(password)) {
			addError(new Error(ErrorCode.PASSWORD_EMPTY));
		}
		if (password.contains(" ")) {
			addError(new Error(ErrorCode.PASSWORD_HAS_SPACE));
		}

		checkAndThrowError();
	}
}

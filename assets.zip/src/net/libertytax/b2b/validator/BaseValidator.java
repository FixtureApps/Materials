package net.libertytax.b2b.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.libertytax.b2b.base.AppException;
import net.libertytax.b2b.base.Error;

public class BaseValidator {

	protected String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	protected String PHONE_PATTERN = "^\\d{3}-\\d{3}-\\d{4}$";

	protected Pattern emailPattern;
	protected Pattern phonePattern;
	protected Matcher matcher;

	private List<Error> errors = new ArrayList<Error>();

	public BaseValidator() {
		emailPattern = Pattern.compile(EMAIL_PATTERN);
		phonePattern = Pattern.compile(PHONE_PATTERN);
	}

	protected void addError(Error error) {
		errors.add(error);
	}

	protected boolean hasErrors() {
		return errors.size() > 0;
	}

	protected List<Error> getErrors() {
		return errors;
	}

	protected void checkAndThrowError() {
		if (hasErrors()) {
			throw new AppException(getErrors());
		}
	}
}

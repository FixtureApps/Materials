package net.libertytax.b2b.customviews;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.EditText;

public class B2BEditText extends EditText {

	public B2BEditText(Context context, AttributeSet attrs) {
		super(context, attrs);
	}
}

package net.libertytax.b2b.customviews;

import net.libertytax.b2b.R;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.RatingBar;

public class B2BRatingBar extends RatingBar {

	public B2BRatingBar(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	@Override
	public Drawable getBackground() {
		return getContext().getResources().getDrawable(R.drawable.star_off);
	}

	@Override
	public synchronized int getSecondaryProgress() {
		return R.drawable.star_off;
	}

	@Override
	public synchronized int getProgress() {
		return R.drawable.star_on;
	}

	@Override
	public int getMinimumWidth() {
		return 16;
	}

	@Override
	public int getMinimumHeight() {
		return 16;
	}
}

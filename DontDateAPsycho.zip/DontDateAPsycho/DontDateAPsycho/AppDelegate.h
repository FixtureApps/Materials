//
//  AppDelegate.h
//  DontDateAPsycho
//
//  Created by fixtureapps on 11/3/13.
//  Copyright (c) 2013 fixtureapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

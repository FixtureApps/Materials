//
//  Constants.h
//  DontDateAPsycho
//
//  Created by fixtureapps on 11/4/13.
//  Copyright (c) 2013 fixtureapps. All rights reserved.
//

#define kSectionHeader1 @"KNOW YOURSELF"
#define kSectionHeader2 @"RELATIONSHIP ISSUES"
#define kSectionHeader3 @"PERSONAL ISSUES"
#define kSectionHeader4 @"DEALING WITH OTHERS"
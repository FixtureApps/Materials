//
//  DashBoardViewController.m
//  DontDateAPsycho
//
//  Created by Vidya on 07/11/13.
//  Copyright (c) 2013 fixtureapps. All rights reserved.
//

#import "DashBoardViewController.h"
#import "QuizCategoryViewController.h"

@interface DashBoardViewController ()
{
    int selectedIndex;
}

@end

@implementation DashBoardViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.carousel.type = iCarouselTypeRotary;
    self.carousel.vertical = NO;
    self.carousel.viewpointOffset = CGSizeMake(0.0f, -500);
    self.carousel.contentOffset = CGSizeMake(0.0f, -400);

}

-(void) viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBar.hidden = YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) onMenuButtonClicked
{
    QuizCategoryViewController *quizCtegoryVC = [self.storyboard instantiateViewControllerWithIdentifier:@"QuizCategoryVC"];

    switch (selectedIndex) {
            
        case 0:
            [self.navigationController pushViewController:[self.storyboard instantiateViewControllerWithIdentifier:@"QuizCategoryVC2"] animated:YES];
            break;
        
        case 1:
            quizCtegoryVC.categoriesArray = [NSArray arrayWithObjects:@"Are You Too Needy?", @"Awww...Ain't You Sweet!", @"Does SEX Make You Feel Guilty?", @"Is There Any Romance in Your Soul?", nil];
            [self.navigationController pushViewController:quizCtegoryVC animated:YES];
            break;
            
         case 2:
            quizCtegoryVC.categoriesArray = [NSArray arrayWithObjects:@"Are You a Big Ol' Rage Monster?", @"Control FREAK!", @"Do You Worry Too Much?", @"Test Your Self-Control!", nil];
            [self.navigationController pushViewController:quizCtegoryVC animated:YES];
            break;
            
        case 3:
            quizCtegoryVC.categoriesArray = [NSArray arrayWithObjects:@"Do You Trust Too Easily?", @"Does a Manipulator Lurk Inside You?", @"How Much of a Friend Are You?", @"Would You Rather Fight?", nil];
            [self.navigationController pushViewController:quizCtegoryVC animated:YES];
            break;

        default:
            break;
    }
}

#pragma mark iCarousel Delegate methods

- (NSUInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return 4;
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSUInteger)index reusingView:(UIView *)view
{
	UIButton *button = (UIButton *)view;
    UIImage *image;
	if (button == nil)
    {
		button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0.0f, 0.0f, 100, 100);
		[button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        button.tag = index;
    }
    
    switch (index)
    {
        case 0:
            image = [UIImage imageNamed:@"know_yourself1.png"];
            break;
            
        case 1:
            image = [UIImage imageNamed:@"relationship_issues1.png"];
            break;
            
        case 2:
            image = [UIImage imageNamed:@"personal_issues1.png"];
            break;
            
        case 3:
            image = [UIImage imageNamed:@"dealing_with_others1.png"];
            break;
            
    }
    [image drawInRect:CGRectMake(0, 0, 136, 168)];
    
    switch(index)
    {
        case 0:
            [button addTarget:self action:@selector(onMenuButtonClicked) forControlEvents:UIControlEventTouchUpInside];
            [button setBackgroundImage:image forState:UIControlStateNormal];
            break;
            
        case 1:
            [button addTarget:self action:@selector(onMenuButtonClicked) forControlEvents:UIControlEventTouchUpInside];
            [button setBackgroundImage:image forState:UIControlStateNormal];
            break;
            
        case 2:
            [button addTarget:self action:@selector(onMenuButtonClicked) forControlEvents:UIControlEventTouchUpInside];
            [button setBackgroundImage:image forState:UIControlStateNormal];
            break;
            
        case 3:
            [button addTarget:self action:@selector(onMenuButtonClicked) forControlEvents:UIControlEventTouchUpInside];
            [button setBackgroundImage:image forState:UIControlStateNormal];
            break;
            
            
    }
	return button;
}

- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index {

    
    selectedIndex = index;
    [self performSelector:@selector(onMenuButtonClicked)];
}

- (CGFloat)carousel:(iCarousel *)_carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value
{
    switch (option)
    {
        case iCarouselOptionFadeMax:
        {
            if (self.carousel.type == iCarouselTypeCustom)
            {
                return 0.0f;
            }
            return value;
        }
        case iCarouselOptionArc:
        {
            return 6.3f;
            
        }
        case iCarouselOptionRadius:
        {
            if (UIInterfaceOrientationIsPortrait([UIApplication sharedApplication].statusBarOrientation))
            {
                return 150;
            }
            return 110;
            
        }
        case iCarouselOptionSpacing:
        {
            return 1.7;
            
        }
        default:
        {
            return value;
        }
    }
    
}


@end

//
//  DashboardViewController.h
//  DontDateAPsycho
//
//  Created by fixtureapps on 11/4/13.
//  Copyright (c) 2013 fixtureapps. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CollapsableTableViewDelegate.h"

@interface DashboardViewController : UIViewController<UITableViewDelegate, UITableViewDataSource, CollapsableTableViewDelegate>

@property (strong, nonatomic) IBOutlet UITableView *categoryTable;

@end

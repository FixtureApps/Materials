//
//  DashboardViewController.m
//  DontDateAPsycho
//
//  Created by fixtureapps on 11/4/13.
//  Copyright (c) 2013 fixtureapps. All rights reserved.
//

#import "DashboardViewController2.h"
#import "CollapsableTableView.h"
#import "Constants.h"

@interface DashboardViewController ()

@end

@implementation DashboardViewController

@synthesize categoryTable;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    CollapsableTableView* tableView = (CollapsableTableView *)categoryTable;
    tableView.collapsableTableViewDelegate = self;
    tableView.sectionsInitiallyCollapsed = YES;
    [tableView setIsCollapsed:NO forHeaderWithTitle:kSectionHeader1];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }

    NSString* labelText = @"";

    switch (indexPath.section) {
        case 0:
            switch (indexPath.row) {
                case 0:
                    labelText = @"How Do You Feel About YOU?";
                    break;
                case 1:
                    labelText = @"How Realistic Can You Be?";
                    break;
                case 2:
                    labelText = @"Large and in Charge!";
                    break;
                case 3:
                    labelText = @"Who Controls Your Life?";
                    break;
                case 4:
                    labelText = @"Emotional Baggage!";
                    break;
                default:
                    break;
            }
            break;
        case 1:
            switch (indexPath.row) {
                case 0:
                    labelText = @"Are You Too Needy?";
                    break;
                case 1:
                    labelText = @"Awww...Ain't You Sweet!";
                    break;
                case 2:
                    labelText = @"Does SEX Make You Feel Guilty?";
                    break;
                case 3:
                    labelText = @"Is There Any Romance in Your Soul?";
                    break;
                default:
                    break;
            }
            break;
        case 2:
            switch (indexPath.row) {
                case 0:
                    labelText = @"Are You a Big Ol' Rage Monster?";
                    break;
                case 1:
                    labelText = @"Control FREAK!";
                    break;
                case 2:
                    labelText = @"Do You Worry Too Much?";
                    break;
                case 3:
                    labelText = @"Test Your Self-Control!";
                    break;
                default:
                    break;
            }
            break;
        case 3:
            switch (indexPath.row) {
                case 0:
                    labelText = @"Do You Trust Too Easily?";
                    break;
                case 1:
                    labelText = @"Does a Manipulator Lurk Inside You?";
                    break;
                case 2:
                    labelText = @"How Much of a Friend Are You?";
                    break;
                case 3:
                    labelText = @"Would You Rather Fight?";
                    break;
                default:
                    break;
            }
            break;
        default:
            break;
    }

    cell.textLabel.text = labelText;
    cell.backgroundColor = [UIColor clearColor];

    return cell;
}

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch (section) {
        case 0: return 5;
        default: return 4;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case 0: return kSectionHeader1;
        case 1: return kSectionHeader2;
        case 2: return kSectionHeader3;
        case 3: return kSectionHeader4;
        default: return @"";
    }
}

-(void) collapsableTableView:(CollapsableTableView *)tableView didCollapseSection:(NSInteger)section title:(NSString *)sectionTitle headerView:(UIView *)headerView
{
    
}

- (void)collapsableTableView:(CollapsableTableView *)tableView didExpandSection:(NSInteger)section title:(NSString *)sectionTitle headerView:(UIView *)headerView
{
    [self collapseAllExcept:sectionTitle];
}

- (void)collapsableTableView:(CollapsableTableView *)tableView willCollapseSection:(NSInteger)section title:(NSString *)sectionTitle headerView:(UIView *)headerView
{
    
}

-(void)collapsableTableView:(CollapsableTableView *)tableView willExpandSection:(NSInteger)section title:(NSString *)sectionTitle headerView:(UIView *)headerView
{
    
}

-(void)collapseAllExcept:(NSString *) header
{
    CollapsableTableView* tableView = (CollapsableTableView *)categoryTable;
    if (![kSectionHeader1 isEqualToString:header]) {
        [tableView setIsCollapsed:YES forHeaderWithTitle:kSectionHeader1 withRowAnimation:UITableViewRowAnimationNone];
    }
    if (![kSectionHeader2 isEqualToString:header]) {
        [tableView setIsCollapsed:YES forHeaderWithTitle:kSectionHeader2 withRowAnimation:UITableViewRowAnimationNone];
    }
    if (![kSectionHeader3 isEqualToString:header]) {
        [tableView setIsCollapsed:YES forHeaderWithTitle:kSectionHeader3 withRowAnimation:UITableViewRowAnimationNone];
    }
    if (![kSectionHeader4 isEqualToString:header]) {
        [tableView setIsCollapsed:YES forHeaderWithTitle:kSectionHeader4 withRowAnimation:UITableViewRowAnimationNone];
    }
}

@end

//
//  QuizCategoryViewController.m
//  DontDateAPsycho
//
//  Created by Vidya on 08/11/13.
//  Copyright (c) 2013 fixtureapps. All rights reserved.
//

#import "QuizCategoryViewController.h"

@interface QuizCategoryViewController ()

@end

@implementation QuizCategoryViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.label1.text = [self.categoriesArray objectAtIndex:0];
    self.label2.text = [self.categoriesArray objectAtIndex:1];
    self.label3.text = [self.categoriesArray objectAtIndex:2];
    self.label4.text = [self.categoriesArray objectAtIndex:3];

}

-(void) viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBar.hidden = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

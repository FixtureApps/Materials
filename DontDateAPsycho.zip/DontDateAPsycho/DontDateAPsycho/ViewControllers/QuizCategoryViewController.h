//
//  QuizCategoryViewController.h
//  DontDateAPsycho
//
//  Created by Vidya on 08/11/13.
//  Copyright (c) 2013 fixtureapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuizCategoryViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *label1;
@property (strong, nonatomic) IBOutlet UILabel *label2;
@property (strong, nonatomic) IBOutlet UILabel *label3;
@property (strong, nonatomic) IBOutlet UILabel *label4;

@property (strong, nonatomic) NSArray *categoriesArray;

@end

//
//  ViewController.m
//  DontDateAPsycho
//
//  Created by fixtureapps on 11/3/13.
//  Copyright (c) 2013 fixtureapps. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)declineClicked:(id)sender {

    UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Confirmation" message:@"Declining will Quit this App. Are you sure you want to Quit?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1) {
        exit(0);
    }
}

@end

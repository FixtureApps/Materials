//
//  QuizViewController2.m
//  DontDateAPsycho
//
//  Created by Vidya on 09/11/13.
//  Copyright (c) 2013 fixtureapps. All rights reserved.
//

#import "QuizViewController2.h"

@interface QuizViewController2 ()

@end

@implementation QuizViewController2

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

-(void) viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBar.hidden = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  ViewController.h
//  DontDateAPsycho
//
//  Created by fixtureapps on 11/3/13.
//  Copyright (c) 2013 fixtureapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)declineClicked:(id)sender;

@end

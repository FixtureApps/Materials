//
//  DashBoardViewController.h
//  DontDateAPsycho
//
//  Created by Vidya on 07/11/13.
//  Copyright (c) 2013 fixtureapps. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "iCarousel.h"

@interface DashBoardViewController : UIViewController<iCarouselDataSource, iCarouselDelegate>

@property (strong, nonatomic) IBOutlet iCarousel *carousel;
@end

package decopack;

public class BloodTest extends Test{
	MoneyMaking customer;
	public BloodTest(MoneyMaking customer)
	{
		this.customer=customer;
	}
	public int cost() {
		// TODO Auto-generated method stub
		return 100+customer.cost();
	}

}

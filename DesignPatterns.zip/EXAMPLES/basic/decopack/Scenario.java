package decopack;

public class Scenario {
public static void main(String[] args) {
	MoneyMaking ramu=new Student();
	ramu=new BloodTest(ramu);
	ramu=new BloodTest(ramu);
	ramu=new XrayTest(ramu);
	System.out.println(ramu.cost());
}
}

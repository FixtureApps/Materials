package decopack;

public abstract class MoneyMaking {
	public abstract int cost();
}

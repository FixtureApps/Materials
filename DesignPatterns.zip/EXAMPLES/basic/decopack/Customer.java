package decopack;

public abstract class Customer extends MoneyMaking{

}

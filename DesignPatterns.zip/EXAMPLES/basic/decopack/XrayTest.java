package decopack;

public class XrayTest extends Test{
	MoneyMaking customer;
	public XrayTest(MoneyMaking customer)
	{
		this.customer=customer;
	}
	public int cost() {
		// TODO Auto-generated method stub
		return 300+customer.cost();
	}
	
}

package decopack;

public class Student extends Customer {

	public int cost() {
		// TODO Auto-generated method stub
		return 50;
	}

}

package decopack;

public abstract class Test extends MoneyMaking{

}

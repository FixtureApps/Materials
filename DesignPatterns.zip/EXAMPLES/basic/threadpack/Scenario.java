package threadpack;

public class Scenario {
public static void main(String[] args) {
	Counter tidel=new Counter();
	new CreateThread("ramu",tidel,1000);
	new CreateThread("somu",tidel,500);
}
}

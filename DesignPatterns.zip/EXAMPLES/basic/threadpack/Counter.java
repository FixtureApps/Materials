package threadpack;

public class Counter {
	int amt;
	synchronized public void bookTicket(int amt)
	{
		this.amt=amt;
		Thread t=Thread.currentThread();
		System.out.println("User:"+t.getName());
		System.out.println("Ticket Booked...");
		try{Thread.sleep(5000);}catch(Exception e){}
	}
	 synchronized public void giveChange()
	{
		Thread t=Thread.currentThread();
		System.out.println("User:"+t.getName());
		System.out.println("change given..." +(amt-100));
	}
	 public void water()
	 {
		 System.out.println("drinking water");
	 }
}

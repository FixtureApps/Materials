package threadpack;

public class ThreadDemo implements Runnable{
	Thread t;
	public ThreadDemo()
	{
		t=new Thread(this);
		t.start();
	}
	public void run()
	{
		System.out.println("child thread...");
	}
	public static void main(String[] args) {
		new ThreadDemo();
		for(int i=0;i<5;i++)
		{
			System.out.println("main thread :"+i);
			try{Thread.sleep(1);}catch(Exception e){}
		}
	}
}

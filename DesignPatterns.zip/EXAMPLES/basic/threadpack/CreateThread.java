package threadpack;

public class CreateThread implements Runnable {
	Thread t;Counter tidel;int amt;
	 public CreateThread(String name,Counter tidel,int amt)
	{
		this.amt=amt;
		this.tidel=tidel;
		t=new Thread(this,name);
		t.start();
	}
	public void run()
	{
		Thread t=Thread.currentThread();
		if(t.getName().equals("ramu")){
		tidel.bookTicket(amt);
		}
		else
		{
			tidel.water();
		}
	}
}

package obserpack;

import java.util.Observable;
import java.util.Observer;

public class Students implements Observer{

	public void update(Observable o, Object arg) {
		System.out.println(arg);
		run();
	}
	public void run()
	{
		System.out.println("students are running");
	}
}

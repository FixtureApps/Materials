package obserpack;

public class Scenario {
	public static void main(String[] args) {
		FireAlarm alarm=new FireAlarm();
		Students satyam=new Students();
		Faculty shoiab=new Faculty();
		
		alarm.addObserver(satyam);
		alarm.addObserver(shoiab);
		
		alarm.setAlarm("Fire fire fire.....");
	}
}

package obserpack;

import java.util.Observer;

public class CreateThread implements Runnable{
	Thread t;Observer obs;String message;
	public CreateThread(Observer obs,Object args)
	{
		this.obs=obs;this.message=args.toString();
		t=new Thread(this);
		t.start();
	}
	public void run()
	{
		obs.update(null,message);
	}
}

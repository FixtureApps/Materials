package obserpack;

import java.util.Observable;

public class FireAlarm extends MyObservable{
	String alarm;
	public void setAlarm(String alarm)
	{
		this.alarm=alarm;
		setChanged();
		notifyObservers(alarm);
	}
	
}

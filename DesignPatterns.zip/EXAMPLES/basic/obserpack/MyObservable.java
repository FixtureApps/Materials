package obserpack;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Observable;
import java.util.Observer;

public class MyObservable extends Observable{
	LinkedList ll=new LinkedList();
	public synchronized void addObserver(Observer o) {
		ll.add(o);
	}
	public void notifyObservers(Object args) {
		Iterator i=ll.iterator();
		while(i.hasNext())
		{
			Observer obs=(Observer)i.next();
			new CreateThread(obs,args);
		}
	}
}

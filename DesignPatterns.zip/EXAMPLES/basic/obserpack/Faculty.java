package obserpack;

import java.util.Observable;
import java.util.Observer;

public class Faculty implements Observer{
	public void update(Observable o, Object arg) {
		System.out.println("arg");
		run();
	}
	public void run()
	{
		try{Thread.sleep(5000);}catch(Exception e){}
		System.out.println("faculty is running");
	}
}

package factorypack;

public class VimalShoeShop extends ShoeShop{
	ShoeFactory factory;
		public void setFactory(ShoeFactory factory)
		{
			this.factory=factory;
		}
		public ShoeFactory getFactory()
		{
			return factory;
		}
		
	public Shoe sellShoe()
	{
		System.out.println(factory);
		return factory.makeShoe();
	}

}

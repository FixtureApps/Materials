package factorypack;

public class BataShoeFactory extends ShoeFactory{

	public Shoe makeShoe() {
		// TODO Auto-generated method stub
		return new Shoe();
	}
	
}

package factorypack;

public abstract class ShoeFactory {
	public abstract Shoe makeShoe();
}

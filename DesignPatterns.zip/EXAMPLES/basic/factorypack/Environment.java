package factorypack;

import java.io.FileInputStream;
import java.util.Properties;

public class Environment {
public static ShoeShop getShoeShop()
{
	try{
	Properties p=new Properties();
	p.load(new FileInputStream("config.properties"));
	String bean1=p.get("bean1").toString();
	String bean1depends=p.get("bean1.depends").toString();
	ShoeShop shop=(ShoeShop)Class.forName(bean1).newInstance();
	ShoeFactory factory=(ShoeFactory)Class.forName(bean1depends).newInstance();
	shop.setFactory(factory);
	return shop;
	}catch(Exception e){System.out.println(e);return null;}
}
}

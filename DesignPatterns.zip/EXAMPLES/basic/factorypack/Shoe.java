package factorypack;

public class Shoe {

}

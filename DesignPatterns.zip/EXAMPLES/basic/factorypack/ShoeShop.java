package factorypack;

public abstract class ShoeShop {
	ShoeFactory factory;
	public abstract void setFactory(ShoeFactory factory);
	public abstract ShoeFactory getFactory();
	public abstract Shoe sellShoe();
}

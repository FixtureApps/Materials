package factorypack;

public class Scenario {
public static void main(String[] args) {
	ShoeShop myshop=Environment.getShoeShop();
	Shoe myshoe=myshop.sellShoe();
	System.out.println("myshoe :"+myshoe);
}
}

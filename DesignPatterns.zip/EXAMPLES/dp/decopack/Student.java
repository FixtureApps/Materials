package decopack;

public class Student extends Customer{
	@Override
	
	public int cost() {
		// TODO Auto-generated method stub
		return 10;
	}
}

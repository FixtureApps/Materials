package decopack;

public class BloodTest extends Test{
	MoneyMaking mm;
	public BloodTest(MoneyMaking mm)
	{
		this.mm=mm;
	}
	@Override
	public int cost() {
		// TODO Auto-generated method stub
		return 10+mm.cost();
	}
}


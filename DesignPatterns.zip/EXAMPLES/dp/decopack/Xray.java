package decopack;

public class Xray extends Test{
	MoneyMaking mm;
	public Xray(MoneyMaking mm)
	{
		this.mm=mm;
	}
	@Override
	public int cost() {
		// TODO Auto-generated method stub
		return 20+mm.cost();
	}
}

package decopack;

public class Scenario {
public static void main(String[] args) {
	MoneyMaking mm=new Student();
	System.out.println("student:"+mm.cost());
	mm=new BloodTest(mm);
	System.out.println("student+bt:"+mm.cost());
	
	mm=new BloodTest(mm);
	
	System.out.println("student+bt+bt:"+mm.cost());
	}
}

package command;

public class Remote {
	Command onSlot[]=new Command[5];
	Command offSlot[]=new Command[5];
	Command temp;
	Remote()
	{
		for(int i=0;i<5;i++)
		{
			onSlot[i]=new NoCommand();
			offSlot[i]=new NoCommand();
		}
	}
	public void setUp(Command on,Command off,int slot)
	{
		onSlot[slot]=on;
		offSlot[slot]=off;
	}
	public void onButtonPressed(int slot)
	{
		onSlot[slot].execute();
		temp=onSlot[slot];
	}
	public void offButtonPressed(int slot)
	{
		offSlot[slot].execute();
		temp=offSlot[slot];
	}
	public void undo()
	{
		temp.undo();
	}
}

package command;

public class FridgeCoolCommand implements Command{
	Fridge fridge;
	public FridgeCoolCommand(Fridge fridge)
	{
		this.fridge=fridge;
	}
	public void execute() {
		fridge.cool();
	}

	public void undo() {
		fridge.off();
	}

}

package command;

public class Scenario {
public static void main(String[] args) {
	Remote chineseremote=new Remote();
	
	Tv onida=new Tv();
	Fridge sony=new Fridge();
	
	TvOnCommand tvon=new TvOnCommand(onida);
	
	FridgeCoolCommand fc=new FridgeCoolCommand(sony);
	
	chineseremote.setUp(tvon,new NoCommand(),0);
	chineseremote.setUp(fc,new NoCommand(),1);
	
	chineseremote.onButtonPressed(1);
}
}

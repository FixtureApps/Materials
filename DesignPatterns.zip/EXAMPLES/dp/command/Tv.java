package command;

public class Tv {
	public void on()
	{
		System.out.println("TV On method called..");
	}
	public void off()
	{
		System.out.println("TV off method called..");
	}
}

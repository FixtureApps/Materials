package command;

public class NoCommand implements Command{

	public void execute() {
		System.out.println("I am dummy...");
	}
	public void undo() {
		System.out.println("I am dummy...");
	}
}

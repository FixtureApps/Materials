package command;

public class Fridge {
	public void on()
	{
		System.out.println("fridge on called..");
	}
	public void off()
	{
		System.out.println("fridge off called..");
	}
	public void freeze()
	{
		System.out.println("fridge freeze called..");
	}
	public void cool()
	{
		System.out.println("fridge cool called..");
	}
}

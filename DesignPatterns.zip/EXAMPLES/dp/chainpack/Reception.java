package chainpack;

public class Reception implements Interceptor{
	public void doIntercept() {
		// TODO Auto-generated method stub
		System.out.println("provide IT certificate for laptop and take signatures..");
	}
}

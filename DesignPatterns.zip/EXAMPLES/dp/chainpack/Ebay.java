package chainpack;

public class Ebay {
	public void training()
	{
		Training ooad=new Training();
		GroundSecurity gs=new GroundSecurity();
		FirstFloorSecurity fs=new FirstFloorSecurity();
		Reception recep=new Reception();
		
		Interceptor inters[]=new Interceptor[]{gs,fs,recep};
		InterceptorChain ichain=new InterceptorChain();
		
		ichain.setInter(inters);
		ichain.execute();
		ooad.service();
		
	}
}

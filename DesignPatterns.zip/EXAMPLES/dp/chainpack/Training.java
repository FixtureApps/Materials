package chainpack;

public class Training {
	public void service()
	{
		System.out.println("service is rendered now............");
	}
}

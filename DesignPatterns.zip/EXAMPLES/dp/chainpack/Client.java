package chainpack;

public class Client {
public static void main(String[] args) {
	Ebay ebay=new Ebay();
	ebay.training();
}
}

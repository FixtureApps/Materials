package chainpack;

public interface Interceptor {
	public void doIntercept();
}

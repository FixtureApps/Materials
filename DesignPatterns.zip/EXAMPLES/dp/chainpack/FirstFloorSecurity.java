package chainpack;

public class FirstFloorSecurity implements Interceptor{
	public void doIntercept() {
		// TODO Auto-generated method stub
		System.out.println("does check for laptop and appointment...");
		
	}
}

package chainpack;

public class GroundSecurity implements Interceptor{
public void doIntercept() {
	// TODO Auto-generated method stub
	System.out.println("does normal check,and enquires.........");
	//ic.getInter().doIntercept(ic);
	
}
}

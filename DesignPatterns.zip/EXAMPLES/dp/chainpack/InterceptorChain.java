package chainpack;

public class InterceptorChain {
	Interceptor inter[];
	Interceptor interceptor;
	public Interceptor[] getInter() {
		return inter;
	}

	public void setInter(Interceptor[] inter) {
		this.inter = inter;
	}

	public void execute()
	{
		for(int i=0;i<inter.length;i++)
		{
			interceptor=inter[i];
			interceptor.doIntercept();
		}
	}
	
}

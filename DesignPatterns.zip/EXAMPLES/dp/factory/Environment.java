package factory;

import java.util.Properties;
import java.io.FileInputStream;
public class Environment {
	public static ShoeShop getShop()
	{
	
		try{
			Properties prop=new Properties();
			prop.load(new FileInputStream("config.properties"));
			String s=prop.getProperty("shop").toString();
			String f=prop.getProperty("factory").toString();
			ShoeShop shop=(ShoeShop)Class.forName(s).newInstance();
			ShoeFactory factory=(ShoeFactory)Class.forName(f).newInstance();
			shop.setFactory(factory);
			
		return shop;
		}catch(Exception e)
		{
			return null;
		}
		
	}
}

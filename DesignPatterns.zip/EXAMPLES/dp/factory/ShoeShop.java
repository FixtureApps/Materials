package factory;

public abstract class ShoeShop {
	private ShoeFactory factory;
	
	public abstract Shoe sellShoe();

	public ShoeFactory getFactory() {
		return factory;
	}

	public void setFactory(ShoeFactory factory) {
		this.factory = factory;
	}
}

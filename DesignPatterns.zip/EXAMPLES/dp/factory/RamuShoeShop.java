package factory;

public class RamuShoeShop extends ShoeShop{
	@Override
	public Shoe sellShoe() {
		// TODO Auto-generated method stub
		System.out.println(getFactory());
		return getFactory().makeShoe();
	}
}

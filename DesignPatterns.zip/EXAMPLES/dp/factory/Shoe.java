package factory;

public class Shoe {

}

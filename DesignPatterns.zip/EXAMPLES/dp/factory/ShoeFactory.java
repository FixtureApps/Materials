package factory;

public abstract class ShoeFactory {
	public abstract Shoe makeShoe();
}

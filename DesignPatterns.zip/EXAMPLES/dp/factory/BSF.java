package factory;

public class BSF extends ShoeFactory{
	@Override
	public Shoe makeShoe() {
		// TODO Auto-generated method stub
		return new Shoe();
	}
}

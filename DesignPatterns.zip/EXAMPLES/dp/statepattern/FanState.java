package statepattern;

public interface FanState {
	public void pull(CeilingFanPullChain2 wrapper);
}

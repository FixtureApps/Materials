package statepattern;

public class OffState implements FanState{
	public void pull(CeilingFanPullChain2 wrapper) {
		// TODO Auto-generated method stub
		wrapper.setFanstate(new LowSpeedState());
		System.out.println("The fan is switched from off to on state");
		System.out.println("The fan is in low speed state....");
	}
}

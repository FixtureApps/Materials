package statepattern;

public class CeilingFanPullChain2 {
	private FanState fanstate;
	public CeilingFanPullChain2()
	{
		this.fanstate=new OffState();
	}
	public void pull()
	{
		fanstate.pull(this);
	}
	public void setFanstate(FanState fanstate) {
		this.fanstate = fanstate;
	}
}

package statepattern;

public class LowSpeedState implements FanState{
public void pull(CeilingFanPullChain2 wrapper) {
	// TODO Auto-generated method stub
	wrapper.setFanstate(new MediumSpeedState());
	System.out.println("The fan is now from low to medium state.....");
}
}

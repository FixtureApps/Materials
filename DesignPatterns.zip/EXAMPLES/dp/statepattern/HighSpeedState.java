package statepattern;

public class HighSpeedState implements FanState{
public void pull(CeilingFanPullChain2 wrapper) {
	// TODO Auto-generated method stub
	wrapper.setFanstate(new OffState());
	System.out.println("From high speed to off state..........");
	
}
}

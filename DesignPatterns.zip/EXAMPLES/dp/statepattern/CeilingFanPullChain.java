package statepattern;

public class CeilingFanPullChain {
	private int fan_current_state;
	public CeilingFanPullChain()
	{
		fan_current_state=0;
	}
	public void pull()
	{
		if(fan_current_state==0)
		{
			fan_current_state=1;
			System.out.println("The fan is switched on and the state is from off to on");
			System.out.println("Low Speed.......");
		}
		else if(fan_current_state==1)
		{
			fan_current_state=2;
			System.out.println("The fan is swithed from low to medium speed");
			System.out.println("Medium Speed.......");
		}
		else if(fan_current_state==2)
		{
			fan_current_state=3;
			System.out.println("The fan is swithed from medium to high speed");
			System.out.println("High Speed.......");
		}
		else if(fan_current_state==3)
		{
			fan_current_state=0;
			System.out.println("The fan is swithed from high to off state");
			System.out.println("Switched off.......");
		}
	}
}

package statepattern;

public class MediumSpeedState implements FanState{
public void pull(CeilingFanPullChain2 wrapper) {
	// TODO Auto-generated method stub
	wrapper.setFanstate(new HighSpeedState());
	System.out.println("The fan is now from medium to high speed....");
	
}
}

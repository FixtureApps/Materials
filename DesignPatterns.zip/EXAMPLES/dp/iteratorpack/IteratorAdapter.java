package iteratorpack;

import java.util.Enumeration;
import java.util.Iterator;

public class IteratorAdapter implements Iterator{
	public Enumeration e;
	public IteratorAdapter(Enumeration e)
	{
		this.e=e;
	}
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return e.hasMoreElements();
	}

	public Object next() {
		// TODO Auto-generated method stub
		return e.nextElement();
	}

	public void remove() {
		// TODO Auto-generated method stub
		
	}

}

package iteratorpack;

import java.util.Iterator;
import java.util.Vector;

public class Scenario {
public static void main(String[] args) {
	Vector v=new Vector();
	v.add(0,"ebay");
	v.add(1,"hello");
	v.add(2,"hai");
	
	Iterator i=new IteratorAdapter(v.elements());
	
	while(i.hasNext())
	{
		System.out.println(i.next());
	}
}
}

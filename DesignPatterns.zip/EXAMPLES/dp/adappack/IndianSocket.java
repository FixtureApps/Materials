package adappack;

public interface IndianSocket {
	public void roundPin();
}

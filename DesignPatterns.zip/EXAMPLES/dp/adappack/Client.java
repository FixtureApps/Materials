package adappack;

public class Client {
public static void main(String[] args) {
	Legrand plug=new Legrand();
	AmericanSocket as=new AmericanAdapter(plug);
	as.slabPin();
}
}

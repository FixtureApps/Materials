package adappack;

public interface AmericanSocket {
	public void slabPin();
}

package adappack;

public class Legrand implements IndianSocket{
		public void roundPin() {
			// TODO Auto-generated method stub
			System.out.println("round pin plug inserted..............");
		}
}

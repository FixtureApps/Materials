package adappack;

public class AmericanAdapter implements AmericanSocket{
	IndianSocket soc;
	public AmericanAdapter(IndianSocket soc)
	{
		this.soc=soc;
	}
	public void slabPin() {
		// TODO Auto-generated method stub
		soc.roundPin();
	}
}

package builderpack;

public interface Items {
	public String getName();
	public int price();
}

package builderpack;

public interface Hotel {
	public void miniMeal();
	public void meal();
}

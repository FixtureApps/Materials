package builderpack;

public class Package {
	Items item;int price;
	public void addItems(Items items[])
	{
		for(int i=0;i<items.length;i++)
		{
			item=items[i];
			System.out.println(item.getName());
			price=price+item.price();
		}
		System.out.println("The price is :"+price);
	}
}

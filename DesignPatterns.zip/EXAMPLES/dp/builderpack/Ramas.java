package builderpack;

public class Ramas implements Hotel{
	private BuilderBoy ramu;
	Ramas()
	{
		ramu=new BuilderBoy();
	}
	public void meal() {
		// TODO Auto-generated method stub
		ramu.buildMeals();
	}
	public void miniMeal() {
		// TODO Auto-generated method stub
		ramu.buildMiniMeals();
	}
}

package builderpack;

public class BuilderBoy {
	Package packingdept=new Package();
	public void buildMiniMeals()
	{
		Items items[]=new Items[]{new Rice()};
		packingdept.addItems(items);
	}
	public void buildMeals()
	{
		Items items[]=new Items[]{new Rice(),new Chappathi()};
		packingdept.addItems(items);
	}
}


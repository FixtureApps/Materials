package builderpack;

public class Client {
public static void main(String[] args) {
	Hotel hotel=new Ramas();
	hotel.meal();
}
}

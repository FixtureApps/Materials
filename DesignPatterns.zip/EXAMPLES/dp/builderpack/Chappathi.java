package builderpack;

public class Chappathi implements Items{
	public String getName() {
		// TODO Auto-generated method stub
		return "CHAPPATHI";
	}
public int price() {
	// TODO Auto-generated method stub
	return 15;
}
}

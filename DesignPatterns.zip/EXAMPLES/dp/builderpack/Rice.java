package builderpack;

public class Rice implements Items{
	public String getName() {
		// TODO Auto-generated method stub
		return "RICE";
	}
	public int price() {
		// TODO Auto-generated method stub
		return 10;
	}
}

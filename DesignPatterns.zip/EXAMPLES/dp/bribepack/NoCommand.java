package bribepack;

public class NoCommand implements ESevaCommand{
	public void execute() {
		// TODO Auto-generated method stub
	System.out.println("i am dummy.....");	
	}
	public void undo() {
		// TODO Auto-generated method stub
		System.out.println("i am dummy........");
	}
}

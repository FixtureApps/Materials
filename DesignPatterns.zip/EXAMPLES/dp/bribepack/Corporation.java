package bribepack;

public class Corporation {
	public void getDeathCertificate()
	{
		//conditions are checked before giving.
		
		System.out.println("death certificate given............");
	}
}

package bribepack;

public class Police {
	public void getPoliceCert()
	{
		System.out.println("police clearance certificate is given...........");
	}
}

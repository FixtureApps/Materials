package bribepack;

public class ESevaCounter {
	ESevaCommand counter[]=new ESevaCommand[2];
	
	ESevaCounter()
	{
		for(int i=0;i<counter.length;i++)
		{
			counter[i]=new NoCommand();
		}
	}
	public void setUp(ESevaCommand com,int slot)
	{
		counter[slot]=com;
	}
	public void jobSelected(int slot)
	{
		counter[slot].execute();
	}
}

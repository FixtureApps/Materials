package bribepack;

public interface ESevaCommand {
	public void execute();
	public void undo();
}

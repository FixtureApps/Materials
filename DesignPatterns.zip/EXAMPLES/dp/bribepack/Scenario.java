package bribepack;

public class Scenario {
public static void main(String[] args) {
	ESevaCounter chennai=new ESevaCounter();
	Hospital gh=new Hospital();
	Police cop=new Police();
	Corporation ribbon=new Corporation();
	
	DeathCommand dc=new DeathCommand(ribbon,gh,cop);
	chennai.setUp(dc,0);
	
	chennai.jobSelected(0);
}
}

package bribepack;

public class Hospital {
	public void getMedicalCertificate()
	{
		System.out.println("medical certificate given........");
	}
}

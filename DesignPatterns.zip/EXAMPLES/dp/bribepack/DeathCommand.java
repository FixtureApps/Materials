package bribepack;

public class DeathCommand implements ESevaCommand{
	Hospital hop;Corporation cop;Police p;
	public DeathCommand(Corporation cop,Hospital hop,Police p)
	{
		this.hop=hop;
		this.cop=cop;
		this.p=p;
	}
public void execute() {
	// TODO Auto-generated method stub
	p.getPoliceCert();
	hop.getMedicalCertificate();
	cop.getDeathCertificate();
}
public void undo() {
	// TODO Auto-generated method stub
	System.out.println("cannot be undone......");	
}
}

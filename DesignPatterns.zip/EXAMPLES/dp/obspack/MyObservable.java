package obspack;

import java.util.Enumeration;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

public class MyObservable extends Observable {

	Vector v=new Vector();
	
	String msg;
	Observer o=null;
	public synchronized void addObserver(Observer o) {
		v.add(o);
	}
	@Override
	public void notifyObservers(Object arg) {
			
		Enumeration e=v.elements();
		while(e.hasMoreElements())
		{
		o=(Observer)e.nextElement();
		new CreateThread(o,msg);
		}
	}
}

package obspack;

public class Scenario {
	public static void main(String[] args) {
		FireAlarm sakthi=new FireAlarm();
		
		Teacher shoiab=new Teacher();
		Student ebay=new Student();
		
		sakthi.addObserver(ebay);
		sakthi.addObserver(shoiab);
		
		
		sakthi.setAlarm("fire in the mountain run run run......");
		
	}
}

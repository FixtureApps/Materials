package obspack;

import java.util.Observable;

public class FireAlarm extends MyObservable{
	private String alarm;
	public void setAlarm(String alarm)
	{
		this.alarm=alarm;
		setChanged();
		notifyObservers(alarm);
	}
}

package obspack;

import java.util.Observable;
import java.util.Observer;

public class CreateThread implements Runnable{
	Thread t;
	Observer obj;String msg;
	public CreateThread(Observer obj,String msg)
	{
		this.obj=obj;this.msg=msg;
		t=new Thread(this);
		t.start();
	}
	public void run()
	{
		obj.update(null,msg);
	}
}

package obspack;

import java.util.Observable;
import java.util.Observer;

public class Student implements Observer{
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		System.out.println(arg);
		running();
		
	}
	public void running()
	{
		try{Thread.sleep(5000);}catch(Exception e){}
		System.out.println("Students are running..........");
	}
}

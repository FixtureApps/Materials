package singleton;

public class MySingleTon {
	static MySingleTon mysingleton;int i=1;
	private MySingleTon()
	{
		System.out.println("No of objects created..."+ i++);
	}
	synchronized public static MySingleTon getMySingleTon()
	{
		if(mysingleton==null)
		{
			mysingleton=new MySingleTon();
			return mysingleton;
		}
		else
		{
			return mysingleton;
		}
	}
}

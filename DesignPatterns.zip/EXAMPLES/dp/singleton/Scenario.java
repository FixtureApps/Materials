package singleton;

public class Scenario {
public static void main(String[] args) {
	
	MySingleTon obj=MySingleTon.getMySingleTon();
	MySingleTon obj1=MySingleTon.getMySingleTon();
	MySingleTon obj2=MySingleTon.getMySingleTon();
	MySingleTon obj3=MySingleTon.getMySingleTon();
	MySingleTon obj4=MySingleTon.getMySingleTon();
	MySingleTon obj5=MySingleTon.getMySingleTon();
	
}
}

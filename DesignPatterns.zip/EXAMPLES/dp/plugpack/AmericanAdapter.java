package plugpack;

public class AmericanAdapter implements AmericanSocket{
	IndianSocket is;
	public AmericanAdapter(IndianSocket is)
	{
		this.is=is;
	}
	public void slabSocket() {
		// TODO Auto-generated method stub
		is.roundSocket();
	}
}

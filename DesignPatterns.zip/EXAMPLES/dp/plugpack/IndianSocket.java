package plugpack;

public interface IndianSocket {
	public void roundSocket();
}

package plugpack;

public interface AmericanSocket {
	public void slabSocket();
}

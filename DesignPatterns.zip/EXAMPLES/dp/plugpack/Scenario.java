package plugpack;

public class Scenario {
public static void main(String[] args) {
	Legrand socket=new Legrand();
	
	AmericanSocket as=new AmericanAdapter(socket);
	
	as.slabSocket();
}
}

package plugpack;

public class Legrand implements IndianSocket{
	public void roundSocket() {
		// TODO Auto-generated method stub
		System.out.println("round socket used............");
	}
}

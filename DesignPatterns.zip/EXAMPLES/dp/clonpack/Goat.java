package clonpack;

import java.io.FileInputStream;

public class Goat implements Cloneable{
	 String name;//primitive
	 FileInputStream fis;//complex (resource)
	public Goat()
	{
		System.out.println("cons called...............");
		try{
			fis=new FileInputStream("d:/notes.txt");
		}catch(Exception e){}
	}
	public Object getClone()
	{
		try{
			return super.clone();
		}catch(Exception e){return null;}
	}
}

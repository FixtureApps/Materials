package clonpack;

public class Scenario {
	public static void main(String[] args)throws Exception {
		Goat mothergoat=new Goat();
		Goat dolly=(Goat)mothergoat.getClone();
		
		mothergoat.name="my name is mothergoat";
		
		System.out.println(mothergoat.name);
		System.out.println(mothergoat.fis.available());
		
		mothergoat.fis.close();
		
		System.out.println(dolly.fis.available());
		
	}
}

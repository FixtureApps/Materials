package momentopattern;

public class OriginalObject {
	private String story="jack and jill went up the hill....";
	private String authorname="rahul";
	private MySerializer ser;
	public void newStory(String story,String authorname)
	{	
		ser=new MySerializer();
		createMomento();
		this.story=story;this.authorname=authorname;
	}
	public void undo()
	{
		setMomento();
	}
	public void createMomento()
	{
		Momento mom=new Momento(story,authorname);
		ser.serialize(mom);
		
	}
	public void setMomento()
	{
		Momento mom=(Momento)ser.deserialize();
		this.story=mom.getStory();
		this.authorname=mom.getAuthorname();
	}
	public String getStory() {
		return story;
	}
}

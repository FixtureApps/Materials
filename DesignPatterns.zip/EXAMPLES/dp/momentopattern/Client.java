package momentopattern;

public class Client {
public static void main(String[] args) {
	OriginalObject org=new OriginalObject();
	org.newStory("bla bla bla bal bla ...","blabla");
	
	org.undo();
	
	System.out.println(org.getStory());
	
}
}

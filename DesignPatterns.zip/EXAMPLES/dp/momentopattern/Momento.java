package momentopattern;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Momento implements Serializable{
	private String story,authorname;
	public Momento(String story,String authorname)
	{
		this.story=story;this.authorname=authorname;		
	}
	public String getAuthorname() {
		return authorname;
	}
	public String getStory() {
		return story;
	}
		
}

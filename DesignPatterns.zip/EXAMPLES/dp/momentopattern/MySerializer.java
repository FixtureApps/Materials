package momentopattern;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class MySerializer {
	public void serialize(Momento mom)
	{
		try{
		FileOutputStream fos=new FileOutputStream("d:/story.dat");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(mom);
		}catch(Exception e){}
	}
	public Object deserialize()
	{
		try{
		FileInputStream fis=new FileInputStream("d:/story.dat");
		ObjectInputStream ois=new ObjectInputStream(fis);
		return ois.readObject();
		}catch(Exception e){return null;}
	}
}

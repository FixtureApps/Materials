package tagpack;

import java.util.ResourceBundle;

import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class Message extends TagSupport{
	String key;
	public void setKey(String key)
	{
		this.key=key;
	}
	public int doEndTag() throws JspException {
		HttpSession session=pageContext.getSession();
		ResourceBundle rb=(ResourceBundle)session.getAttribute("rb");
		String value=rb.getString(key);
		JspWriter out=pageContext.getOut();
		try{out.print(value);}catch(Exception e){}
		return 1;
	}
}

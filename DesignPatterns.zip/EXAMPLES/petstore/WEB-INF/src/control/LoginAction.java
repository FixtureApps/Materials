package control;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginAction extends Action{

	public String execute(HttpServletRequest req, HttpServletResponse res) {
		String uname=req.getParameter("uname");
		ActionError error;
		HttpSession session=req.getSession();
		if(uname.equals("null")||uname.length()==0)
		{
			error=new ActionError();error.setMsg("The user name is null....");
			session.setAttribute("error",error);
			return "login.failure";
		}
		if(uname.equals("ramu"))
		{
			return "login.success";
		}
		else
		{
			return "login.failure";
		}
	}

}

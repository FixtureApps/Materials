package control;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LogoutAction extends Action{

	public String execute(HttpServletRequest req, HttpServletResponse res) {
		return "logout.success";
	}

}

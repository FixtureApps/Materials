package control;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FrontController extends HttpServlet{
	Secretary assistant;String fullpath;
	public void init(ServletConfig config) throws ServletException {
		String path=config.getInitParameter("config");
		ServletContext application=config.getServletContext();
		fullpath=application.getRealPath(path);
	}
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		req.setAttribute("fullpath",fullpath);
		assistant=new Secretary();
		assistant.process(req,res);
		
	}
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req,res);
	}
}

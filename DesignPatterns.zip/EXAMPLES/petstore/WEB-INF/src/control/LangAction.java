package control;

import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LangAction extends Action{

	public String execute(HttpServletRequest req, HttpServletResponse res) {
		String lang=req.getParameter("language");
		Locale locale=new Locale(lang);
		
		ResourceBundle rb=ResourceBundle.getBundle("Dictionary",locale);
		HttpSession session=req.getSession();
		session.setAttribute("rb",rb);
		return "lang.success";
	}

}

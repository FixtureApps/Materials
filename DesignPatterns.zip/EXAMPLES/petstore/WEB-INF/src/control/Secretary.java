package control;

import java.io.FileInputStream;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Secretary {
	RequestDispatcher rd;
	public void process(HttpServletRequest req,HttpServletResponse res)
	{
		try{
			Properties p=new Properties();
			p.load(new FileInputStream(req.getAttribute("fullpath").toString()));
			String id=req.getParameter("id");
			String actionclass=p.get(id).toString();
			Action action=(Action)Class.forName(actionclass).newInstance();
			String result=action.execute(req,res);
			String path=p.get(result).toString();
			rd=req.getRequestDispatcher(path);
			rd.forward(req,res);
		}catch(Exception e){System.out.println("from sec:"+e);}
	}
}

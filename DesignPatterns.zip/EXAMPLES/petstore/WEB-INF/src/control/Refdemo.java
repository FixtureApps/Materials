package control;

import java.lang.reflect.Method;

public class Refdemo {
public static void main(String[] args) throws Exception{
	Class s=Class.forName("java.lang.String");
	Method m[]=s.getClass().getMethods();
	for(int i=0;i<m.length;i++)
	{
		//System.out.println(m[i].getName());
		
	}
	Method mm=s.getClass().getMethod("hashCode",new Class[]{});
	System.out.println(mm.invoke(s,new Object[]{}));
}
}

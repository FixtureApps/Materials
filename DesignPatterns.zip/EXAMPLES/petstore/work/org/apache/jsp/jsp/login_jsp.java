package org.apache.jsp.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;

public final class login_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  static {
    _jspx_dependants = new java.util.Vector(1);
    _jspx_dependants.add("/WEB-INF/satyamtags.tld");
  }

  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_satyam_message_key;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _jspx_tagPool_satyam_message_key = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
  }

  public void _jspDestroy() {
    _jspx_tagPool_satyam_message_key.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");

	control.ActionError error=(control.ActionError)session.getAttribute("error");
	if(error!=null)
	{
		out.println("<h1>Error Messages<h1>");
		out.println("<li style='color:red'>"+error.getMsg()+"</li>");
		out.println("<hr>");
	}



      out.write("\r\n");
      out.write("<form action=\"/petstore/*.do\">\r\n");
      out.write("\t<input type=\"hidden\" name=\"id\" value=\"login\">\r\n");
      out.write("\r\n");
      out.write("\t");
      if (_jspx_meth_satyam_message_0(_jspx_page_context))
        return;
      out.write(":<input type=\"text\" name=\"uname\">\r\n");
      out.write("\t");
      if (_jspx_meth_satyam_message_1(_jspx_page_context))
        return;
      out.write(":<input type=\"password\" name=\"upass\">\r\n");
      out.write("\t\r\n");
      out.write("\t<input type=\"submit\" value=\"login\">\r\n");
      out.write("\r\n");
      out.write("</form>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_satyam_message_0(PageContext _jspx_page_context)
          throws Throwable {
    JspWriter out = _jspx_page_context.getOut();
    //  satyam:message
    tagpack.Message _jspx_th_satyam_message_0 = (tagpack.Message) _jspx_tagPool_satyam_message_key.get(tagpack.Message.class);
    _jspx_th_satyam_message_0.setPageContext(_jspx_page_context);
    _jspx_th_satyam_message_0.setParent(null);
    _jspx_th_satyam_message_0.setKey("username");
    int _jspx_eval_satyam_message_0 = _jspx_th_satyam_message_0.doStartTag();
    if (_jspx_th_satyam_message_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_satyam_message_key.reuse(_jspx_th_satyam_message_0);
    return false;
  }

  private boolean _jspx_meth_satyam_message_1(PageContext _jspx_page_context)
          throws Throwable {
    JspWriter out = _jspx_page_context.getOut();
    //  satyam:message
    tagpack.Message _jspx_th_satyam_message_1 = (tagpack.Message) _jspx_tagPool_satyam_message_key.get(tagpack.Message.class);
    _jspx_th_satyam_message_1.setPageContext(_jspx_page_context);
    _jspx_th_satyam_message_1.setParent(null);
    _jspx_th_satyam_message_1.setKey("password");
    int _jspx_eval_satyam_message_1 = _jspx_th_satyam_message_1.doStartTag();
    if (_jspx_th_satyam_message_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_satyam_message_key.reuse(_jspx_th_satyam_message_1);
    return false;
  }
}

package factorypack;

public class RamuShoeShop extends ShoeShop{
public RamuShoeShop() {
	// TODO Auto-generated constructor stub
}
public RamuShoeShop(ShoeFactory factory) {
	// TODO Auto-generated constructor stub
	super(factory);
}
public Shoe sellShoe() {
	// TODO Auto-generated method stub
	return getFactory().makeShoe();
}
}

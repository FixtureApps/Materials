package factorypack;

public abstract class ShoeShop {
	private ShoeFactory factory;
	public ShoeShop() {
		// TODO Auto-generated constructor stub
	}
	public ShoeShop(ShoeFactory factory)
	{
		this.factory=factory;
	}
	public ShoeFactory getFactory()
	{
		return factory;
	}
	public abstract Shoe sellShoe();
}

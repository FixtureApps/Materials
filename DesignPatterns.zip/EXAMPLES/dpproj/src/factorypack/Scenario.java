package factorypack;

public class Scenario {
	public static void main(String[] args) {
		ShoeShop shop=Environment.getShop();
		System.out.println(shop.sellShoe());
	}
}

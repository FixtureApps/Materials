package factorypack;

import java.io.FileInputStream;
import java.lang.reflect.Constructor;
import java.util.Properties;

public class Environment {
	public static ShoeShop getShop()
	{
		try{
			Properties p=new Properties();
			p.load(new FileInputStream("config.properties"));
			ShoeFactory factory=(ShoeFactory)
					Class.forName(p.getProperty("factory")).newInstance();
			System.out.println(factory);
			ShoeShop shop=(ShoeShop)
					Class.forName(p.getProperty("shop")).newInstance();
			
			Constructor cons=shop.getClass().getConstructor(ShoeFactory.class);
			cons.setAccessible(true);
			ShoeShop loadedshop=(ShoeShop)cons.newInstance(factory);
			
			return loadedshop;
			
		}catch(Exception e){e.printStackTrace();return null;}
	}
}

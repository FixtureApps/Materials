package chaining;

public class Scenario {
public static void main(String[] args) {
	Dog killer=new Dog();
	try{
		killer.hit();
	}catch(Throwable e){
		try{
			run(e);
		}catch(Throwable t){
			System.out.println(t);
			System.out.println(t.getCause());
		}
		System.out.println(e.getCause());
	}
}
public static void run(Throwable e)throws Throwable
{
	throw new RunException("I am running......").initCause(e);
}
}

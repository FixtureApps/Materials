package chaining;

public class DogBiteException extends Exception{
	String msg;
	public DogBiteException(String msg) {
		// TODO Auto-generated constructor stub
		this.msg=msg;
	}
	@Override
	public String toString() {
		return "DogBitingException:"+msg;
	}
}

package chaining;

public class Dog {
	public void hit()throws DogBiteException,Throwable
	{
		throw new DogBiteException("Dog bites.....").
					initCause(new BeatException("because I have beaten"));		
	}
}

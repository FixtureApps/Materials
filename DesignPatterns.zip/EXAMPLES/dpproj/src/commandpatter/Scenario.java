package commandpatter;

public class Scenario {
public static void main(String[] args) {
	TV onida=new TV();
	Fridge voltas=new Fridge();
	AC samsung=new AC();
	
	RemoteFacade myremote=new RemoteFacade();
	
	PartyCommand pc=new PartyCommand(onida, voltas, samsung);
	OrderVegCommand ovg=new OrderVegCommand(voltas);
	
	myremote.onCommand(pc, 0);
	myremote.onCommand(ovg, 1);
	
	//use the remote......
	myremote.pressOnButton(1);
	myremote.universalUndo();
}
}

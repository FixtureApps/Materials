package commandpatter;

public class TV {
	public void onthetv()
	{
		System.out.println("TV ON.....");
	}
	public void onstereo()
	{
		System.out.println("stereo on for party...");
	}
	public void mtv()
	{
		System.out.println("mtv on.........");
	}
	public void offTv()
	{
		System.out.println("tv switched off.....");
	}
}

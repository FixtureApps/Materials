package commandpatter;

public class AC {
	public void chill()
	{
		System.out.println("Chill now.......");
	}
	public void normaltemperature()
	{
		System.out.println("now the ac is on normal temperature....");
	}
}

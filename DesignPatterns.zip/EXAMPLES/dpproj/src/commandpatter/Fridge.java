package commandpatter;

public class Fridge {
	public void freeze()
	{
		System.out.println("freezer is switched on.....");
	}
	public void orderVegetables()
	{
		System.out.println("vegetables ordered....");
	}
	public void orderdrinks()
	{
		System.out.println("drinks ordered.......for party......");
	}
	public void shutdown()
	{
		System.out.println("fridge shuts down....");
	}
}

package commandpatter;

public class OrderVegCommand implements Command{
	Fridge voltas;
	public OrderVegCommand(Fridge voltas)
	{
		this.voltas=voltas;
	}
@Override
public void execute() {
	// TODO Auto-generated method stub
	voltas.orderVegetables();
}
@Override
	public void undo() {
		// TODO Auto-generated method stub
		voltas.shutdown();
	}
}

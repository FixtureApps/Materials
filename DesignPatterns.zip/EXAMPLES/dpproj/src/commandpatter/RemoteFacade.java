package commandpatter;

public class RemoteFacade {
	Command on[]=new Command[5];
	Command off[]=new Command[5];
	Command last;
	public RemoteFacade()
	{
		for(int i=0;i<5;i++)
		{
			on[i]=new DummyCommand();
			off[i]=new DummyCommand();
		}
	}
	public void onCommand(Command command,int slot)
	{
		on[slot]=command;
	}
	public void offCommand(Command command,int slot)
	{
		off[slot]=command;
	}
	public void pressOnButton(int slot)
	{
		on[slot].execute();
		last=on[slot];
	}
	public void pressOffButton(int slot)
	{
		off[slot].undo();
		
	}
	public void universalUndo()
	{
		last.undo();
	}
}

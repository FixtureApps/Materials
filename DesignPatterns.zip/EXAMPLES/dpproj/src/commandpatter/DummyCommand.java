package commandpatter;

public class DummyCommand implements Command{
@Override
public void execute() {
	// TODO Auto-generated method stub
	System.out.println("iam dummy....try later....");
}
@Override
	public void undo() {
		// TODO Auto-generated method stub
	System.out.println("iam dummy....try later....");
	}
}

package commandpatter;

public class PartyCommand implements Command{
	TV onida; Fridge voltas; AC samsung;
	public PartyCommand(TV onida,Fridge voltas,AC samsung)
	{
		this.onida=onida;this.voltas=voltas;this.samsung=samsung;
	}
@Override
public void execute() {
	// TODO Auto-generated method stub
	samsung.chill();
	voltas.orderdrinks();
	voltas.freeze();
	onida.mtv();
}
@Override
	public void undo() {
		onida.offTv();
		voltas.shutdown();
		samsung.normaltemperature();
	}
}

package decopack;

public class Scenario {
public static void main(String[] args) {
	MoneyMaking ramu=new Student();
	System.out.println("InitialCost:"+ramu.cost());
	
	ramu=new BloodTest(ramu);
	
	System.out.println("ramu+bloodTest:"+ramu.cost());
	
	ramu=new BloodTest(ramu);
	
	System.out.println("ramu+2 bt:"+ramu.cost());
}
}

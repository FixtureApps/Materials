package decopack;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class BloodTest extends Test{
	MoneyMaking mm;
	//java example for decoration
	//BufferedInputStream bis=new BufferedInputStream(new InputStreamReader(System.in));
	
	public BloodTest(MoneyMaking mm)
	{
		this.mm=mm;
	}
	@Override
	public int cost() {
		// TODO Auto-generated method stub
		return mm.cost()+10;
	}
	
}


package decopack;

public class CBTTest extends Test{
	MoneyMaking mm;
	public CBTTest(MoneyMaking mm)
	{
		this.mm=mm;
	}
@Override
public int cost() {
	// TODO Auto-generated method stub
	return mm.cost()+30;
}
}

package obspack;

import java.util.Observable;

public class FireAlarm extends CustomObservable{
	public void alarm()
	{
		System.out.println("Fire in the mountain run run run.....");
		setChanged();
		notifyObservers("fire fire fire......");		
	}
}

package obspack;

import java.util.Observable;
import java.util.Observer;

public class CreateThread implements Runnable{
	Observer obs;Object msg;Observable oble;
	Thread t;
	public CreateThread(Observer obs,Object msg,Observable oble)
	{
		this.obs=obs;this.msg=msg;this.oble=oble;
		t=new Thread(this);
		t.start();
	}
@Override
public void run() {
	// TODO Auto-generated method stub
	obs.update(oble, msg);
}
}

package obspack;

import java.util.Enumeration;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

public class CustomObservable extends Observable{
	Vector v=new Vector();
	@Override
	public synchronized void addObserver(Observer o) {
		v.add(o);
	}
	@Override
	public void notifyObservers(Object arg) {
		Enumeration e=v.elements();
		while(e.hasMoreElements())
		{
			new CreateThread((Observer)e.nextElement(),arg,this);
		}
	}
}

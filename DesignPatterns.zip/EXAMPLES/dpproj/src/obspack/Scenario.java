package obspack;

public class Scenario {
public static void main(String[] args) {
	FireAlarm sakthi=new FireAlarm();
	
	Students fidelity=new Students();
	Teacher shoiab=new Teacher();
	
	sakthi.addObserver(fidelity);
	sakthi.addObserver(shoiab);
	
	sakthi.alarm();
}
}

package obspack;

import java.util.Observable;
import java.util.Observer;

public class Students implements Observer{
	String message;
@Override
public void update(Observable o, Object msg) {
	// TODO Auto-generated method stub
	message=(String)msg;
	bhago();
}
public void bhago()
{
	
	System.out.println("Students running....:"+message);	
}
}

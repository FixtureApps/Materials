package obspack;

import java.util.Observable;
import java.util.Observer;

public class Teacher implements Observer{
	String message;
	@Override
	public void update(Observable o, Object msg) {
		message=(String)msg;
		bhago();
	}
	public void bhago()
	{
		try{Thread.sleep(5000);}catch(Exception e){}
		System.out.println("Teacher running....:"+message);
	}
}

package statepattern2;

import java.io.BufferedReader;
import java.io.*;

public class Client {
public static void main(String[] args) {
	Fan fanchain=new Fan();
	while(true)
	{
		System.out.println("Press a button.........");
		getAction();
		fanchain.pull();
	}
}
static String getAction()
{
	try{
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	String line=br.readLine();
	return line;
	}catch(Exception e){return null;
	}
}
}

package statepattern2;

public class OffState extends FanState{
@Override
public void pull(Fan fan) {
fan.setFanstate(new OnState());
System.out.println("The fan is switched on....");

}
}

package statepattern2;

public class Fan {
	private FanState fanstate;
	public Fan()
	{
		this.fanstate=new OffState();
	}
	public void pull()
	{
		fanstate.pull(this);
	}
	public void setFanstate(FanState fanstate)
	{
		this.fanstate=fanstate;
	}
}

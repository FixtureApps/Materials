package statepattern2;

public class HighSpeedState extends FanState {

	@Override
	public void pull(Fan fan) {
		// TODO Auto-generated method stub
		fan.setFanstate(new OffState());
		System.out.println("fan is switched off.....");

	}

}

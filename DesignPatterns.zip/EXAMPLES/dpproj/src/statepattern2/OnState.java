package statepattern2;

public class OnState extends FanState{
@Override
public void pull(Fan fan) {
fan.setFanstate(new LowSpeedState());
System.out.println("low speed state.....");
	
}
}

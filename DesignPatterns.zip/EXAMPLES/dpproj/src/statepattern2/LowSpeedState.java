package statepattern2;

public class LowSpeedState extends FanState {

	@Override
	public void pull(Fan fan) {
		// TODO Auto-generated method stub
		fan.setFanstate(new HighSpeedState());
		System.out.println("high speed state....");

	}

}

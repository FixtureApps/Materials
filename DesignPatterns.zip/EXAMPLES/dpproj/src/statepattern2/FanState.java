package statepattern2;

public abstract class FanState {
	public abstract void pull(Fan fan);
}

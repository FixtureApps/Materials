package momentopattern;

public class Client {
public static void main(String[] args) {
	OriginalObject org=new OriginalObject();
	
	org.newStory("bla bla bla bal bla ...","blabla");
	
	System.out.println("new story:"+org.getStory());
	org.undo();
	System.out.println("new story deleted....");
	System.out.println(org.getStory());
	
}
}

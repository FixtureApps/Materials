package clonepack;

import java.io.FileInputStream;

public class Goat implements Cloneable{
	String name;
	FileInputStream fis;
	String str="abcddefffff";
	public Goat()
	{
		System.out.println("cons called.....");
		for(int i=0;i<1000;i++)
		{
			str=str+i;
		}
		try{
			fis=new FileInputStream("d:/stalin.war");
		}catch(Exception e){}
	}
	public Object getClone()
	{
		try{
		return super.clone();
	}catch(Exception e){return null;}
	}
}



package clonepack;

public class Scenario {
public static void main(String[] args) throws Exception{
	Runtime r=Runtime.getRuntime();
	
	System.out.println("Free memory before creation:"+r.freeMemory());
	Goat mothergoat=new Goat();
	System.out.println("Free memory after mothergoat:"+r.freeMemory());
	mothergoat.name="my name is mothergoat";
	
	Goat dolly=(Goat)mothergoat.getClone();
	System.out.println("Free memory after clone:"+r.freeMemory());
	//dolly.name="my name is mothergoat";
	System.out.println(mothergoat.toString());
	System.out.println(dolly.toString());
	System.out.println("Mg:"+mothergoat.name);
	System.out.println("clone:"+dolly.name);
	System.out.println(mothergoat.fis.available());
	
	//mothergoat.fis.close();
	
	System.out.println(mothergoat==dolly);
	System.out.println(mothergoat.equals(dolly));
	System.out.println(dolly.fis.available());
	
} 

}
